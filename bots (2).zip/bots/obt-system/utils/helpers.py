"""
Helper Functions - دوال مساعدة
"""

import discord
import re
from datetime import datetime, timedelta


def parse_duration(duration_str: str) -> int:
    """
    Parse duration string to seconds.
    Examples: 10m, 2h, 1d, 30s
    """
    units = {
        's': 1, 'ث': 1,
        'm': 60, 'د': 60,
        'h': 3600, 'س': 3600,
        'd': 86400, 'ي': 86400,
    }
    match = re.match(r'^(\d+)([smhdثدسي])$', duration_str.lower())
    if not match:
        return None
    amount, unit = int(match.group(1)), match.group(2)
    return amount * units.get(unit, 1)


def format_duration(seconds: int) -> str:
    """Format seconds to human-readable Arabic string."""
    if seconds < 60:
        return f'{seconds} ثانية'
    elif seconds < 3600:
        return f'{seconds // 60} دقيقة'
    elif seconds < 86400:
        return f'{seconds // 3600} ساعة'
    else:
        return f'{seconds // 86400} يوم'


def format_datetime(dt: datetime) -> str:
    """Format datetime to Arabic string."""
    return dt.strftime('%Y/%m/%d %H:%M')


def has_higher_role(moderator: discord.Member, target: discord.Member) -> bool:
    """Check if moderator has higher role than target."""
    return moderator.top_role > target.top_role


def can_moderate(moderator: discord.Member, target: discord.Member) -> tuple[bool, str]:
    """Check if moderator can moderate target. Returns (can_moderate, reason)."""
    if target.id == moderator.guild.owner_id:
        return False, 'لا يمكن اتخاذ إجراء ضد مالك السيرفر.'
    if moderator.id == target.id:
        return False, 'لا يمكنك اتخاذ إجراء ضد نفسك.'
    if not has_higher_role(moderator, target):
        return False, 'لا يمكنك اتخاذ إجراء ضد عضو يملك رتبة أعلى منك أو مساوية لك.'
    return True, None


def is_url(text: str) -> bool:
    """Check if text contains a URL."""
    url_pattern = re.compile(
        r'https?://[^\s<>"{}|\\^`\[\]]+'
        r'|www\.[^\s<>"{}|\\^`\[\]]+'
    )
    return bool(url_pattern.search(text))


def has_invite(text: str) -> bool:
    """Check if text contains a Discord invite."""
    invite_pattern = re.compile(
        r'discord\.gg/[a-zA-Z0-9-]+'
        r'|discord\.com/invite/[a-zA-Z0-9-]+'
        r'|discordapp\.com/invite/[a-zA-Z0-9-]+'
    )
    return bool(invite_pattern.search(text))


def truncate(text: str, max_len: int = 1024) -> str:
    """Truncate text to max_len characters."""
    if len(text) <= max_len:
        return text
    return text[:max_len - 3] + '...'


def get_member_color(member: discord.Member) -> int:
    """Get member's top role color."""
    return member.color.value if member.color.value != 0 else 0x5865F2


def ordinal_arabic(n: int) -> str:
    """Return Arabic ordinal for number."""
    ordinals = {
        1: 'الأول', 2: 'الثاني', 3: 'الثالث', 4: 'الرابع', 5: 'الخامس',
        6: 'السادس', 7: 'السابع', 8: 'الثامن', 9: 'التاسع', 10: 'العاشر'
    }
    return ordinals.get(n, f'#{n}')
