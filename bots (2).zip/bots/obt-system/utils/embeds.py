"""
Embed Helpers - مساعدات الـ Embed
"""

import discord
from datetime import datetime


COLORS = {
    'success': 0x2ECC71,   # أخضر
    'error': 0xE74C3C,     # أحمر
    'warning': 0xF39C12,   # برتقالي
    'info': 0x3498DB,      # أزرق
    'primary': 0x5865F2,   # بنفسجي Discord
    'gold': 0xF1C40F,      # ذهبي
    'dark': 0x2C2F33,      # داكن
    'cyan': 0x1ABC9C,      # سماوي
}

BOT_NAME = 'OBT System'
BOT_EMOJI = '🛡️'


def success_embed(title: str, description: str = None, fields: list = None) -> discord.Embed:
    embed = discord.Embed(
        title=f'✅ {title}',
        description=description,
        color=COLORS['success'],
        timestamp=datetime.utcnow()
    )
    if fields:
        for name, value, inline in fields:
            embed.add_field(name=name, value=value, inline=inline)
    embed.set_footer(text=f'{BOT_EMOJI} {BOT_NAME}')
    return embed


def error_embed(title: str, description: str = None) -> discord.Embed:
    embed = discord.Embed(
        title=f'❌ {title}',
        description=description,
        color=COLORS['error'],
        timestamp=datetime.utcnow()
    )
    embed.set_footer(text=f'{BOT_EMOJI} {BOT_NAME}')
    return embed


def warning_embed(title: str, description: str = None) -> discord.Embed:
    embed = discord.Embed(
        title=f'⚠️ {title}',
        description=description,
        color=COLORS['warning'],
        timestamp=datetime.utcnow()
    )
    embed.set_footer(text=f'{BOT_EMOJI} {BOT_NAME}')
    return embed


def info_embed(title: str, description: str = None, fields: list = None, thumbnail: str = None) -> discord.Embed:
    embed = discord.Embed(
        title=f'ℹ️ {title}',
        description=description,
        color=COLORS['info'],
        timestamp=datetime.utcnow()
    )
    if fields:
        for name, value, inline in fields:
            embed.add_field(name=name, value=value, inline=inline)
    if thumbnail:
        embed.set_thumbnail(url=thumbnail)
    embed.set_footer(text=f'{BOT_EMOJI} {BOT_NAME}')
    return embed


def mod_embed(action: str, target: discord.Member, moderator: discord.Member,
              reason: str, color: int = None, extra_fields: list = None) -> discord.Embed:
    embed = discord.Embed(
        title=action,
        color=color or COLORS['primary'],
        timestamp=datetime.utcnow()
    )
    embed.add_field(name='👤 العضو', value=f'{target.mention} (`{target.id}`)', inline=True)
    embed.add_field(name='🛡️ المشرف', value=f'{moderator.mention}', inline=True)
    embed.add_field(name='📝 السبب', value=reason or 'لم يُذكر', inline=False)
    if extra_fields:
        for name, value, inline in extra_fields:
            embed.add_field(name=name, value=value, inline=inline)
    embed.set_thumbnail(url=target.display_avatar.url)
    embed.set_footer(text=f'{BOT_EMOJI} {BOT_NAME}')
    return embed


def log_embed(title: str, description: str = None, color: int = None,
              fields: list = None, author: discord.Member = None) -> discord.Embed:
    embed = discord.Embed(
        title=title,
        description=description,
        color=color or COLORS['dark'],
        timestamp=datetime.utcnow()
    )
    if fields:
        for name, value, inline in fields:
            embed.add_field(name=name, value=value, inline=inline)
    if author:
        embed.set_author(name=str(author), icon_url=author.display_avatar.url)
    embed.set_footer(text=f'{BOT_EMOJI} {BOT_NAME}')
    return embed


def leaderboard_embed(title: str, entries: list, guild: discord.Guild) -> discord.Embed:
    embed = discord.Embed(
        title=f'🏆 {title}',
        color=COLORS['gold'],
        timestamp=datetime.utcnow()
    )
    medals = ['🥇', '🥈', '🥉']
    desc = ''
    for i, (user_id, points) in enumerate(entries, 1):
        medal = medals[i - 1] if i <= 3 else f'`#{i}`'
        member = guild.get_member(user_id)
        name = member.display_name if member else f'<@{user_id}>'
        desc += f'{medal} **{name}** — {points:,} نقطة\n'
    embed.description = desc or 'لا يوجد أعضاء في لوحة المتصدرين بعد.'
    embed.set_footer(text=f'{BOT_EMOJI} {BOT_NAME}')
    return embed


def ticket_embed(ticket_number: int, user: discord.Member, department: str) -> discord.Embed:
    embed = discord.Embed(
        title=f'🎫 تذكرة #{ticket_number}',
        description=(
            f'مرحباً {user.mention}!\n\n'
            f'تم إنشاء تذكرتك في قسم **{department}**.\n'
            'سيتواصل معك فريق الدعم في أقرب وقت ممكن.\n\n'
            'للإغلاق: اضغط على زر **إغلاق** أو استخدم `/إغلاق_تذكرة`'
        ),
        color=COLORS['primary'],
        timestamp=datetime.utcnow()
    )
    embed.add_field(name='👤 العضو', value=f'{user.mention}', inline=True)
    embed.add_field(name='📂 القسم', value=department, inline=True)
    embed.set_thumbnail(url=user.display_avatar.url)
    embed.set_footer(text=f'{BOT_EMOJI} {BOT_NAME}')
    return embed
