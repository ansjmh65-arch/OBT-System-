"""
Clans Cog - نظام الكلانات
"""

import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime
from utils.embeds import success_embed, error_embed


class Clans(commands.Cog, name='الكلانات'):
    def __init__(self, bot):
        self.bot = bot
        self.db = bot.db

    # ── /إنشاء_كلان ───────────────────────────────────────────────────────────

    @app_commands.command(name='إنشاء_كلان', description='إنشاء كلان جديد')
    @app_commands.describe(الاسم='اسم الكلان', الوصف='وصف الكلان')
    async def create_clan(self, interaction: discord.Interaction, الاسم: str, الوصف: str = ''):
        # Check if user already in a clan
        existing = await self.db.get_user_clan(interaction.guild.id, interaction.user.id)
        if existing:
            return await interaction.response.send_message(
                embed=error_embed('خطأ', f'أنت بالفعل في كلان: **{existing["name"]}**'), ephemeral=True)

        # Check if clan name exists
        existing_clan = await self.db.get_clan(interaction.guild.id, name=الاسم)
        if existing_clan:
            return await interaction.response.send_message(
                embed=error_embed('خطأ', f'يوجد كلان بهذا الاسم بالفعل.'), ephemeral=True)

        if len(الاسم) > 30:
            return await interaction.response.send_message(
                embed=error_embed('خطأ', 'اسم الكلان يجب أن يكون أقل من 30 حرف.'), ephemeral=True)

        try:
            clan_id = await self.db.create_clan(interaction.guild.id, الاسم, interaction.user.id, الوصف)
            embed = success_embed(
                f'👑 تم إنشاء الكلان: {الاسم}',
                f'تم إنشاء الكلان بنجاح!\n**الوصف:** {الوصف or "لا يوجد وصف"}\n**المالك:** {interaction.user.mention}'
            )
            embed.color = 0xF1C40F
            await interaction.response.send_message(embed=embed)
        except Exception as e:
            await interaction.response.send_message(
                embed=error_embed('خطأ', f'فشل إنشاء الكلان: {str(e)}'), ephemeral=True)

    # ── /حذف_كلان ─────────────────────────────────────────────────────────────

    @app_commands.command(name='حذف_كلان', description='حذف كلانك')
    async def delete_clan(self, interaction: discord.Interaction):
        user_clan = await self.db.get_user_clan(interaction.guild.id, interaction.user.id)
        if not user_clan:
            return await interaction.response.send_message(
                embed=error_embed('خطأ', 'أنت لست في أي كلان.'), ephemeral=True)

        if user_clan['member_role'] != 'owner':
            return await interaction.response.send_message(
                embed=error_embed('خطأ', 'فقط مالك الكلان يمكنه حذفه.'), ephemeral=True)

        # Confirm deletion
        embed = discord.Embed(
            title='⚠️ تأكيد الحذف',
            description=f'هل أنت متأكد من حذف كلان **{user_clan["name"]}**؟\nهذا الإجراء لا يمكن التراجع عنه.',
            color=0xFF0000
        )
        view = ConfirmView()
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)
        await view.wait()

        if view.confirmed:
            await self.db.delete_clan(user_clan['id'])
            await interaction.edit_original_response(
                embed=success_embed('تم حذف الكلان', f'تم حذف كلان **{user_clan["name"]}** بنجاح.'),
                view=None)

    # ── /انضمام_كلان ──────────────────────────────────────────────────────────

    @app_commands.command(name='انضمام_كلان', description='الانضمام لكلان')
    @app_commands.describe(الاسم='اسم الكلان')
    async def join_clan(self, interaction: discord.Interaction, الاسم: str):
        existing = await self.db.get_user_clan(interaction.guild.id, interaction.user.id)
        if existing:
            return await interaction.response.send_message(
                embed=error_embed('خطأ', f'أنت بالفعل في كلان: **{existing["name"]}**'), ephemeral=True)

        clan = await self.db.get_clan(interaction.guild.id, name=الاسم)
        if not clan:
            return await interaction.response.send_message(
                embed=error_embed('خطأ', 'الكلان غير موجود.'), ephemeral=True)

        await self.db.add_clan_member(clan['id'], interaction.user.id)
        embed = success_embed('تم الانضمام', f'انضممت بنجاح إلى كلان **{clan["name"]}**!')
        await interaction.response.send_message(embed=embed)

    # ── /مغادرة_كلان ──────────────────────────────────────────────────────────

    @app_commands.command(name='مغادرة_كلان', description='مغادرة كلانك الحالي')
    async def leave_clan(self, interaction: discord.Interaction):
        user_clan = await self.db.get_user_clan(interaction.guild.id, interaction.user.id)
        if not user_clan:
            return await interaction.response.send_message(
                embed=error_embed('خطأ', 'أنت لست في أي كلان.'), ephemeral=True)

        if user_clan['member_role'] == 'owner':
            return await interaction.response.send_message(
                embed=error_embed('خطأ', 'لا يمكنك مغادرة الكلان كمالك. احذفه أو انقل الملكية أولاً.'),
                ephemeral=True)

        await self.db.remove_clan_member(user_clan['id'], interaction.user.id)
        embed = success_embed('تم المغادرة', f'غادرت كلان **{user_clan["name"]}**.')
        await interaction.response.send_message(embed=embed)

    # ── /معلومات_كلان ─────────────────────────────────────────────────────────

    @app_commands.command(name='معلومات_كلان', description='عرض معلومات كلان')
    @app_commands.describe(الاسم='اسم الكلان (اتركه فارغاً لعرض كلانك)')
    async def clan_info(self, interaction: discord.Interaction, الاسم: str = None):
        if الاسم:
            clan = await self.db.get_clan(interaction.guild.id, name=الاسم)
        else:
            user_clan = await self.db.get_user_clan(interaction.guild.id, interaction.user.id)
            clan = user_clan

        if not clan:
            return await interaction.response.send_message(
                embed=error_embed('خطأ', 'الكلان غير موجود.' if الاسم else 'أنت لست في أي كلان.'),
                ephemeral=True)

        members = await self.db.get_clan_members(clan['id'])
        owner = interaction.guild.get_member(clan['owner_id'])

        embed = discord.Embed(
            title=f'👑 {clan["name"]}',
            description=clan['description'] or '*لا يوجد وصف*',
            color=0xF1C40F,
            timestamp=datetime.utcnow()
        )
        embed.add_field(name='👤 المالك', value=owner.mention if owner else f"<@{clan['owner_id']}>", inline=True)
        embed.add_field(name='👥 الأعضاء', value=str(len(members)), inline=True)
        embed.add_field(name='⭐ النقاط', value=f'{clan["points"]:,}', inline=True)
        embed.add_field(name='📅 تاريخ الإنشاء', value=clan['created_at'][:10], inline=True)

        member_list = []
        for m in members[:5]:
            member = interaction.guild.get_member(m['user_id'])
            role_emoji = '👑' if m['role'] == 'owner' else '⚔️'
            uid = m['user_id']
            display = member.display_name if member else f'<@{uid}>'
            member_list.append(f'{role_emoji} {display}')
        if member_list:
            embed.add_field(name='📋 الأعضاء', value='\n'.join(member_list), inline=False)
        embed.set_footer(text='🛡️ OBT System')
        await interaction.response.send_message(embed=embed)

    # ── /ترتيب_الكلانات ───────────────────────────────────────────────────────

    @app_commands.command(name='ترتيب_الكلانات', description='عرض ترتيب الكلانات')
    async def clan_leaderboard(self, interaction: discord.Interaction):
        clans = await self.db.get_clan_leaderboard(interaction.guild.id)
        embed = discord.Embed(
            title='🏆 ترتيب الكلانات',
            color=0xF1C40F,
            timestamp=datetime.utcnow()
        )
        medals = ['🥇', '🥈', '🥉']
        desc = ''
        for i, clan in enumerate(clans, 1):
            medal = medals[i - 1] if i <= 3 else f'`#{i}`'
            desc += f'{medal} **{clan["name"]}** — {clan["points"]:,} نقطة\n'
        embed.description = desc or 'لا توجد كلانات بعد.'
        embed.set_footer(text='🛡️ OBT System')
        await interaction.response.send_message(embed=embed)

    # ── /نقاط_كلان ────────────────────────────────────────────────────────────

    @app_commands.command(name='نقاط_كلان', description='إضافة نقاط لكلان')
    @app_commands.describe(الاسم='اسم الكلان', كمية='كمية النقاط')
    @app_commands.checks.has_permissions(manage_guild=True)
    async def clan_points(self, interaction: discord.Interaction, الاسم: str, كمية: int):
        clan = await self.db.get_clan(interaction.guild.id, name=الاسم)
        if not clan:
            return await interaction.response.send_message(
                embed=error_embed('خطأ', 'الكلان غير موجود.'), ephemeral=True)

        await self.db.add_clan_points(clan['id'], كمية)
        embed = success_embed(
            'تمت إضافة النقاط',
            f'تمت إضافة **{كمية:,}** نقطة لكلان **{الاسم}**'
        )
        await interaction.response.send_message(embed=embed)

    # ── /تحدي ─────────────────────────────────────────────────────────────────

    challenges_group = app_commands.Group(name='تحديات', description='نظام تحديات الكلانات')

    @challenges_group.command(name='إضافة', description='إضافة تحدي جديد')
    @app_commands.describe(العنوان='عنوان التحدي', الوصف='وصف التحدي', النقاط='نقاط الجائزة')
    @app_commands.checks.has_permissions(manage_guild=True)
    async def add_challenge(self, interaction: discord.Interaction,
                            العنوان: str, الوصف: str, النقاط: int):
        await self.db._conn.execute(
            """INSERT INTO clan_challenges (guild_id, title, description, reward_points)
               VALUES (?, ?, ?, ?)""",
            (interaction.guild.id, العنوان, الوصف, النقاط)
        )
        await self.db._conn.commit()
        embed = success_embed('تم إضافة التحدي', f'**{العنوان}**\n{الوصف}\n🏆 الجائزة: {النقاط:,} نقطة')
        await interaction.response.send_message(embed=embed)

    @challenges_group.command(name='عرض', description='عرض التحديات النشطة')
    async def show_challenges(self, interaction: discord.Interaction):
        async with self.db._conn.execute(
            "SELECT * FROM clan_challenges WHERE guild_id = ? AND status = 'active'",
            (interaction.guild.id,)
        ) as cur:
            challenges = await cur.fetchall()

        embed = discord.Embed(title='⚔️ التحديات النشطة', color=0xFF6600, timestamp=datetime.utcnow())
        if not challenges:
            embed.description = 'لا توجد تحديات نشطة حالياً.'
        else:
            for ch in challenges:
                embed.add_field(
                    name=f'⚔️ {ch["title"]}',
                    value=f'{ch["description"]}\n🏆 الجائزة: **{ch["reward_points"]:,} نقطة**',
                    inline=False
                )
        embed.set_footer(text='🛡️ OBT System')
        await interaction.response.send_message(embed=embed)


class ConfirmView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=30)
        self.confirmed = False

    @discord.ui.button(label='تأكيد', style=discord.ButtonStyle.danger, emoji='✅')
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.confirmed = True
        await interaction.response.defer()
        self.stop()

    @discord.ui.button(label='إلغاء', style=discord.ButtonStyle.secondary, emoji='❌')
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.confirmed = False
        await interaction.response.defer()
        self.stop()


async def setup(bot):
    await bot.add_cog(Clans(bot))
