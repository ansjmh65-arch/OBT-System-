"""
General Cog - نظام الأوامر العامة
"""

import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime
import platform
from utils.embeds import info_embed, success_embed, error_embed


class General(commands.Cog, name='عام'):
    def __init__(self, bot):
        self.bot = bot
        self.db = bot.db

    # ── /معلومات_عضو ──────────────────────────────────────────────────────────

    @app_commands.command(name='معلومات_عضو', description='عرض معلومات عضو')
    @app_commands.describe(عضو='العضو المراد عرض معلوماته')
    async def member_info(self, interaction: discord.Interaction, عضو: discord.Member = None):
        target = عضو or interaction.user
        embed = discord.Embed(
            title=f'👤 معلومات العضو — {target.display_name}',
            color=target.color.value or 0x5865F2,
            timestamp=datetime.utcnow()
        )
        embed.set_thumbnail(url=target.display_avatar.url)

        # Basic info
        embed.add_field(name='🔖 اسم المستخدم', value=str(target), inline=True)
        embed.add_field(name='🆔 المعرف', value=str(target.id), inline=True)
        embed.add_field(name='🤖 بوت؟', value='نعم' if target.bot else 'لا', inline=True)

        # Dates
        embed.add_field(name='📅 تاريخ الإنشاء', value=discord.utils.format_dt(target.created_at, 'F'), inline=False)
        if target.joined_at:
            embed.add_field(name='📥 تاريخ الانضمام', value=discord.utils.format_dt(target.joined_at, 'F'), inline=False)

        # Status
        status_map = {
            discord.Status.online: '🟢 متصل',
            discord.Status.idle: '🟡 خامل',
            discord.Status.dnd: '🔴 انتبه',
            discord.Status.offline: '⚫ غير متصل'
        }
        embed.add_field(name='🔌 الحالة', value=status_map.get(target.status, '⚫ غير متصل'), inline=True)

        # Roles
        roles = [r.mention for r in reversed(target.roles) if r.name != '@everyone']
        if roles:
            embed.add_field(name=f'🎖️ الرتب ({len(roles)})', value=' '.join(roles[:10]), inline=False)

        # Points
        points = await self.db.get_points(interaction.guild.id, target.id, 'member')
        embed.add_field(name='⭐ النقاط', value=f'{points:,}', inline=True)

        # Warnings
        warn_count = await self.db.get_warning_count(interaction.guild.id, target.id)
        embed.add_field(name='⚠️ التحذيرات', value=str(warn_count), inline=True)

        embed.set_footer(text='🛡️ OBT System')
        await interaction.response.send_message(embed=embed)

    # ── /معلومات_سيرفر ────────────────────────────────────────────────────────

    @app_commands.command(name='معلومات_سيرفر', description='عرض معلومات السيرفر')
    async def server_info(self, interaction: discord.Interaction):
        guild = interaction.guild
        embed = discord.Embed(
            title=f'🏠 معلومات السيرفر — {guild.name}',
            color=0x5865F2,
            timestamp=datetime.utcnow()
        )
        if guild.icon:
            embed.set_thumbnail(url=guild.icon.url)

        embed.add_field(name='🆔 المعرف', value=str(guild.id), inline=True)
        embed.add_field(name='👑 المالك', value=guild.owner.mention if guild.owner else 'غير معروف', inline=True)
        embed.add_field(name='📅 تاريخ الإنشاء', value=discord.utils.format_dt(guild.created_at, 'F'), inline=False)

        # Members
        bots = sum(1 for m in guild.members if m.bot)
        humans = guild.member_count - bots
        embed.add_field(name='👥 الأعضاء', value=f'إجمالي: {guild.member_count}\n👤 بشر: {humans}\n🤖 بوتات: {bots}', inline=True)

        # Channels
        text_ch = len(guild.text_channels)
        voice_ch = len(guild.voice_channels)
        embed.add_field(name='📋 الرومات', value=f'📝 نصية: {text_ch}\n🔊 صوتية: {voice_ch}', inline=True)

        # Roles
        embed.add_field(name='🎖️ الرتب', value=str(len(guild.roles)), inline=True)

        # Boosts
        embed.add_field(name='💎 البوستات', value=f'{guild.premium_subscription_count} بوست | المستوى {guild.premium_tier}', inline=True)

        # Verification
        verify_map = {
            discord.VerificationLevel.none: 'بدون',
            discord.VerificationLevel.low: 'منخفض',
            discord.VerificationLevel.medium: 'متوسط',
            discord.VerificationLevel.high: 'عالي',
            discord.VerificationLevel.highest: 'أعلى'
        }
        embed.add_field(name='🔒 التحقق', value=verify_map.get(guild.verification_level, 'غير معروف'), inline=True)

        embed.set_footer(text='🛡️ OBT System')
        await interaction.response.send_message(embed=embed)

    # ── /معلومات_رتبة ─────────────────────────────────────────────────────────

    @app_commands.command(name='معلومات_رتبة', description='عرض معلومات رتبة')
    @app_commands.describe(رتبة='الرتبة المراد عرض معلوماتها')
    async def role_info(self, interaction: discord.Interaction, رتبة: discord.Role):
        embed = discord.Embed(
            title=f'🎖️ معلومات الرتبة — {رتبة.name}',
            color=رتبة.color.value or 0x5865F2,
            timestamp=datetime.utcnow()
        )
        embed.add_field(name='🆔 المعرف', value=str(رتبة.id), inline=True)
        embed.add_field(name='🎨 اللون', value=str(رتبة.color), inline=True)
        embed.add_field(name='👥 عدد الأعضاء', value=str(len(رتبة.members)), inline=True)
        embed.add_field(name='📌 مثبتة', value='نعم' if رتبة.hoist else 'لا', inline=True)
        embed.add_field(name='💫 قابلة للإشارة', value='نعم' if رتبة.mentionable else 'لا', inline=True)
        embed.add_field(name='🤖 للبوتات', value='نعم' if رتبة.managed else 'لا', inline=True)
        embed.add_field(name='📅 تاريخ الإنشاء', value=discord.utils.format_dt(رتبة.created_at, 'F'), inline=False)
        embed.set_footer(text='🛡️ OBT System')
        await interaction.response.send_message(embed=embed)

    # ── /معلومات_روم ──────────────────────────────────────────────────────────

    @app_commands.command(name='معلومات_روم', description='عرض معلومات روم')
    @app_commands.describe(روم='الروم المراد عرض معلوماته')
    async def channel_info(self, interaction: discord.Interaction,
                           روم: discord.TextChannel = None):
        channel = روم or interaction.channel
        embed = discord.Embed(
            title=f'📋 معلومات الروم — {channel.name}',
            color=0x5865F2,
            timestamp=datetime.utcnow()
        )
        embed.add_field(name='🆔 المعرف', value=str(channel.id), inline=True)
        embed.add_field(name='📂 الفئة', value=channel.category.name if channel.category else 'بدون فئة', inline=True)
        embed.add_field(name='🔒 خاص', value='نعم' if channel.overwrites else 'لا', inline=True)
        if hasattr(channel, 'topic') and channel.topic:
            embed.add_field(name='📝 الوصف', value=channel.topic[:200], inline=False)
        if hasattr(channel, 'slowmode_delay'):
            embed.add_field(name='🐌 وضع التباطؤ', value=f'{channel.slowmode_delay} ثانية', inline=True)
        embed.add_field(name='📅 تاريخ الإنشاء', value=discord.utils.format_dt(channel.created_at, 'F'), inline=False)
        embed.set_footer(text='🛡️ OBT System')
        await interaction.response.send_message(embed=embed)

    # ── /أفاتار ───────────────────────────────────────────────────────────────

    @app_commands.command(name='أفاتار', description='عرض صورة عضو')
    @app_commands.describe(عضو='العضو المراد عرض صورته')
    async def avatar(self, interaction: discord.Interaction, عضو: discord.Member = None):
        target = عضو or interaction.user
        embed = discord.Embed(
            title=f'🖼️ صورة {target.display_name}',
            color=target.color.value or 0x5865F2
        )
        embed.set_image(url=target.display_avatar.url)
        embed.add_field(name='🔗 الرابط',
                        value=f'[PNG]({target.display_avatar.with_format("png").url}) | '
                              f'[JPG]({target.display_avatar.with_format("jpg").url}) | '
                              f'[WebP]({target.display_avatar.url})',
                        inline=False)
        embed.set_footer(text='🛡️ OBT System')
        await interaction.response.send_message(embed=embed)

    # ── /بانر ─────────────────────────────────────────────────────────────────

    @app_commands.command(name='بانر', description='عرض بانر عضو')
    @app_commands.describe(عضو='العضو المراد عرض بانره')
    async def banner(self, interaction: discord.Interaction, عضو: discord.Member = None):
        target = عضو or interaction.user
        user = await self.bot.fetch_user(target.id)
        if not user.banner:
            return await interaction.response.send_message(
                embed=error_embed('لا يوجد بانر', f'{target.mention} لا يملك بانر.'), ephemeral=True)

        embed = discord.Embed(title=f'🖼️ بانر {target.display_name}', color=target.color.value or 0x5865F2)
        embed.set_image(url=user.banner.url)
        embed.set_footer(text='🛡️ OBT System')
        await interaction.response.send_message(embed=embed)

    # ── /بينق ─────────────────────────────────────────────────────────────────

    @app_commands.command(name='بينق', description='عرض تأخير البوت')
    async def ping(self, interaction: discord.Interaction):
        latency = round(self.bot.latency * 1000)
        color = 0x2ECC71 if latency < 100 else 0xF39C12 if latency < 200 else 0xE74C3C
        emoji = '🟢' if latency < 100 else '🟡' if latency < 200 else '🔴'
        embed = discord.Embed(
            title=f'{emoji} البينق',
            description=f'⏱️ **الاستجابة:** `{latency}ms`\n🌐 **WebSocket:** `{round(self.bot.latency * 1000)}ms`',
            color=color
        )
        embed.set_footer(text='🛡️ OBT System')
        await interaction.response.send_message(embed=embed)

    # ── /مساعدة ───────────────────────────────────────────────────────────────

    @app_commands.command(name='مساعدة', description='عرض قائمة الأوامر')
    async def help(self, interaction: discord.Interaction):
        embed = discord.Embed(
            title='🛡️ OBT System — قائمة الأوامر',
            description='مرحباً! إليك قائمة بأنظمة البوت:',
            color=0x5865F2,
            timestamp=datetime.utcnow()
        )
        sections = [
            ('🛡️ الإدارة', '/حظر /طرد /كتم /فك_كتم /تحذير /التحذيرات /إزالة_تحذير /مسح /قفل /فتح /إضافة_رتبة /إزالة_رتبة /فك_حظر /سجل_الإجراءات'),
            ('🔒 الحماية', '/حماية عرض /حماية تفعيل /حماية إضافة_whitelist'),
            ('🎫 التذاكر', '/تذاكر لوحة /تذاكر إغلاق /تذاكر إحصائيات /تذاكر إعداد'),
            ('⭐ النقاط', '/نقاط /إضافة_نقاط /خصم_نقاط /المتصدرين /مكافآت إضافة /مكافآت عرض'),
            ('👑 الكلانات', '/إنشاء_كلان /حذف_كلان /انضمام_كلان /مغادرة_كلان /معلومات_كلان /ترتيب_الكلانات /نقاط_كلان /تحديات إضافة /تحديات عرض'),
            ('🎥 صناع المحتوى', '/صناع ربط /صناع إلغاء_الربط /صناع قائمة /صناع فحص'),
            ('💬 التفاعل', '/إعداد_ترحيب /إعداد_وداع /إعداد_تحقق /رتبة_تلقائية /رتبة_تفاعلية'),
            ('⚙️ الإعدادات', '/إعدادات عرض /إعدادات لوق /إعدادات بريفكس /إعدادات عداد_أعضاء'),
            ('ℹ️ عام', '/معلومات_عضو /معلومات_سيرفر /معلومات_رتبة /معلومات_روم /أفاتار /بانر /بينق /اقتراح /بلاغ /تصويت'),
        ]
        for name, cmds in sections:
            embed.add_field(name=name, value=f'```{cmds}```', inline=False)
        embed.set_footer(text='🛡️ OBT System | بوت عربي متكامل')
        await interaction.response.send_message(embed=embed)

    # ── /اقتراح ───────────────────────────────────────────────────────────────

    @app_commands.command(name='اقتراح', description='إرسال اقتراح')
    @app_commands.describe(الاقتراح='اقتراحك')
    async def suggest(self, interaction: discord.Interaction, الاقتراح: str):
        guild_data = await self.db.get_guild(interaction.guild.id)
        suggest_channel_id = guild_data.get('log_channel') if guild_data else None

        embed = discord.Embed(
            title='💡 اقتراح جديد',
            description=الاقتراح,
            color=0x3498DB,
            timestamp=datetime.utcnow()
        )
        embed.set_author(name=str(interaction.user), icon_url=interaction.user.display_avatar.url)
        embed.set_footer(text=f'🆔 {interaction.user.id}')

        # Send to suggestion channel or current channel
        target_channel = interaction.guild.get_channel(suggest_channel_id) if suggest_channel_id else interaction.channel
        if not target_channel:
            target_channel = interaction.channel

        msg = await target_channel.send(embed=embed)
        await msg.add_reaction('👍')
        await msg.add_reaction('👎')

        await self.db.add_suggestion(
            interaction.guild.id, interaction.user.id, msg.id, target_channel.id, الاقتراح)

        await interaction.response.send_message(
            embed=success_embed('تم إرسال الاقتراح', f'تم إرسال اقتراحك بنجاح!'), ephemeral=True)

    # ── /بلاغ ─────────────────────────────────────────────────────────────────

    @app_commands.command(name='بلاغ', description='الإبلاغ عن عضو')
    @app_commands.describe(عضو='العضو المُبلَّغ عنه', السبب='سبب البلاغ')
    async def report(self, interaction: discord.Interaction, عضو: discord.Member, السبب: str):
        if عضو.id == interaction.user.id:
            return await interaction.response.send_message(
                embed=error_embed('خطأ', 'لا يمكنك الإبلاغ عن نفسك.'), ephemeral=True)

        await self.db._conn.execute(
            "INSERT INTO reports (guild_id, reporter_id, reported_id, reason) VALUES (?, ?, ?, ?)",
            (interaction.guild.id, interaction.user.id, عضو.id, السبب)
        )
        await self.db._conn.commit()

        embed = discord.Embed(
            title='🚨 بلاغ جديد',
            color=0xFF0000,
            timestamp=datetime.utcnow()
        )
        embed.add_field(name='📢 المُبلِّغ', value=f'{interaction.user.mention}', inline=True)
        embed.add_field(name='🎯 المُبلَّغ عنه', value=f'{عضو.mention}', inline=True)
        embed.add_field(name='📝 السبب', value=السبب, inline=False)
        embed.set_footer(text='🛡️ OBT System')

        guild_data = await self.db.get_guild(interaction.guild.id)
        log_ch = interaction.guild.get_channel(guild_data['log_channel']) if guild_data and guild_data['log_channel'] else None
        if log_ch:
            await log_ch.send(embed=embed)

        await interaction.response.send_message(
            embed=success_embed('تم الإبلاغ', 'تم إرسال بلاغك للمشرفين.'), ephemeral=True)

    # ── /تصويت ────────────────────────────────────────────────────────────────

    @app_commands.command(name='تصويت', description='إنشاء تصويت')
    @app_commands.describe(السؤال='سؤال التصويت')
    async def vote(self, interaction: discord.Interaction, السؤال: str):
        embed = discord.Embed(
            title=f'📊 {السؤال}',
            color=0x5865F2,
            timestamp=datetime.utcnow()
        )
        embed.set_author(name=str(interaction.user), icon_url=interaction.user.display_avatar.url)
        embed.set_footer(text='🛡️ OBT System | صوّت الآن!')

        await interaction.response.send_message(embed=embed)
        msg = await interaction.original_response()
        await msg.add_reaction('👍')
        await msg.add_reaction('👎')


async def setup(bot):
    await bot.add_cog(General(bot))
