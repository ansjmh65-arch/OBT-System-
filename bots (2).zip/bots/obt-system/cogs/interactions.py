"""
Interactions Cog - نظام التفاعل (ترحيب، وداع، تحقق، رتب)
"""

import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime
from utils.embeds import success_embed, error_embed


class Interactions(commands.Cog, name='التفاعل'):
    def __init__(self, bot):
        self.bot = bot
        self.db = bot.db

    # ── Welcome / Goodbye Events ───────────────────────────────────────────────

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        guild_data = await self.db.get_guild(member.guild.id)
        if not guild_data:
            return

        # Welcome message
        if guild_data['welcome_channel']:
            channel = member.guild.get_channel(guild_data['welcome_channel'])
            if channel:
                msg = guild_data['welcome_message'] or '🎉 مرحباً {mention} في **{server}**!'
                msg = msg.replace('{mention}', member.mention) \
                         .replace('{name}', member.display_name) \
                         .replace('{server}', member.guild.name) \
                         .replace('{count}', str(member.guild.member_count))

                embed = discord.Embed(
                    title='👋 عضو جديد!',
                    description=msg,
                    color=0x2ECC71,
                    timestamp=datetime.utcnow()
                )
                embed.set_thumbnail(url=member.display_avatar.url)
                embed.add_field(name='📅 الحساب', value=discord.utils.format_dt(member.created_at, 'R'), inline=True)
                embed.add_field(name='👥 العضو رقم', value=str(member.guild.member_count), inline=True)
                embed.set_footer(text='🛡️ OBT System')
                try:
                    await channel.send(embed=embed)
                except Exception:
                    pass

        # Auto role
        if guild_data['auto_role']:
            role = member.guild.get_role(guild_data['auto_role'])
            if role:
                try:
                    await member.add_roles(role, reason='رتبة تلقائية عند الانضمام')
                except Exception:
                    pass

        # Update member counter
        await self._update_counters(member.guild)

    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member):
        guild_data = await self.db.get_guild(member.guild.id)
        if not guild_data:
            return

        # Goodbye message
        if guild_data['goodbye_channel']:
            channel = member.guild.get_channel(guild_data['goodbye_channel'])
            if channel:
                msg = guild_data['goodbye_message'] or '😢 وداعاً **{name}**! نتمنى رؤيتك مرة أخرى.'
                msg = msg.replace('{mention}', member.mention) \
                         .replace('{name}', member.display_name) \
                         .replace('{server}', member.guild.name) \
                         .replace('{count}', str(member.guild.member_count))

                embed = discord.Embed(
                    title='👋 عضو غادر',
                    description=msg,
                    color=0xE74C3C,
                    timestamp=datetime.utcnow()
                )
                embed.set_thumbnail(url=member.display_avatar.url)
                embed.set_footer(text='🛡️ OBT System')
                try:
                    await channel.send(embed=embed)
                except Exception:
                    pass

        # Update member counter
        await self._update_counters(member.guild)

    async def _update_counters(self, guild: discord.Guild):
        """Update member/bot counter channels."""
        guild_data = await self.db.get_guild(guild.id)
        if not guild_data:
            return

        total = guild.member_count
        bots = sum(1 for m in guild.members if m.bot)
        humans = total - bots

        if guild_data['member_counter_channel']:
            ch = guild.get_channel(guild_data['member_counter_channel'])
            if ch:
                try:
                    await ch.edit(name=f'👥 الأعضاء: {humans}')
                except Exception:
                    pass

        if guild_data['bot_counter_channel']:
            ch = guild.get_channel(guild_data['bot_counter_channel'])
            if ch:
                try:
                    await ch.edit(name=f'🤖 البوتات: {bots}')
                except Exception:
                    pass

    # ── Reaction Roles ─────────────────────────────────────────────────────────

    @commands.Cog.listener()
    async def on_raw_reaction_add(self, payload: discord.RawReactionActionEvent):
        if not payload.guild_id or payload.user_id == self.bot.user.id:
            return

        rr = await self.db.get_reaction_role(payload.message_id, str(payload.emoji))
        if not rr:
            return

        guild = self.bot.get_guild(payload.guild_id)
        if not guild:
            return
        member = guild.get_member(payload.user_id)
        role = guild.get_role(rr['role_id'])
        if member and role:
            try:
                await member.add_roles(role, reason='رتبة تفاعلية')
            except Exception:
                pass

    @commands.Cog.listener()
    async def on_raw_reaction_remove(self, payload: discord.RawReactionActionEvent):
        if not payload.guild_id or payload.user_id == self.bot.user.id:
            return

        rr = await self.db.get_reaction_role(payload.message_id, str(payload.emoji))
        if not rr:
            return

        guild = self.bot.get_guild(payload.guild_id)
        if not guild:
            return
        member = guild.get_member(payload.user_id)
        role = guild.get_role(rr['role_id'])
        if member and role:
            try:
                await member.remove_roles(role, reason='إزالة رتبة تفاعلية')
            except Exception:
                pass

    # ── Verification ───────────────────────────────────────────────────────────

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if not message.guild or message.author.bot:
            return

        guild_data = await self.db.get_guild(message.guild.id)
        if not guild_data:
            return

        # Verify channel check
        if (guild_data['verify_channel'] and
                message.channel.id == guild_data['verify_channel'] and
                guild_data['verify_role']):
            role = message.guild.get_role(guild_data['verify_role'])
            if role and role not in message.author.roles:
                try:
                    await message.author.add_roles(role, reason='تحقق تلقائي')
                    try:
                        await message.delete()
                    except Exception:
                        pass
                    verify_embed = discord.Embed(
                        description=f'✅ {message.author.mention} تم التحقق منك بنجاح!',
                        color=0x2ECC71
                    )
                    msg = await message.channel.send(embed=verify_embed)
                    import asyncio
                    await asyncio.sleep(5)
                    await msg.delete()
                except Exception:
                    pass

    # ── Setup Commands ─────────────────────────────────────────────────────────

    @app_commands.command(name='إعداد_ترحيب', description='إعداد رسالة الترحيب')
    @app_commands.describe(
        روم='روم الترحيب',
        رسالة='رسالة الترحيب (يمكن استخدام {mention} {name} {server} {count})'
    )
    @app_commands.checks.has_permissions(manage_guild=True)
    async def setup_welcome(self, interaction: discord.Interaction,
                            روم: discord.TextChannel, رسالة: str = None):
        await self.db.update_guild(interaction.guild.id,
                                   welcome_channel=روم.id,
                                   welcome_message=رسالة)
        embed = success_embed(
            'تم إعداد الترحيب',
            f'سيتم إرسال رسائل الترحيب في {روم.mention}\n'
            f'**متغيرات:** `{{mention}}` `{{name}}` `{{server}}` `{{count}}`'
        )
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name='إعداد_وداع', description='إعداد رسالة الوداع')
    @app_commands.describe(روم='روم الوداع', رسالة='رسالة الوداع')
    @app_commands.checks.has_permissions(manage_guild=True)
    async def setup_goodbye(self, interaction: discord.Interaction,
                            روم: discord.TextChannel, رسالة: str = None):
        await self.db.update_guild(interaction.guild.id,
                                   goodbye_channel=روم.id,
                                   goodbye_message=رسالة)
        embed = success_embed('تم إعداد الوداع', f'سيتم إرسال رسائل الوداع في {روم.mention}')
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name='إعداد_تحقق', description='إعداد نظام التحقق التلقائي')
    @app_commands.describe(روم='روم التحقق', رتبة='الرتبة الممنوحة بعد التحقق')
    @app_commands.checks.has_permissions(manage_guild=True)
    async def setup_verify(self, interaction: discord.Interaction,
                           روم: discord.TextChannel, رتبة: discord.Role):
        await self.db.update_guild(interaction.guild.id,
                                   verify_channel=روم.id,
                                   verify_role=رتبة.id)

        embed_info = discord.Embed(
            title='✅ نظام التحقق',
            description='اكتب أي شيء في هذا الروم للتحقق والحصول على الرتبة.',
            color=0x2ECC71
        )
        await روم.send(embed=embed_info)

        embed = success_embed('تم إعداد التحقق',
                              f'روم التحقق: {روم.mention}\nرتبة التحقق: {رتبة.mention}')
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name='رتبة_تلقائية', description='تعيين رتبة تلقائية عند الانضمام')
    @app_commands.describe(رتبة='الرتبة الممنوحة تلقائياً')
    @app_commands.checks.has_permissions(manage_guild=True)
    async def auto_role(self, interaction: discord.Interaction, رتبة: discord.Role = None):
        await self.db.update_guild(interaction.guild.id, auto_role=رتبة.id if رتبة else None)
        if رتبة:
            embed = success_embed('تم تعيين الرتبة التلقائية',
                                  f'سيحصل الأعضاء الجدد على {رتبة.mention} تلقائياً.')
        else:
            embed = success_embed('تم إلغاء الرتبة التلقائية', 'لن يحصل الأعضاء الجدد على رتبة تلقائية.')
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name='رتبة_تفاعلية', description='إضافة رتبة تفاعلية لرسالة')
    @app_commands.describe(معرف_الرسالة='معرف الرسالة', إيموجي='الإيموجي', رتبة='الرتبة')
    @app_commands.checks.has_permissions(manage_roles=True)
    async def reaction_role(self, interaction: discord.Interaction,
                            معرف_الرسالة: str, إيموجي: str, رتبة: discord.Role):
        try:
            msg_id = int(معرف_الرسالة)
        except ValueError:
            return await interaction.response.send_message(
                embed=error_embed('خطأ', 'معرف الرسالة غير صحيح.'), ephemeral=True)

        await self.db.add_reaction_role(interaction.guild.id, msg_id, إيموجي, رتبة.id)

        # Try to add the reaction to the message
        for channel in interaction.guild.text_channels:
            try:
                msg = await channel.fetch_message(msg_id)
                await msg.add_reaction(إيموجي)
                break
            except Exception:
                continue

        embed = success_embed(
            'تمت إضافة الرتبة التفاعلية',
            f'الإيموجي {إيموجي} → {رتبة.mention}\nعلى الرسالة `{msg_id}`'
        )
        await interaction.response.send_message(embed=embed)


async def setup(bot):
    await bot.add_cog(Interactions(bot))
