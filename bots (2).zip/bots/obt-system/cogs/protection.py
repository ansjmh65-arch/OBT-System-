"""
Protection Cog - نظام الحماية التلقائية
Includes: Anti-Spam, Anti-Links, Anti-Invites, Anti-Mention, Anti-Bots,
          Anti-Channel/Role Create/Delete, Bad Words Filter
"""

import discord
from discord import app_commands
from discord.ext import commands, tasks
import asyncio
import json
import re
from datetime import datetime, timedelta
from collections import defaultdict
from utils.embeds import success_embed, error_embed, warning_embed


class Protection(commands.Cog, name='الحماية'):
    def __init__(self, bot):
        self.bot = bot
        self.db = bot.db
        # In-memory spam tracking: {guild_id: {user_id: [timestamps]}}
        self.spam_data = defaultdict(lambda: defaultdict(list))
        # Bad words cache: {guild_id: set(words)}
        self._bad_words_cache: dict = {}
        self.cleanup_spam.start()

    def cog_unload(self):
        self.cleanup_spam.cancel()

    @tasks.loop(minutes=2)
    async def cleanup_spam(self):
        cutoff = datetime.utcnow() - timedelta(seconds=10)
        for guild_id in list(self.spam_data.keys()):
            for user_id in list(self.spam_data[guild_id].keys()):
                self.spam_data[guild_id][user_id] = [
                    t for t in self.spam_data[guild_id][user_id] if t > cutoff
                ]

    async def get_bad_words(self, guild_id: int) -> set:
        """Get cached bad words set for a guild."""
        if guild_id not in self._bad_words_cache:
            words = await self.db.get_bad_words(guild_id)
            self._bad_words_cache[guild_id] = set(words)
        return self._bad_words_cache[guild_id]

    def invalidate_bad_words_cache(self, guild_id: int):
        self._bad_words_cache.pop(guild_id, None)

    async def is_whitelisted(self, guild_id: int, member: discord.Member) -> bool:
        if member.guild_permissions.administrator:
            return True
        protection = await self.db.get_protection(guild_id)
        if not protection:
            return True
        try:
            whitelist_roles = json.loads(protection['whitelist_roles'] or '[]')
            member_role_ids = [r.id for r in member.roles]
            return any(r in member_role_ids for r in whitelist_roles)
        except Exception:
            return False

    async def get_log_channel(self, guild: discord.Guild):
        guild_data = await self.db.get_guild(guild.id)
        if guild_data and guild_data['log_channel']:
            return guild.get_channel(guild_data['log_channel'])
        return None

    async def send_protection_log(self, guild: discord.Guild, action: str,
                                   member: discord.Member, reason: str):
        channel = await self.get_log_channel(guild)
        if not channel:
            return
        embed = discord.Embed(
            title=f'🛡️ نظام الحماية — {action}',
            color=0xFF6600,
            timestamp=datetime.utcnow()
        )
        embed.add_field(name='👤 العضو', value=f'{member.mention} (`{member.id}`)', inline=True)
        embed.add_field(name='📝 السبب', value=reason, inline=True)
        embed.set_footer(text='🛡️ OBT System')
        await channel.send(embed=embed)

    # ── Anti-Spam ──────────────────────────────────────────────────────────────

    async def check_spam(self, message: discord.Message, protection) -> bool:
        if not protection['anti_spam']:
            return False
        limit = protection['spam_limit'] or 5
        now = datetime.utcnow()
        user_msgs = self.spam_data[message.guild.id][message.author.id]
        user_msgs.append(now)
        cutoff = now - timedelta(seconds=5)
        self.spam_data[message.guild.id][message.author.id] = [t for t in user_msgs if t > cutoff]
        if len(self.spam_data[message.guild.id][message.author.id]) >= limit:
            self.spam_data[message.guild.id][message.author.id] = []
            return True
        return False

    # ── Bad Words ──────────────────────────────────────────────────────────────

    async def check_bad_words(self, message: discord.Message, protection) -> bool:
        if not protection.get('anti_bad_words', 0):
            return False
        bad_words = await self.get_bad_words(message.guild.id)
        if not bad_words:
            return False
        content_lower = message.content.lower()
        for word in bad_words:
            # Match whole word or partial
            if word in content_lower:
                return True
        return False

    # ── Main Message Handler ───────────────────────────────────────────────────

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if not message.guild or message.author.bot:
            return
        if not isinstance(message.author, discord.Member):
            return

        if await self.is_whitelisted(message.guild.id, message.author):
            return

        protection = await self.db.get_protection(message.guild.id)
        if not protection:
            return

        reasons = []

        # Anti-spam
        if await self.check_spam(message, protection):
            reasons.append('سبام')

        # Anti-links
        if protection['anti_links']:
            url_pattern = re.compile(r'https?://|www\.')
            if url_pattern.search(message.content):
                reasons.append('رابط غير مسموح')

        # Anti-invites
        if protection['anti_invites']:
            if 'discord.gg/' in message.content or 'discord.com/invite/' in message.content:
                reasons.append('دعوة Discord')

        # Anti-mass mention
        if protection['anti_mention']:
            limit = protection['mention_limit'] or 5
            if len(message.mentions) >= limit or len(message.role_mentions) >= limit:
                reasons.append(f'منشن جماعي ({len(message.mentions)} منشن)')

        # Bad words
        if await self.check_bad_words(message, protection):
            reasons.append('كلمات محظورة')

        if not reasons:
            return

        reason_str = ' | '.join(reasons)

        # Delete the message
        try:
            await message.delete()
        except Exception:
            pass

        # Send warning
        try:
            warn_embed = discord.Embed(
                description=f'⚠️ {message.author.mention} تم حذف رسالتك بسبب: **{reason_str}**',
                color=0xFF6600
            )
            msg = await message.channel.send(embed=warn_embed)
            await asyncio.sleep(5)
            await msg.delete()
        except Exception:
            pass

        # Auto-warn
        warn_count = await self.db.add_warning(
            message.guild.id, message.author.id, self.bot.user.id,
            f'نظام الحماية: {reason_str}'
        )
        warn_limit = protection['warn_limit'] or 3
        if warn_count >= warn_limit:
            action = protection['warn_action'] or 'mute'
            await self._auto_action(message.guild, message.author, action, warn_count)

        await self.send_protection_log(
            message.guild, reason_str, message.author,
            f'تحذير #{warn_count}/{warn_limit}'
        )

    async def _auto_action(self, guild, member, action, warn_count):
        reason = f'نظام الحماية التلقائي — {warn_count} تحذيرات'
        try:
            if action == 'mute':
                until = discord.utils.utcnow() + timedelta(hours=1)
                await member.timeout(until, reason=reason)
            elif action == 'kick':
                await member.kick(reason=reason)
            elif action == 'ban':
                await member.ban(reason=reason)
        except Exception:
            pass

    # ── Anti-Bot ───────────────────────────────────────────────────────────────

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        if not member.bot:
            return
        protection = await self.db.get_protection(member.guild.id)
        if not protection or not protection['anti_bots']:
            return
        try:
            await member.kick(reason='نظام الحماية: منع البوتات')
            await self.send_protection_log(member.guild, 'طرد بوت', member, 'منع البوتات تلقائياً')
        except Exception:
            pass

    # ── Anti-Channel Create/Delete ─────────────────────────────────────────────

    @commands.Cog.listener()
    async def on_guild_channel_create(self, channel: discord.abc.GuildChannel):
        protection = await self.db.get_protection(channel.guild.id)
        if not protection or not protection['anti_channel_create']:
            return
        try:
            async for entry in channel.guild.audit_logs(limit=1, action=discord.AuditLogAction.channel_create):
                if not entry.user.bot and not entry.user.guild_permissions.administrator:
                    if not await self.is_whitelisted(channel.guild.id, entry.user):
                        await channel.delete(reason='نظام الحماية: منع إنشاء الرومات')
                        await self.send_protection_log(channel.guild, 'حذف روم تلقائي',
                                                       entry.user, 'محاولة إنشاء روم')
        except Exception:
            pass

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel: discord.abc.GuildChannel):
        protection = await self.db.get_protection(channel.guild.id)
        if not protection or not protection['anti_channel_delete']:
            return
        try:
            async for entry in channel.guild.audit_logs(limit=1, action=discord.AuditLogAction.channel_delete):
                if not entry.user.bot and not entry.user.guild_permissions.administrator:
                    if not await self.is_whitelisted(channel.guild.id, entry.user):
                        await self.send_protection_log(channel.guild, 'تحذير حذف روم',
                                                       entry.user, f'حذف روم: {channel.name}')
        except Exception:
            pass

    # ── Anti-Role Create/Delete ────────────────────────────────────────────────

    @commands.Cog.listener()
    async def on_guild_role_create(self, role: discord.Role):
        protection = await self.db.get_protection(role.guild.id)
        if not protection or not protection['anti_role_create']:
            return
        try:
            async for entry in role.guild.audit_logs(limit=1, action=discord.AuditLogAction.role_create):
                if not entry.user.bot and not entry.user.guild_permissions.administrator:
                    if not await self.is_whitelisted(role.guild.id, entry.user):
                        await role.delete(reason='نظام الحماية: منع إنشاء الرتب')
                        await self.send_protection_log(role.guild, 'حذف رتبة تلقائي',
                                                       entry.user, 'محاولة إنشاء رتبة')
        except Exception:
            pass

    @commands.Cog.listener()
    async def on_guild_role_delete(self, role: discord.Role):
        protection = await self.db.get_protection(role.guild.id)
        if not protection or not protection['anti_role_delete']:
            return
        try:
            async for entry in role.guild.audit_logs(limit=1, action=discord.AuditLogAction.role_delete):
                if not entry.user.bot and not entry.user.guild_permissions.administrator:
                    if not await self.is_whitelisted(role.guild.id, entry.user):
                        await self.send_protection_log(role.guild, 'تحذير حذف رتبة',
                                                       entry.user, f'حذف رتبة: {role.name}')
        except Exception:
            pass

    # ── Protection Commands ────────────────────────────────────────────────────

    protection_group = app_commands.Group(name='حماية', description='إعدادات نظام الحماية')

    @protection_group.command(name='عرض', description='عرض إعدادات الحماية الحالية')
    @app_commands.checks.has_permissions(administrator=True)
    async def show_protection(self, interaction: discord.Interaction):
        p = await self.db.get_protection(interaction.guild.id)
        embed = discord.Embed(title='🛡️ إعدادات الحماية', color=0x5865F2, timestamp=datetime.utcnow())
        s = lambda v: '✅' if v else '❌'
        embed.add_field(name='🚫 منع السبام', value=f'{s(p["anti_spam"])} (حد: {p["spam_limit"]}/5ث)', inline=True)
        embed.add_field(name='🔗 منع الروابط', value=s(p['anti_links']), inline=True)
        embed.add_field(name='📢 منع المنشن', value=f'{s(p["anti_mention"])} (حد: {p["mention_limit"]})', inline=True)
        embed.add_field(name='📨 منع الدعوات', value=s(p['anti_invites']), inline=True)
        embed.add_field(name='🤖 مكافحة البوتات', value=s(p['anti_bots']), inline=True)
        embed.add_field(name='🤬 فلتر الكلمات', value=s(p.get('anti_bad_words', 0)), inline=True)
        embed.add_field(name='📋 منع إنشاء الرومات', value=s(p['anti_channel_create']), inline=True)
        embed.add_field(name='🗑️ منع حذف الرومات', value=s(p['anti_channel_delete']), inline=True)
        embed.add_field(name='🎖️ منع إنشاء الرتب', value=s(p['anti_role_create']), inline=True)
        embed.add_field(name='🗑️ منع حذف الرتب', value=s(p['anti_role_delete']), inline=True)
        embed.add_field(name='⚠️ حد التحذيرات', value=f'{p["warn_limit"]} → {p["warn_action"]}', inline=True)
        embed.set_footer(text='🛡️ OBT System')
        await interaction.response.send_message(embed=embed)

    @protection_group.command(name='تفعيل', description='تفعيل/تعطيل ميزة حماية')
    @app_commands.describe(الميزة='الميزة', الحالة='تفعيل أو تعطيل')
    @app_commands.choices(الميزة=[
        app_commands.Choice(name='منع السبام', value='anti_spam'),
        app_commands.Choice(name='منع الروابط', value='anti_links'),
        app_commands.Choice(name='منع المنشن الجماعي', value='anti_mention'),
        app_commands.Choice(name='منع الدعوات', value='anti_invites'),
        app_commands.Choice(name='مكافحة البوتات', value='anti_bots'),
        app_commands.Choice(name='فلتر الكلمات المحظورة', value='anti_bad_words'),
        app_commands.Choice(name='منع إنشاء الرومات', value='anti_channel_create'),
        app_commands.Choice(name='منع إنشاء الرتب', value='anti_role_create'),
        app_commands.Choice(name='منع حذف الرومات', value='anti_channel_delete'),
        app_commands.Choice(name='منع حذف الرتب', value='anti_role_delete'),
    ])
    @app_commands.choices(الحالة=[
        app_commands.Choice(name='تفعيل', value=1),
        app_commands.Choice(name='تعطيل', value=0),
    ])
    @app_commands.checks.has_permissions(administrator=True)
    async def toggle_protection(self, interaction: discord.Interaction, الميزة: str, الحالة: int):
        await self.db.update_protection(interaction.guild.id, **{الميزة: الحالة})
        status = '✅ تم التفعيل' if الحالة else '❌ تم التعطيل'
        await interaction.response.send_message(
            embed=success_embed(f'الحماية — {الميزة}', f'{status} بنجاح'))

    @protection_group.command(name='whitelist', description='إضافة رتبة للقائمة البيضاء')
    @app_commands.describe(رتبة='الرتبة')
    @app_commands.checks.has_permissions(administrator=True)
    async def add_whitelist(self, interaction: discord.Interaction, رتبة: discord.Role):
        protection = await self.db.get_protection(interaction.guild.id)
        try:
            whitelist = json.loads(protection['whitelist_roles'] or '[]')
        except Exception:
            whitelist = []
        if رتبة.id not in whitelist:
            whitelist.append(رتبة.id)
            await self.db.update_protection(interaction.guild.id, whitelist_roles=json.dumps(whitelist))
        await interaction.response.send_message(
            embed=success_embed('القائمة البيضاء', f'تمت إضافة {رتبة.mention} للقائمة البيضاء.'))

    # ── Bad Words Commands ─────────────────────────────────────────────────────

    bad_words_group = app_commands.Group(name='كلمات_محظورة', description='إدارة الكلمات المحظورة')

    @bad_words_group.command(name='إضافة', description='إضافة كلمة للقائمة المحظورة')
    @app_commands.describe(كلمة='الكلمة المراد حظرها')
    @app_commands.checks.has_permissions(administrator=True)
    async def add_bad_word(self, interaction: discord.Interaction, كلمة: str):
        added = await self.db.add_bad_word(interaction.guild.id, كلمة.strip())
        self.invalidate_bad_words_cache(interaction.guild.id)
        if added:
            await interaction.response.send_message(
                embed=success_embed('تم إضافة الكلمة', f'تم حظر: `{كلمة.strip()}`'))
        else:
            await interaction.response.send_message(
                embed=error_embed('خطأ', 'الكلمة مضافة مسبقاً.'), ephemeral=True)

    @bad_words_group.command(name='إزالة', description='إزالة كلمة من القائمة المحظورة')
    @app_commands.describe(كلمة='الكلمة')
    @app_commands.checks.has_permissions(administrator=True)
    async def remove_bad_word(self, interaction: discord.Interaction, كلمة: str):
        await self.db.remove_bad_word(interaction.guild.id, كلمة.strip())
        self.invalidate_bad_words_cache(interaction.guild.id)
        await interaction.response.send_message(
            embed=success_embed('تم إزالة الكلمة', f'تم إزالة: `{كلمة.strip()}`'))

    @bad_words_group.command(name='عرض', description='عرض جميع الكلمات المحظورة')
    @app_commands.checks.has_permissions(administrator=True)
    async def list_bad_words(self, interaction: discord.Interaction):
        words = await self.db.get_bad_words(interaction.guild.id)
        if not words:
            return await interaction.response.send_message(
                embed=error_embed('لا توجد كلمات', 'لم يتم إضافة أي كلمات محظورة.'), ephemeral=True)
        embed = discord.Embed(
            title='🤬 الكلمات المحظورة',
            description='\n'.join(f'`{w}`' for w in sorted(words)),
            color=0xFF0000,
            timestamp=datetime.utcnow()
        )
        embed.set_footer(text=f'🛡️ OBT System | {len(words)} كلمة')
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @bad_words_group.command(name='مسح', description='مسح جميع الكلمات المحظورة')
    @app_commands.checks.has_permissions(administrator=True)
    async def clear_bad_words(self, interaction: discord.Interaction):
        await self.db.clear_bad_words(interaction.guild.id)
        self.invalidate_bad_words_cache(interaction.guild.id)
        await interaction.response.send_message(
            embed=success_embed('تم المسح', 'تم مسح جميع الكلمات المحظورة.'))

    @protection_group.command(name='إعداد_تحذيرات', description='ضبط حد التحذيرات والإجراء التلقائي')
    @app_commands.describe(الحد='عدد التحذيرات', الإجراء='الإجراء عند الوصول للحد')
    @app_commands.choices(الإجراء=[
        app_commands.Choice(name='كتم', value='mute'),
        app_commands.Choice(name='طرد', value='kick'),
        app_commands.Choice(name='حظر', value='ban'),
    ])
    @app_commands.checks.has_permissions(administrator=True)
    async def set_warn_limit(self, interaction: discord.Interaction, الحد: int, الإجراء: str):
        await self.db.update_protection(interaction.guild.id, warn_limit=الحد, warn_action=الإجراء)
        await interaction.response.send_message(
            embed=success_embed('تم حفظ إعدادات التحذيرات',
                                f'عند **{الحد}** تحذيرات → إجراء **{الإجراء}** تلقائياً'))


async def setup(bot):
    await bot.add_cog(Protection(bot))
