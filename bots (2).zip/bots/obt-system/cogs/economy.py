"""
Economy Cog - نظام الاقتصاد والكريدتات
"""

import discord
from discord import app_commands
from discord.ext import commands
import asyncio
from datetime import datetime, timedelta
from utils.embeds import success_embed, error_embed


class Economy(commands.Cog, name='الاقتصاد'):
    def __init__(self, bot):
        self.bot = bot
        self.db = bot.db

    async def get_currency(self, guild_id):
        config = await self.db.get_economy_config(guild_id)
        emoji = config['currency_emoji'] if config else '💰'
        name = config['currency_name'] if config else 'كريدت'
        return emoji, name

    # ── !credits / /كريدت ─────────────────────────────────────────────────────

    @commands.command(name='كريدت', aliases=['credits', 'bal', 'رصيد'])
    async def credits_prefix(self, ctx, عضو: discord.Member = None):
        """عرض رصيد الكريدتات"""
        target = عضو or ctx.author
        emoji, name = await self.get_currency(ctx.guild.id)
        amount = await self.db.get_credits(ctx.guild.id, target.id)
        embed = discord.Embed(
            title=f'{emoji} رصيد {target.display_name}',
            description=f'**{amount:,}** {name}',
            color=0xF1C40F,
            timestamp=datetime.utcnow()
        )
        embed.set_thumbnail(url=target.display_avatar.url)
        embed.set_footer(text='🛡️ OBT System')
        await ctx.send(embed=embed)

    @app_commands.command(name='كريدت', description='عرض رصيد الكريدتات')
    @app_commands.describe(عضو='العضو المراد عرض رصيده')
    async def credits_slash(self, interaction: discord.Interaction, عضو: discord.Member = None):
        target = عضو or interaction.user
        emoji, name = await self.get_currency(interaction.guild.id)
        amount = await self.db.get_credits(interaction.guild.id, target.id)
        embed = discord.Embed(
            title=f'{emoji} رصيد {target.display_name}',
            description=f'**{amount:,}** {name}',
            color=0xF1C40F,
            timestamp=datetime.utcnow()
        )
        embed.set_thumbnail(url=target.display_avatar.url)
        embed.set_footer(text='🛡️ OBT System')
        await interaction.response.send_message(embed=embed)

    # ── !daily / /يومي ────────────────────────────────────────────────────────

    @commands.command(name='يومي', aliases=['daily'])
    async def daily_prefix(self, ctx):
        """احصل على مكافأتك اليومية"""
        await self._handle_daily(ctx.guild.id, ctx.author, ctx)

    @app_commands.command(name='يومي', description='احصل على مكافأتك اليومية')
    async def daily_slash(self, interaction: discord.Interaction):
        await self._handle_daily(interaction.guild.id, interaction.user, interaction)

    async def _handle_daily(self, guild_id, user, ctx_or_inter):
        config = await self.db.get_economy_config(guild_id)
        daily_amount = config['daily_amount'] if config else 100
        emoji, name = await self.get_currency(guild_id)

        last_daily = await self.db.get_daily_cooldown(guild_id, user.id)
        if last_daily:
            last_dt = datetime.fromisoformat(last_daily)
            next_dt = last_dt + timedelta(hours=24)
            if datetime.utcnow() < next_dt:
                remaining = next_dt - datetime.utcnow()
                hours = int(remaining.total_seconds() // 3600)
                minutes = int((remaining.total_seconds() % 3600) // 60)
                embed = error_embed(
                    '⏰ كولداون',
                    f'لقد استلمت مكافأتك اليومية بالفعل!\n'
                    f'العودة بعد: **{hours} ساعة و{minutes} دقيقة**'
                )
                if isinstance(ctx_or_inter, discord.Interaction):
                    return await ctx_or_inter.response.send_message(embed=embed, ephemeral=True)
                return await ctx_or_inter.send(embed=embed)

        new_balance = await self.db.add_credits(guild_id, user.id, daily_amount)
        await self.db.set_daily_cooldown(guild_id, user.id)

        embed = discord.Embed(
            title=f'{emoji} مكافأة يومية!',
            description=f'حصلت على **{daily_amount:,}** {name}!\n'
                        f'رصيدك الحالي: **{new_balance:,}** {name}',
            color=0x2ECC71,
            timestamp=datetime.utcnow()
        )
        embed.set_thumbnail(url=user.display_avatar.url)
        embed.set_footer(text='🛡️ OBT System | العودة بعد 24 ساعة')
        if isinstance(ctx_or_inter, discord.Interaction):
            await ctx_or_inter.response.send_message(embed=embed)
        else:
            await ctx_or_inter.send(embed=embed)

    # ── !send / /إرسال_كريدت ─────────────────────────────────────────────────

    @commands.command(name='إرسال', aliases=['send', 'transfer'])
    async def send_prefix(self, ctx, عضو: discord.Member, مبلغ: int):
        """إرسال كريدتات لعضو آخر"""
        await self._handle_send(ctx.guild.id, ctx.author, عضو, مبلغ, ctx)

    @app_commands.command(name='إرسال_كريدت', description='إرسال كريدتات لعضو آخر')
    @app_commands.describe(عضو='العضو المستلم', مبلغ='المبلغ المراد إرساله')
    async def send_slash(self, interaction: discord.Interaction, عضو: discord.Member, مبلغ: int):
        await self._handle_send(interaction.guild.id, interaction.user, عضو, مبلغ, interaction)

    async def _handle_send(self, guild_id, sender, receiver, amount, ctx_or_inter):
        emoji, name = await self.get_currency(guild_id)

        def send_embed(embed, ephemeral=False):
            if isinstance(ctx_or_inter, discord.Interaction):
                return ctx_or_inter.response.send_message(embed=embed, ephemeral=ephemeral)
            return ctx_or_inter.send(embed=embed)

        if sender.id == receiver.id:
            return await send_embed(error_embed('خطأ', 'لا يمكنك إرسال كريدتات لنفسك.'), ephemeral=True)
        if receiver.bot:
            return await send_embed(error_embed('خطأ', 'لا يمكنك إرسال كريدتات للبوتات.'), ephemeral=True)
        if amount <= 0:
            return await send_embed(error_embed('خطأ', 'يجب أن يكون المبلغ أكبر من الصفر.'), ephemeral=True)

        success = await self.db.transfer_credits(guild_id, sender.id, receiver.id, amount)
        if not success:
            balance = await self.db.get_credits(guild_id, sender.id)
            return await send_embed(
                error_embed('رصيد غير كافٍ',
                            f'رصيدك: **{balance:,}** {name}\nالمطلوب: **{amount:,}** {name}'),
                ephemeral=True)

        new_sender_balance = await self.db.get_credits(guild_id, sender.id)
        embed = discord.Embed(
            title=f'{emoji} تم إرسال الكريدتات',
            description=f'أرسلت **{amount:,}** {name} إلى {receiver.mention}',
            color=0x2ECC71,
            timestamp=datetime.utcnow()
        )
        embed.add_field(name='رصيدك الجديد', value=f'{new_sender_balance:,} {name}', inline=True)
        embed.set_footer(text='🛡️ OBT System')
        await send_embed(embed)

    # ── /متجر ─────────────────────────────────────────────────────────────────

    @app_commands.command(name='متجر', description='عرض متجر الرتب')
    async def shop(self, interaction: discord.Interaction):
        items = await self.db.get_shop_items(interaction.guild.id)
        emoji, name = await self.get_currency(interaction.guild.id)

        if not items:
            return await interaction.response.send_message(
                embed=error_embed('المتجر فارغ', 'لم يتم إضافة أي عناصر للمتجر بعد.'),
                ephemeral=True)

        embed = discord.Embed(
            title=f'🛍️ متجر {interaction.guild.name}',
            color=0x9B59B6,
            timestamp=datetime.utcnow()
        )
        for item in items:
            role = interaction.guild.get_role(item['role_id'])
            role_str = role.mention if role else '(رتبة محذوفة)'
            stock_str = f' | المخزون: {item["stock"]}' if item['stock'] > 0 else ''
            embed.add_field(
                name=f'#{item["id"]} — {item["name"]}',
                value=f'{role_str}\n{item["description"]}\n'
                      f'💰 السعر: **{item["price"]:,}** {name}{stock_str}',
                inline=False
            )
        embed.set_footer(text=f'🛡️ OBT System | استخدم /شراء <رقم> للشراء')
        await interaction.response.send_message(embed=embed)

    # ── /شراء ─────────────────────────────────────────────────────────────────

    @app_commands.command(name='شراء', description='شراء عنصر من المتجر')
    @app_commands.describe(رقم_العنصر='رقم العنصر في المتجر')
    async def buy(self, interaction: discord.Interaction, رقم_العنصر: int):
        item = await self.db.get_shop_item(رقم_العنصر)
        emoji, name = await self.get_currency(interaction.guild.id)

        if not item or item['guild_id'] != interaction.guild.id:
            return await interaction.response.send_message(
                embed=error_embed('خطأ', 'العنصر غير موجود في المتجر.'), ephemeral=True)

        if item['stock'] == 0:
            return await interaction.response.send_message(
                embed=error_embed('خطأ', 'نفذ المخزون من هذا العنصر.'), ephemeral=True)

        # Check if user already has the role
        role = interaction.guild.get_role(item['role_id'])
        if role and role in interaction.user.roles:
            return await interaction.response.send_message(
                embed=error_embed('خطأ', 'تملك هذه الرتبة بالفعل.'), ephemeral=True)

        success = await self.db.remove_credits(interaction.guild.id, interaction.user.id, item['price'])
        if not success:
            balance = await self.db.get_credits(interaction.guild.id, interaction.user.id)
            return await interaction.response.send_message(
                embed=error_embed('رصيد غير كافٍ',
                                  f'رصيدك: **{balance:,}** {name}\nالسعر: **{item["price"]:,}** {name}'),
                ephemeral=True)

        # Grant the role
        if role:
            try:
                await interaction.user.add_roles(role, reason=f'شراء من المتجر: {item["name"]}')
            except Exception:
                # Refund
                await self.db.add_credits(interaction.guild.id, interaction.user.id, item['price'])
                return await interaction.response.send_message(
                    embed=error_embed('خطأ', 'فشل منح الرتبة. تم استرداد الكريدتات.'), ephemeral=True)

        # Decrement stock
        if item['stock'] > 0:
            await self.db.decrement_stock(item['id'])

        new_balance = await self.db.get_credits(interaction.guild.id, interaction.user.id)
        embed = discord.Embed(
            title='🛍️ تم الشراء بنجاح!',
            description=f'اشتريت **{item["name"]}**\n'
                        f'{role.mention if role else ""}\n'
                        f'رصيدك الجديد: **{new_balance:,}** {name}',
            color=0x2ECC71,
            timestamp=datetime.utcnow()
        )
        embed.set_footer(text='🛡️ OBT System')
        await interaction.response.send_message(embed=embed)

    # ── Admin: /إضافة_للمتجر ──────────────────────────────────────────────────

    @app_commands.command(name='إضافة_للمتجر', description='إضافة رتبة للمتجر')
    @app_commands.describe(
        رتبة='الرتبة المراد إضافتها',
        سعر='السعر بالكريدتات',
        اسم='اسم العنصر',
        وصف='وصف العنصر',
        مخزون='الكمية المتاحة (-1 لغير محدود)'
    )
    @app_commands.checks.has_permissions(administrator=True)
    async def add_shop_item(self, interaction: discord.Interaction,
                             رتبة: discord.Role, سعر: int, اسم: str,
                             وصف: str = '', مخزون: int = -1):
        if سعر <= 0:
            return await interaction.response.send_message(
                embed=error_embed('خطأ', 'يجب أن يكون السعر أكبر من الصفر.'), ephemeral=True)

        await self.db.add_shop_item(interaction.guild.id, اسم, وصف, سعر, رتبة.id, مخزون)
        _, name = await self.get_currency(interaction.guild.id)
        await interaction.response.send_message(
            embed=success_embed('تم إضافة العنصر للمتجر',
                                f'**{اسم}** — {رتبة.mention}\nالسعر: **{سعر:,}** {name}'))

    @app_commands.command(name='إزالة_من_المتجر', description='إزالة عنصر من المتجر')
    @app_commands.describe(رقم_العنصر='رقم العنصر')
    @app_commands.checks.has_permissions(administrator=True)
    async def remove_shop_item_cmd(self, interaction: discord.Interaction, رقم_العنصر: int):
        item = await self.db.get_shop_item(رقم_العنصر)
        if not item or item['guild_id'] != interaction.guild.id:
            return await interaction.response.send_message(
                embed=error_embed('خطأ', 'العنصر غير موجود.'), ephemeral=True)
        await self.db.remove_shop_item(رقم_العنصر, interaction.guild.id)
        await interaction.response.send_message(
            embed=success_embed('تم إزالة العنصر', f'تم إزالة **{item["name"]}** من المتجر.'))

    # ── Admin: adjust credits ──────────────────────────────────────────────────

    @app_commands.command(name='منح_كريدت', description='منح كريدتات لعضو')
    @app_commands.describe(عضو='العضو', مبلغ='المبلغ')
    @app_commands.checks.has_permissions(manage_guild=True)
    async def grant_credits(self, interaction: discord.Interaction, عضو: discord.Member, مبلغ: int):
        if مبلغ == 0:
            return await interaction.response.send_message(
                embed=error_embed('خطأ', 'المبلغ يجب أن يكون غير صفري.'), ephemeral=True)
        new_bal = await self.db.add_credits(interaction.guild.id, عضو.id, مبلغ)
        emoji, name = await self.get_currency(interaction.guild.id)
        action_word = 'إضافة' if مبلغ > 0 else 'خصم'
        prep_word = 'لـ' if مبلغ > 0 else 'من'
        await interaction.response.send_message(
            embed=success_embed('تم المنح',
                                f'تم {action_word} **{abs(مبلغ):,}** {name} '
                                f'{prep_word} {عضو.mention}\n'
                                f'رصيده الجديد: **{new_bal:,}** {name}'))

    # ── /متصدرو_الاقتصاد ─────────────────────────────────────────────────────

    @app_commands.command(name='متصدرو_الاقتصاد', description='قائمة الأغنى في السيرفر')
    async def economy_leaderboard(self, interaction: discord.Interaction):
        await interaction.response.defer()
        rows = await self.db.get_credits_leaderboard(interaction.guild.id, limit=10)
        emoji, name = await self.get_currency(interaction.guild.id)

        if not rows:
            return await interaction.followup.send(
                embed=error_embed('لا توجد بيانات', 'لم يتم تسجيل أي رصيد بعد.'))

        embed = discord.Embed(
            title=f'{emoji} الأثرياء — {interaction.guild.name}',
            color=0xF1C40F,
            timestamp=datetime.utcnow()
        )
        medals = ['🥇', '🥈', '🥉']
        desc = []
        for i, row in enumerate(rows, 1):
            member = interaction.guild.get_member(row['user_id'])
            n = member.display_name if member else f'<@{row["user_id"]}>'
            medal = medals[i-1] if i <= 3 else f'**#{i}**'
            desc.append(f'{medal} {n} — **{row["credits"]:,}** {name}')
        embed.description = '\n'.join(desc)
        embed.set_footer(text='🛡️ OBT System')
        await interaction.followup.send(embed=embed)

    # ── Economy config ─────────────────────────────────────────────────────────

    @app_commands.command(name='إعدادات_الاقتصاد', description='ضبط إعدادات الاقتصاد')
    @app_commands.describe(
        مبلغ_يومي='المبلغ اليومي',
        اسم_العملة='اسم العملة',
        إيموجي_العملة='إيموجي العملة'
    )
    @app_commands.checks.has_permissions(administrator=True)
    async def economy_config(self, interaction: discord.Interaction,
                              مبلغ_يومي: int = None, اسم_العملة: str = None,
                              إيموجي_العملة: str = None):
        kwargs = {}
        if مبلغ_يومي is not None:
            kwargs['daily_amount'] = مبلغ_يومي
        if اسم_العملة:
            kwargs['currency_name'] = اسم_العملة
        if إيموجي_العملة:
            kwargs['currency_emoji'] = إيموجي_العملة
        if kwargs:
            await self.db.update_economy_config(interaction.guild.id, **kwargs)
        await interaction.response.send_message(
            embed=success_embed('تم حفظ إعدادات الاقتصاد', 'تم تحديث إعدادات نظام الاقتصاد.'))


async def setup(bot):
    await bot.add_cog(Economy(bot))
