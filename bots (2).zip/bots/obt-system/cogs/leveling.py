"""
Leveling Cog - نظام المستويات والـ XP
"""

import discord
from discord import app_commands
from discord.ext import commands
import asyncio
import json
import random
from datetime import datetime
from utils.embeds import success_embed, error_embed


# XP formula: xp_for_level(L) = L^2 * 50
def xp_for_level(level: int) -> int:
    return level * level * 50


def xp_needed_for_next(current_level: int) -> int:
    return xp_for_level(current_level + 1) - xp_for_level(current_level)


class Leveling(commands.Cog, name='المستويات'):
    def __init__(self, bot):
        self.bot = bot
        self.db = bot.db
        # Cooldown tracking: {guild_id: {user_id: last_xp_time}}
        self._xp_cooldown: dict = {}

    def _is_on_cooldown(self, guild_id: int, user_id: int, cooldown: int) -> bool:
        import time
        key = (guild_id, user_id)
        last = self._xp_cooldown.get(key, 0)
        now = time.time()
        if now - last < cooldown:
            return True
        self._xp_cooldown[key] = now
        return False

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if not message.guild or message.author.bot:
            return
        if not isinstance(message.author, discord.Member):
            return
        if message.content.startswith(('!', '/')):
            return  # Skip commands

        config = await self.db.get_xp_config(message.guild.id)
        if not config or not config['enabled']:
            return

        cooldown = config['cooldown'] or 60
        if self._is_on_cooldown(message.guild.id, message.author.id, cooldown):
            return

        xp_gain = random.randint(config['xp_min'] or 5, config['xp_max'] or 15)
        new_xp, new_level, leveled_up = await self.db.add_xp(
            message.guild.id, message.author.id, xp_gain
        )

        if leveled_up:
            await self._handle_level_up(message, new_level, config)

    async def _handle_level_up(self, message: discord.Message, level: int, config):
        member = message.author

        # Assign level roles
        level_roles = await self.db.get_level_roles(message.guild.id)
        stack = config['stack_roles'] if config else 0

        roles_to_add = []
        roles_to_remove = []
        for lr in level_roles:
            role = message.guild.get_role(lr['role_id'])
            if not role:
                continue
            if lr['level'] <= level:
                if not stack:
                    # Only keep the highest applicable role
                    if lr['level'] == level:
                        roles_to_add.append(role)
                    elif role in member.roles:
                        roles_to_remove.append(role)
                else:
                    roles_to_add.append(role)

        try:
            if roles_to_remove:
                await member.remove_roles(*roles_to_remove, reason='ترقية المستوى')
            if roles_to_add:
                await member.add_roles(*roles_to_add, reason=f'وصول للمستوى {level}')
        except Exception:
            pass

        # Send announcement
        announce_type = config['announce_type'] or 'current'
        if announce_type == 'off':
            return

        embed = discord.Embed(
            title='🎉 ترقية مستوى!',
            description=f'مبروك {member.mention}! وصلت للمستوى **{level}** 🏆',
            color=0xF1C40F,
            timestamp=datetime.utcnow()
        )
        embed.set_thumbnail(url=member.display_avatar.url)
        next_xp = xp_for_level(level + 1)
        embed.add_field(name='📊 المستوى الجديد', value=str(level), inline=True)
        embed.add_field(name='⭐ XP للمستوى التالي', value=f'{next_xp:,}', inline=True)
        if roles_to_add:
            embed.add_field(name='🎖️ رتبة جديدة', value=' '.join(r.mention for r in roles_to_add), inline=False)
        embed.set_footer(text='🛡️ OBT System')

        target_channel = None
        if announce_type == 'channel' and config['announce_channel']:
            target_channel = message.guild.get_channel(config['announce_channel'])
        elif announce_type == 'current':
            target_channel = message.channel
        elif announce_type == 'dm':
            try:
                await member.send(embed=embed)
            except Exception:
                pass
            return

        if target_channel:
            try:
                await target_channel.send(embed=embed)
            except Exception:
                pass

    # ── /مستوى ────────────────────────────────────────────────────────────────

    @app_commands.command(name='مستوى', description='عرض مستواك أو مستوى عضو')
    @app_commands.describe(عضو='العضو المراد عرض مستواه')
    async def level(self, interaction: discord.Interaction, عضو: discord.Member = None):
        target = عضو or interaction.user
        data = await self.db.get_user_xp(interaction.guild.id, target.id)

        if not data or data['xp'] == 0:
            return await interaction.response.send_message(
                embed=error_embed('لا توجد بيانات', f'{target.mention} لم يكسب أي XP بعد.'),
                ephemeral=True)

        xp = data['xp']
        level = data['level']
        current_level_xp = xp_for_level(level)
        next_level_xp = xp_for_level(level + 1)
        xp_in_level = xp - current_level_xp
        xp_needed = next_level_xp - current_level_xp
        progress = min(int((xp_in_level / xp_needed) * 20), 20) if xp_needed > 0 else 20

        bar = '█' * progress + '░' * (20 - progress)
        rank = await self.db.get_xp_rank(interaction.guild.id, target.id)

        embed = discord.Embed(
            title=f'📊 مستوى {target.display_name}',
            color=target.color.value or 0x5865F2,
            timestamp=datetime.utcnow()
        )
        embed.set_thumbnail(url=target.display_avatar.url)
        embed.add_field(name='🏆 المستوى', value=str(level), inline=True)
        embed.add_field(name='🌟 الترتيب', value=f'#{rank}', inline=True)
        embed.add_field(name='⭐ إجمالي XP', value=f'{xp:,}', inline=True)
        embed.add_field(
            name=f'📈 التقدم ({xp_in_level:,}/{xp_needed:,} XP)',
            value=f'`{bar}` {int(xp_in_level/xp_needed*100) if xp_needed else 100}%',
            inline=False
        )
        embed.set_footer(text='🛡️ OBT System')
        await interaction.response.send_message(embed=embed)

    # ── /متصدرو_المستويات ─────────────────────────────────────────────────────

    @app_commands.command(name='متصدرو_المستويات', description='قائمة المتصدرين بالـ XP')
    async def xp_leaderboard(self, interaction: discord.Interaction):
        await interaction.response.defer()
        rows = await self.db.get_xp_leaderboard(interaction.guild.id, limit=10)

        if not rows:
            return await interaction.followup.send(
                embed=error_embed('لا توجد بيانات', 'لم يكسب أحد XP بعد في هذا السيرفر.'))

        embed = discord.Embed(
            title=f'🏆 متصدرو المستويات — {interaction.guild.name}',
            color=0xF1C40F,
            timestamp=datetime.utcnow()
        )
        medals = ['🥇', '🥈', '🥉']
        desc = []
        for i, row in enumerate(rows, 1):
            member = interaction.guild.get_member(row['user_id'])
            name = member.display_name if member else f'<@{row["user_id"]}>'
            medal = medals[i-1] if i <= 3 else f'**#{i}**'
            desc.append(f'{medal} {name} — المستوى **{row["level"]}** | `{row["xp"]:,} XP`')

        embed.description = '\n'.join(desc)
        embed.set_footer(text='🛡️ OBT System')
        await interaction.followup.send(embed=embed)

    # ── Level Role Management ──────────────────────────────────────────────────

    level_group = app_commands.Group(name='رتبة_مستوى', description='إدارة رتب المستويات')

    @level_group.command(name='تعيين', description='تعيين رتبة لمستوى معين')
    @app_commands.describe(مستوى='رقم المستوى', رتبة='الرتبة الممنوحة')
    @app_commands.checks.has_permissions(administrator=True)
    async def set_level_role(self, interaction: discord.Interaction,
                              مستوى: int, رتبة: discord.Role):
        if مستوى < 1:
            return await interaction.response.send_message(
                embed=error_embed('خطأ', 'يجب أن يكون المستوى 1 أو أعلى.'), ephemeral=True)
        await self.db.set_level_role(interaction.guild.id, مستوى, رتبة.id)
        await interaction.response.send_message(
            embed=success_embed('تم تعيين الرتبة',
                                f'سيحصل الأعضاء على {رتبة.mention} عند الوصول للمستوى **{مستوى}**'))

    @level_group.command(name='إزالة', description='إزالة رتبة من مستوى')
    @app_commands.describe(مستوى='رقم المستوى')
    @app_commands.checks.has_permissions(administrator=True)
    async def remove_level_role(self, interaction: discord.Interaction, مستوى: int):
        await self.db.remove_level_role(interaction.guild.id, مستوى)
        await interaction.response.send_message(
            embed=success_embed('تم إزالة الرتبة', f'تمت إزالة رتبة المستوى **{مستوى}**'))

    @level_group.command(name='عرض', description='عرض جميع رتب المستويات')
    async def list_level_roles(self, interaction: discord.Interaction):
        roles = await self.db.get_level_roles(interaction.guild.id)
        if not roles:
            return await interaction.response.send_message(
                embed=error_embed('لا توجد رتب', 'لم يتم تعيين رتب للمستويات بعد.'), ephemeral=True)

        embed = discord.Embed(title='🎖️ رتب المستويات', color=0x5865F2, timestamp=datetime.utcnow())
        desc = []
        for lr in roles:
            role = interaction.guild.get_role(lr['role_id'])
            role_str = role.mention if role else f'<@&{lr["role_id"]}>'
            desc.append(f'**المستوى {lr["level"]}** → {role_str}')
        embed.description = '\n'.join(desc)
        embed.set_footer(text='🛡️ OBT System')
        await interaction.response.send_message(embed=embed)

    # ── XP Settings ────────────────────────────────────────────────────────────

    xp_group = app_commands.Group(name='إعدادات_xp', description='إعدادات نظام XP')

    @xp_group.command(name='تفعيل', description='تفعيل أو تعطيل نظام XP')
    @app_commands.choices(الحالة=[
        app_commands.Choice(name='تفعيل', value=1),
        app_commands.Choice(name='تعطيل', value=0),
    ])
    @app_commands.checks.has_permissions(administrator=True)
    async def toggle_xp(self, interaction: discord.Interaction, الحالة: int):
        await self.db.update_xp_config(interaction.guild.id, enabled=الحالة)
        status = '✅ مفعل' if الحالة else '❌ معطل'
        await interaction.response.send_message(
            embed=success_embed('إعدادات XP', f'نظام XP الآن: {status}'))

    @xp_group.command(name='إعداد', description='ضبط معدل XP والكولداون')
    @app_commands.describe(
        أدنى='أقل XP لكل رسالة',
        أعلى='أعلى XP لكل رسالة',
        كولداون='ثواني الانتظار بين رسائل XP',
    )
    @app_commands.checks.has_permissions(administrator=True)
    async def configure_xp(self, interaction: discord.Interaction,
                            أدنى: int = 5, أعلى: int = 15, كولداون: int = 60):
        if أدنى >= أعلى:
            return await interaction.response.send_message(
                embed=error_embed('خطأ', 'يجب أن يكون الحد الأدنى أقل من الحد الأعلى.'), ephemeral=True)
        await self.db.update_xp_config(
            interaction.guild.id, xp_min=أدنى, xp_max=أعلى, cooldown=كولداون)
        await interaction.response.send_message(
            embed=success_embed('تم حفظ إعدادات XP',
                                f'XP لكل رسالة: **{أدنى}-{أعلى}**\nكولداون: **{كولداون}** ثانية'))

    @xp_group.command(name='قناة_الإعلان', description='تحديد قناة إعلانات الترقية')
    @app_commands.describe(
        روم='روم الإعلانات (اتركه فارغاً للروم الحالي)',
        النوع='نوع الإعلان'
    )
    @app_commands.choices(النوع=[
        app_commands.Choice(name='في الروم الحالي', value='current'),
        app_commands.Choice(name='في روم محدد', value='channel'),
        app_commands.Choice(name='برسالة خاصة', value='dm'),
        app_commands.Choice(name='معطل', value='off'),
    ])
    @app_commands.checks.has_permissions(administrator=True)
    async def set_announce(self, interaction: discord.Interaction,
                           النوع: str, روم: discord.TextChannel = None):
        kwargs = {'announce_type': النوع}
        if روم:
            kwargs['announce_channel'] = روم.id
        await self.db.update_xp_config(interaction.guild.id, **kwargs)
        await interaction.response.send_message(
            embed=success_embed('تم حفظ إعدادات الإعلان', f'النوع: **{النوع}**'))

    @xp_group.command(name='تعديل', description='تعديل XP عضو يدوياً')
    @app_commands.describe(عضو='العضو', xp='الـ XP الجديد')
    @app_commands.checks.has_permissions(administrator=True)
    async def set_xp_admin(self, interaction: discord.Interaction, عضو: discord.Member, xp: int):
        if xp < 0:
            return await interaction.response.send_message(
                embed=error_embed('خطأ', 'لا يمكن أن يكون XP سالباً.'), ephemeral=True)
        level = int((xp / 50) ** 0.5)
        await self.db.set_xp(interaction.guild.id, عضو.id, xp, level)
        await interaction.response.send_message(
            embed=success_embed('تم التعديل',
                                f'تم تعيين XP **{عضو.mention}** إلى **{xp:,}** (المستوى {level})'))


async def setup(bot):
    await bot.add_cog(Leveling(bot))
