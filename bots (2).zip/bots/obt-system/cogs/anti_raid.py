"""
Anti-Raid Cog - نظام الحماية من الريد والإدمن المارق
Tracks destructive actions by admins and triggers emergency lockdown.
"""

import discord
from discord import app_commands
from discord.ext import commands
import json
import asyncio
from collections import defaultdict
from datetime import datetime, timedelta
from utils.embeds import success_embed, error_embed


class AntiRaid(commands.Cog, name='مكافحة الريد'):
    def __init__(self, bot):
        self.bot = bot
        self.db = bot.db
        # {guild_id: {user_id: [timestamps]}}
        self._action_tracker: dict = defaultdict(lambda: defaultdict(list))
        # Expose on bot for other cogs to call
        bot.raid_tracker = self

    async def register_destructive_action(self, guild: discord.Guild, perpetrator: discord.Member):
        """
        Called whenever a senior admin performs a destructive action.
        If they exceed the configured limit within the time window, trigger lockdown.
        """
        if not guild or not perpetrator:
            return
        if perpetrator.id == guild.owner_id:
            return  # Never touch the server owner
        if perpetrator.bot:
            return

        config = await self.db.get_anti_raid_config(guild.id)
        if not config or not config['enabled']:
            return

        limit = config['action_limit'] or 3
        window = config['time_window'] or 300  # seconds

        now = datetime.utcnow()
        cutoff = now - timedelta(seconds=window)

        # Append and filter old entries
        tracker = self._action_tracker[guild.id][perpetrator.id]
        tracker.append(now)
        self._action_tracker[guild.id][perpetrator.id] = [t for t in tracker if t > cutoff]

        count = len(self._action_tracker[guild.id][perpetrator.id])

        if count > limit:
            # Clear tracker to avoid re-triggering on every new action
            self._action_tracker[guild.id][perpetrator.id] = []
            await self._emergency_lockdown(guild, perpetrator, count, config)

    async def _emergency_lockdown(self, guild: discord.Guild, perpetrator: discord.Member,
                                   action_count: int, config):
        """Strip all roles, log, DM owner."""
        # 1. Strip ALL roles from the perpetrator immediately
        try:
            roles_to_remove = [r for r in perpetrator.roles if r.name != '@everyone'
                                and r < guild.me.top_role]
            if roles_to_remove:
                await perpetrator.remove_roles(
                    *roles_to_remove,
                    reason=f'🚨 طوارئ مكافحة الريد — {action_count} إجراءات مدمرة'
                )
        except Exception as e:
            pass

        # 2. Log to security channel
        security_ch_id = config['security_log_channel']
        embed = discord.Embed(
            title='🚨 تحذير أمني طارئ — إدمن مارق!',
            description=(
                f'**تم تجميد صلاحيات مشرف!**\n\n'
                f'👤 **المشرف:** {perpetrator.mention} (`{perpetrator.id}`)\n'
                f'⚡ **الإجراءات المدمرة:** {action_count} خلال فترة قصيرة\n'
                f'🕐 **الوقت:** {discord.utils.format_dt(discord.utils.utcnow(), "F")}\n\n'
                f'تم سحب جميع رتبه فورياً لحماية السيرفر.'
            ),
            color=0xFF0000,
            timestamp=datetime.utcnow()
        )
        embed.set_thumbnail(url=perpetrator.display_avatar.url)
        embed.set_footer(text='🛡️ OBT System — Anti-Raid')

        if security_ch_id:
            ch = guild.get_channel(security_ch_id)
            if ch:
                try:
                    await ch.send(embed=embed)
                except Exception:
                    pass

        # Also log to general log channel
        guild_data = await self.db.get_guild(guild.id)
        if guild_data and guild_data['log_channel']:
            log_ch = guild.get_channel(guild_data['log_channel'])
            if log_ch:
                try:
                    await log_ch.send(embed=embed)
                except Exception:
                    pass

        # 3. DM the Server Owner
        if guild.owner:
            dm_embed = discord.Embed(
                title='🚨 تحذير طارئ — سيرفرك بخطر!',
                description=(
                    f'**سيرفر:** {guild.name}\n\n'
                    f'⚠️ تم اكتشاف نشاط مدمر من:\n'
                    f'{perpetrator.mention} (`{perpetrator.name}` | `{perpetrator.id}`)\n\n'
                    f'**الإجراءات المرصودة:** {action_count} إجراء مدمر في وقت قصير\n\n'
                    f'✅ **تم سحب جميع رتبه تلقائياً.**\n'
                    f'يُنصح بمراجعة السيرفر فوراً وحظره إن لزم الأمر.'
                ),
                color=0xFF0000,
                timestamp=datetime.utcnow()
            )
            dm_embed.set_footer(text='🛡️ OBT System — Anti-Raid Protection')
            try:
                await guild.owner.send(embed=dm_embed)
            except Exception:
                pass

        # Log to DB
        await self.db.log_action(
            guild.id, self.bot.user.id, perpetrator.id,
            'anti_raid_lockdown',
            f'تم تجميد صلاحيات الإدمن المارق — {action_count} إجراءات مدمرة'
        )

    # ── Event listeners ────────────────────────────────────────────────────────

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel: discord.abc.GuildChannel):
        """Track channel deletions by admins."""
        try:
            async for entry in channel.guild.audit_logs(
                limit=1, action=discord.AuditLogAction.channel_delete
            ):
                if entry.user and not entry.user.bot:
                    if entry.user.guild_permissions.manage_channels:
                        await self.register_destructive_action(channel.guild, entry.user)
        except Exception:
            pass

    @commands.Cog.listener()
    async def on_guild_role_delete(self, role: discord.Role):
        """Track role deletions by admins."""
        try:
            async for entry in role.guild.audit_logs(
                limit=1, action=discord.AuditLogAction.role_delete
            ):
                if entry.user and not entry.user.bot:
                    if entry.user.guild_permissions.manage_roles:
                        await self.register_destructive_action(role.guild, entry.user)
        except Exception:
            pass

    @commands.Cog.listener()
    async def on_member_ban(self, guild: discord.Guild, user: discord.User):
        """Track bans by admins."""
        try:
            async for entry in guild.audit_logs(
                limit=1, action=discord.AuditLogAction.ban
            ):
                if entry.user and not entry.user.bot:
                    member = guild.get_member(entry.user.id)
                    if member:
                        await self.register_destructive_action(guild, member)
        except Exception:
            pass

    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member):
        """Track kicks by admins (via audit log)."""
        if member.bot:
            return
        try:
            await asyncio.sleep(0.5)  # Small delay for audit log to update
            async for entry in member.guild.audit_logs(
                limit=1, action=discord.AuditLogAction.kick
            ):
                if (entry.target and entry.target.id == member.id and
                        entry.user and not entry.user.bot):
                    kicker = member.guild.get_member(entry.user.id)
                    if kicker:
                        await self.register_destructive_action(member.guild, kicker)
        except Exception:
            pass

    # ── Slash Commands ─────────────────────────────────────────────────────────

    raid_group = app_commands.Group(name='حماية_ريد', description='إعدادات مكافحة الريد')

    @raid_group.command(name='عرض', description='عرض إعدادات نظام مكافحة الريد')
    @app_commands.checks.has_permissions(administrator=True)
    async def show_config(self, interaction: discord.Interaction):
        config = await self.db.get_anti_raid_config(interaction.guild.id)
        embed = discord.Embed(
            title='🛡️ إعدادات مكافحة الريد',
            color=0x5865F2,
            timestamp=datetime.utcnow()
        )
        status = '✅ مفعل' if (config and config['enabled']) else '❌ معطل'
        embed.add_field(name='📊 الحالة', value=status, inline=True)
        embed.add_field(name='⚡ حد الإجراءات', value=str(config['action_limit'] if config else 3), inline=True)
        embed.add_field(name='⏱️ النافذة الزمنية', value=f'{(config["time_window"] if config else 300) // 60} دقائق', inline=True)

        if config and config['security_log_channel']:
            ch = interaction.guild.get_channel(config['security_log_channel'])
            embed.add_field(name='📋 قناة اللوق الأمني', value=ch.mention if ch else 'محذوف', inline=True)

        embed.set_footer(text='🛡️ OBT System')
        await interaction.response.send_message(embed=embed)

    @raid_group.command(name='تفعيل', description='تفعيل/تعطيل نظام مكافحة الريد')
    @app_commands.choices(الحالة=[
        app_commands.Choice(name='تفعيل', value=1),
        app_commands.Choice(name='تعطيل', value=0),
    ])
    @app_commands.checks.has_permissions(administrator=True)
    async def toggle_raid(self, interaction: discord.Interaction, الحالة: int):
        await self.db.update_anti_raid_config(interaction.guild.id, enabled=الحالة)
        status = '✅ مفعل' if الحالة else '❌ معطل'
        await interaction.response.send_message(
            embed=success_embed('مكافحة الريد', f'النظام الآن: {status}'))

    @raid_group.command(name='إعداد', description='ضبط حدود نظام مكافحة الريد')
    @app_commands.describe(
        الحد='عدد الإجراءات قبل التجميد',
        النافذة='المدة بالدقائق',
        قناة_اللوق='قناة اللوق الأمني'
    )
    @app_commands.checks.has_permissions(administrator=True)
    async def configure_raid(self, interaction: discord.Interaction,
                              الحد: int = 3, النافذة: int = 5,
                              قناة_اللوق: discord.TextChannel = None):
        kwargs = {
            'action_limit': الحد,
            'time_window': النافذة * 60,
        }
        if قناة_اللوق:
            kwargs['security_log_channel'] = قناة_اللوق.id

        await self.db.update_anti_raid_config(interaction.guild.id, **kwargs)
        await interaction.response.send_message(
            embed=success_embed(
                'تم حفظ إعدادات مكافحة الريد',
                f'الحد: **{الحد}** إجراءات خلال **{النافذة}** دقائق\n'
                f'قناة اللوق: {قناة_اللوق.mention if قناة_اللوق else "غير محددة"}'
            ))

    @raid_group.command(name='قناة_الأمان', description='تحديد قناة لوق الطوارئ الأمنية')
    @app_commands.describe(قناة='القناة')
    @app_commands.checks.has_permissions(administrator=True)
    async def set_security_channel(self, interaction: discord.Interaction,
                                    قناة: discord.TextChannel):
        await self.db.update_anti_raid_config(interaction.guild.id, security_log_channel=قناة.id)
        await interaction.response.send_message(
            embed=success_embed('تم تحديد القناة الأمنية',
                                f'ستُرسل تحذيرات الطوارئ في {قناة.mention}'))

    @raid_group.command(name='تسجيل_إجراء', description='تسجيل إجراء مدمر يدوياً لاختبار النظام')
    @app_commands.describe(عضو='العضو المراد تسجيل إجراء له')
    @app_commands.checks.has_permissions(administrator=True)
    async def test_register(self, interaction: discord.Interaction, عضو: discord.Member = None):
        target = عضو or interaction.user
        if target.id == interaction.guild.owner_id:
            return await interaction.response.send_message(
                embed=error_embed('خطأ', 'لا يمكن تسجيل إجراء ضد مالك السيرفر.'), ephemeral=True)
        tracker = self._action_tracker[interaction.guild.id][target.id]
        await interaction.response.send_message(
            embed=success_embed(
                'اختبار النظام',
                f'سجّلت إجراءً مدمراً لـ {target.mention}\n'
                f'الإجراءات الحالية: **{len(tracker) + 1}**'
            ), ephemeral=True)
        await self.register_destructive_action(interaction.guild, target)


async def setup(bot):
    await bot.add_cog(AntiRaid(bot))
