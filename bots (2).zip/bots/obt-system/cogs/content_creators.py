"""
Content Creators Cog - نظام صناع المحتوى
"""

import discord
from discord import app_commands
from discord.ext import commands
from discord.ext import tasks
import aiohttp
from datetime import datetime
from utils.embeds import success_embed, error_embed


class ContentCreators(commands.Cog, name='صناع المحتوى'):
    def __init__(self, bot):
        self.bot = bot
        self.db = bot.db
        self.session = None
        self.check_new_videos.start()

    def cog_unload(self):
        self.check_new_videos.cancel()

    async def cog_load(self):
        self.session = aiohttp.ClientSession()

    @tasks.loop(minutes=15)
    async def check_new_videos(self):
        """Check for new YouTube videos every 15 minutes."""
        if not self.session:
            return
        import os
        yt_api_key = os.getenv('YOUTUBE_API_KEY')
        if not yt_api_key:
            return

        for guild in self.bot.guilds:
            creators = await self.db.get_creators(guild.id)
            for creator in creators:
                if not creator['youtube_channel_id']:
                    continue
                await self._check_creator_video(guild, creator, yt_api_key)

    async def _check_creator_video(self, guild: discord.Guild, creator, yt_api_key: str):
        try:
            url = (
                f'https://www.googleapis.com/youtube/v3/search'
                f'?key={yt_api_key}&channelId={creator["youtube_channel_id"]}'
                f'&part=snippet&order=date&maxResults=1&type=video'
            )
            async with self.session.get(url) as resp:
                if resp.status != 200:
                    return
                data = await resp.json()

            items = data.get('items', [])
            if not items:
                return

            latest = items[0]
            video_id = latest['id'].get('videoId')
            if not video_id or video_id == creator['last_video_id']:
                return

            # New video found!
            await self.db.update_creator(guild.id, creator['user_id'], last_video_id=video_id)

            announce_channel = guild.get_channel(creator['announce_channel'])
            if not announce_channel:
                return

            snippet = latest['snippet']
            video_url = f'https://www.youtube.com/watch?v={video_id}'
            thumbnail = snippet.get('thumbnails', {}).get('high', {}).get('url', '')

            member = guild.get_member(creator['user_id'])
            creator_name = member.display_name if member else creator['youtube_name']

            embed = discord.Embed(
                title=f'🎥 {snippet["title"]}',
                url=video_url,
                description=snippet.get('description', '')[:300],
                color=0xFF0000,
                timestamp=datetime.utcnow()
            )
            embed.set_author(name=f'📹 {creator_name} نشر فيديو جديد!')
            if thumbnail:
                embed.set_image(url=thumbnail)
            embed.add_field(name='🔗 الرابط', value=f'[شاهد الآن]({video_url})', inline=True)
            embed.set_footer(text='🛡️ OBT System | صناع المحتوى')

            mention = member.mention if member else ''
            await announce_channel.send(content=mention, embed=embed)

        except Exception as e:
            self.bot.logger.error(f'خطأ في فحص فيديوهات {creator["youtube_name"]}: {e}')

    @check_new_videos.before_loop
    async def before_check(self):
        await self.bot.wait_until_ready()
        if not self.session:
            self.session = aiohttp.ClientSession()

    # ── Commands ───────────────────────────────────────────────────────────────

    creators_group = app_commands.Group(name='صناع', description='نظام صناع المحتوى')

    @creators_group.command(name='ربط', description='ربط حساب YouTube بالسيرفر')
    @app_commands.describe(
        معرف_القناة='معرف قناة YouTube (Channel ID)',
        اسم_القناة='اسم القناة',
        روم_الإعلانات='الروم الذي سيتم نشر الفيديوهات فيه'
    )
    async def link_channel(self, interaction: discord.Interaction,
                           معرف_القناة: str, اسم_القناة: str,
                           روم_الإعلانات: discord.TextChannel):
        await self.db.add_creator(
            interaction.guild.id, interaction.user.id,
            معرف_القناة, اسم_القناة, روم_الإعلانات.id
        )
        embed = success_embed(
            'تم ربط القناة',
            f'تم ربط قناة **{اسم_القناة}** بنجاح!\n'
            f'سيتم نشر الفيديوهات الجديدة في {روم_الإعلانات.mention}'
        )
        await interaction.response.send_message(embed=embed)

    @creators_group.command(name='إلغاء_الربط', description='إلغاء ربط قناة YouTube')
    async def unlink_channel(self, interaction: discord.Interaction):
        creator = await self.db.get_creator(interaction.guild.id, interaction.user.id)
        if not creator:
            return await interaction.response.send_message(
                embed=error_embed('خطأ', 'لم تقم بربط أي قناة.'), ephemeral=True)

        await self.db.remove_creator(interaction.guild.id, interaction.user.id)
        embed = success_embed('تم إلغاء الربط', 'تم إلغاء ربط قناتك من السيرفر.')
        await interaction.response.send_message(embed=embed)

    @creators_group.command(name='قائمة', description='عرض قائمة صناع المحتوى')
    async def list_creators(self, interaction: discord.Interaction):
        creators = await self.db.get_creators(interaction.guild.id)
        embed = discord.Embed(
            title='🎥 صناع المحتوى',
            color=0xFF0000,
            timestamp=datetime.utcnow()
        )
        if not creators:
            embed.description = 'لا يوجد صناع محتوى مسجلون.'
        else:
            for i, creator in enumerate(creators, 1):
                member = interaction.guild.get_member(creator['user_id'])
                name = member.display_name if member else creator['youtube_name']
                yt_url = f'https://www.youtube.com/channel/{creator["youtube_channel_id"]}'
                announce = interaction.guild.get_channel(creator['announce_channel'])
                embed.add_field(
                    name=f'{i}. {name}',
                    value=f'📺 [{creator["youtube_name"]}]({yt_url})\n'
                          f'📢 {announce.mention if announce else "روم غير موجود"}',
                    inline=True
                )
        embed.set_footer(text='🛡️ OBT System')
        await interaction.response.send_message(embed=embed)

    @creators_group.command(name='فحص', description='فحص فيديوهات صانع محتوى الآن')
    @app_commands.checks.has_permissions(manage_guild=True)
    async def manual_check(self, interaction: discord.Interaction):
        import os
        yt_api_key = os.getenv('YOUTUBE_API_KEY')
        if not yt_api_key:
            return await interaction.response.send_message(
                embed=error_embed('خطأ', 'لم يتم تعيين YOUTUBE_API_KEY في البيئة.'), ephemeral=True)

        await interaction.response.defer()
        creators = await self.db.get_creators(interaction.guild.id)
        if not self.session:
            self.session = aiohttp.ClientSession()

        for creator in creators:
            await self._check_creator_video(interaction.guild, creator, yt_api_key)

        await interaction.followup.send(
            embed=success_embed('تم الفحص', f'تم فحص {len(creators)} قناة بحثاً عن فيديوهات جديدة.'))


async def setup(bot):
    await bot.add_cog(ContentCreators(bot))
