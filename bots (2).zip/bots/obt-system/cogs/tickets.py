"""
Tickets Cog - نظام التذاكر
"""

import discord
from discord import app_commands
from discord.ext import commands
import json
import asyncio
from datetime import datetime
from utils.embeds import success_embed, error_embed, ticket_embed


class TicketView(discord.ui.View):
    def __init__(self, departments: list):
        super().__init__(timeout=None)
        self.add_item(TicketSelect(departments))


class TicketSelect(discord.ui.Select):
    def __init__(self, departments: list):
        options = [
            discord.SelectOption(label=dept, emoji='📂', value=dept)
            for dept in departments
        ]
        super().__init__(
            placeholder='اختر القسم...',
            options=options,
            custom_id='ticket_department_select'
        )

    async def callback(self, interaction: discord.Interaction):
        cog = interaction.client.get_cog('التذاكر')
        if cog:
            await cog.create_ticket(interaction, self.values[0])


class TicketControlView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label='إغلاق التذكرة', emoji='🔒', style=discord.ButtonStyle.danger, custom_id='ticket_close')
    async def close_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        cog = interaction.client.get_cog('التذاكر')
        if cog:
            await cog.close_ticket(interaction)

    @discord.ui.button(label='حفظ Transcript', emoji='📄', style=discord.ButtonStyle.secondary, custom_id='ticket_transcript')
    async def save_transcript(self, interaction: discord.Interaction, button: discord.ui.Button):
        cog = interaction.client.get_cog('التذاكر')
        if cog:
            await cog.save_transcript(interaction)


class ClosedTicketView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label='إعادة فتح', emoji='🔓', style=discord.ButtonStyle.success, custom_id='ticket_reopen')
    async def reopen_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        cog = interaction.client.get_cog('التذاكر')
        if cog:
            await cog.reopen_ticket(interaction)

    @discord.ui.button(label='حذف التذكرة', emoji='🗑️', style=discord.ButtonStyle.danger, custom_id='ticket_delete')
    async def delete_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        cog = interaction.client.get_cog('التذاكر')
        if cog:
            await cog.delete_ticket(interaction)


class RatingView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=300)

    @discord.ui.button(label='⭐', style=discord.ButtonStyle.secondary, custom_id='rate_1')
    async def rate_1(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self._rate(interaction, 1)

    @discord.ui.button(label='⭐⭐', style=discord.ButtonStyle.secondary, custom_id='rate_2')
    async def rate_2(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self._rate(interaction, 2)

    @discord.ui.button(label='⭐⭐⭐', style=discord.ButtonStyle.secondary, custom_id='rate_3')
    async def rate_3(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self._rate(interaction, 3)

    @discord.ui.button(label='⭐⭐⭐⭐', style=discord.ButtonStyle.secondary, custom_id='rate_4')
    async def rate_4(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self._rate(interaction, 4)

    @discord.ui.button(label='⭐⭐⭐⭐⭐', style=discord.ButtonStyle.success, custom_id='rate_5')
    async def rate_5(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self._rate(interaction, 5)

    async def _rate(self, interaction: discord.Interaction, stars: int):
        cog = interaction.client.get_cog('التذاكر')
        if cog:
            await cog.handle_rating(interaction, stars)
        self.stop()


class Tickets(commands.Cog, name='التذاكر'):
    def __init__(self, bot):
        self.bot = bot
        self.db = bot.db
        # Register all persistent views so they survive bot restarts
        bot.add_view(TicketControlView())
        bot.add_view(ClosedTicketView())
        # TicketView with empty departments — Discord stores rendered options on the message itself
        bot.add_view(TicketView([]))

    async def send_log(self, guild: discord.Guild, embed: discord.Embed):
        config = await self.db.get_ticket_config(guild.id)
        if config and config['log_channel']:
            ch = guild.get_channel(config['log_channel'])
            if ch:
                try:
                    await ch.send(embed=embed)
                except Exception:
                    pass

    async def create_ticket(self, interaction: discord.Interaction, department: str):
        """Create a new ticket channel."""
        await interaction.response.defer(ephemeral=True)
        config = await self.db.get_ticket_config(interaction.guild.id)

        # Check if user already has open ticket
        user_tickets = await self.db.get_user_tickets(interaction.guild.id, interaction.user.id)
        open_tickets = [t for t in user_tickets if t['status'] == 'open']
        if open_tickets:
            existing_ch = interaction.guild.get_channel(open_tickets[0]['channel_id'])
            if existing_ch:
                return await interaction.followup.send(
                    embed=error_embed('تذكرة موجودة', f'لديك تذكرة مفتوحة بالفعل: {existing_ch.mention}'),
                    ephemeral=True)

        # Create the ticket channel
        category = None
        if config and config['category_id']:
            category = interaction.guild.get_channel(config['category_id'])

        support_role = None
        if config and config['support_role']:
            support_role = interaction.guild.get_role(config['support_role'])

        # Set permissions
        overwrites = {
            interaction.guild.default_role: discord.PermissionOverwrite(read_messages=False),
            interaction.user: discord.PermissionOverwrite(read_messages=True, send_messages=True, attach_files=True),
            interaction.guild.me: discord.PermissionOverwrite(read_messages=True, send_messages=True, manage_channels=True),
        }
        if support_role:
            overwrites[support_role] = discord.PermissionOverwrite(read_messages=True, send_messages=True)

        # Get next ticket number without creating a DB row yet
        ticket_config = await self.db.get_ticket_config(interaction.guild.id)
        ticket_number = (ticket_config['ticket_counter'] or 0) + 1

        channel_name = f'تذكرة-{ticket_number}-{interaction.user.display_name[:10]}'
        try:
            channel = await interaction.guild.create_text_channel(
                name=channel_name,
                category=category,
                overwrites=overwrites,
                topic=f'تذكرة #{ticket_number} | {interaction.user} | {department}'
            )
        except discord.Forbidden:
            return await interaction.followup.send(
                embed=error_embed('خطأ', 'البوت لا يملك صلاحية إنشاء روم.'), ephemeral=True)

        # Now create the ticket row with the real channel_id — no 0-placeholder bypass needed
        await self.db.create_ticket(
            interaction.guild.id, interaction.user.id, channel.id, department)

        embed = ticket_embed(ticket_number, interaction.user, department)
        if support_role:
            await channel.send(content=f'{interaction.user.mention} {support_role.mention}',
                               embed=embed, view=TicketControlView())
        else:
            await channel.send(content=interaction.user.mention, embed=embed, view=TicketControlView())

        await interaction.followup.send(
            embed=success_embed('تم إنشاء التذكرة', f'تم إنشاء تذكرتك: {channel.mention}'),
            ephemeral=True)

        # Log
        log_embed = discord.Embed(title='🎫 تذكرة جديدة', color=0x5865F2, timestamp=datetime.utcnow())
        log_embed.add_field(name='👤 العضو', value=f'{interaction.user.mention} (`{interaction.user.id}`)', inline=True)
        log_embed.add_field(name='📂 القسم', value=department, inline=True)
        log_embed.add_field(name='🔢 الرقم', value=f'#{ticket_number}', inline=True)
        log_embed.add_field(name='📋 الروم', value=channel.mention, inline=True)
        log_embed.set_footer(text='🛡️ OBT System')
        await self.send_log(interaction.guild, log_embed)

    async def close_ticket(self, interaction: discord.Interaction):
        ticket = await self.db.get_ticket(interaction.channel.id)
        if not ticket:
            return await interaction.response.send_message(
                embed=error_embed('خطأ', 'هذا ليس روم تذكرة.'), ephemeral=True)

        if ticket['status'] == 'closed':
            return await interaction.response.send_message(
                embed=error_embed('خطأ', 'هذه التذكرة مغلقة مسبقاً.'), ephemeral=True)

        await interaction.response.defer()

        # Remove user's write permission
        user = interaction.guild.get_member(ticket['user_id'])
        if user:
            try:
                await interaction.channel.set_permissions(user, send_messages=False)
            except Exception:
                pass

        await self.db.update_ticket(interaction.channel.id, status='closed',
                                    closed_at=datetime.utcnow().isoformat())

        close_embed = discord.Embed(
            title='🔒 تم إغلاق التذكرة',
            description=f'تم إغلاق التذكرة بواسطة {interaction.user.mention}',
            color=0xE74C3C,
            timestamp=datetime.utcnow()
        )
        await interaction.channel.send(embed=close_embed, view=ClosedTicketView())

        # Send rating DM to ticket creator
        config = await self.db.get_ticket_config(interaction.guild.id)
        if config and config['rating_enabled'] and user:
            try:
                rating_embed = discord.Embed(
                    title='⭐ تقييم الدعم',
                    description=f'كيف تقيّم تجربة دعمك في **{interaction.guild.name}**؟',
                    color=0xF1C40F
                )
                await user.send(embed=rating_embed, view=RatingView())
            except Exception:
                pass

        await interaction.followup.send(embed=success_embed('تم إغلاق التذكرة', ''))

    async def reopen_ticket(self, interaction: discord.Interaction):
        ticket = await self.db.get_ticket(interaction.channel.id)
        if not ticket or ticket['status'] != 'closed':
            return await interaction.response.send_message(
                embed=error_embed('خطأ', 'هذه التذكرة ليست مغلقة.'), ephemeral=True)

        user = interaction.guild.get_member(ticket['user_id'])
        if user:
            try:
                await interaction.channel.set_permissions(user, send_messages=True)
            except Exception:
                pass

        await self.db.update_ticket(interaction.channel.id, status='open', closed_at=None)

        embed = discord.Embed(
            title='🔓 تم إعادة فتح التذكرة',
            description=f'تم إعادة فتح التذكرة بواسطة {interaction.user.mention}',
            color=0x2ECC71,
            timestamp=datetime.utcnow()
        )
        await interaction.response.send_message(embed=embed, view=TicketControlView())

    async def delete_ticket(self, interaction: discord.Interaction):
        if not interaction.user.guild_permissions.manage_channels:
            return await interaction.response.send_message(
                embed=error_embed('خطأ', 'ليس لديك صلاحية حذف التذاكر.'), ephemeral=True)

        await interaction.response.send_message(
            embed=success_embed('جاري الحذف', 'سيتم حذف هذا الروم خلال 5 ثواني...'))
        await asyncio.sleep(5)
        try:
            await interaction.channel.delete(reason=f'حذف تذكرة بواسطة {interaction.user}')
        except Exception:
            pass

    async def save_transcript(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        messages = []
        async for msg in interaction.channel.history(limit=200, oldest_first=True):
            messages.append(f'[{msg.created_at.strftime("%Y-%m-%d %H:%M")}] {msg.author}: {msg.content}')

        transcript_text = '\n'.join(messages)
        transcript_file = discord.File(
            fp=__import__('io').BytesIO(transcript_text.encode()),
            filename=f'transcript-{interaction.channel.name}.txt'
        )

        await self.db.update_ticket(interaction.channel.id, transcript=transcript_text[:4000])

        await interaction.followup.send(
            content='📄 تم حفظ الـ Transcript:',
            file=transcript_file,
            ephemeral=True
        )

    async def handle_rating(self, interaction: discord.Interaction, stars: int):
        # Find the open ticket by user
        user_tickets = await self.db.get_user_tickets(interaction.guild_id or 0, interaction.user.id)
        if user_tickets:
            latest = user_tickets[0]
            await self.db.update_ticket(latest['channel_id'], rating=stars)
        await interaction.response.send_message(
            embed=success_embed('شكراً على تقييمك!', f'تقييمك: {"⭐" * stars}'),
            ephemeral=True)

    # ── Slash Commands ─────────────────────────────────────────────────────────

    tickets_group = app_commands.Group(name='تذاكر', description='نظام التذاكر')

    @tickets_group.command(name='لوحة', description='إرسال لوحة التذاكر في روم')
    @app_commands.describe(روم='الروم الذي سيتم إرسال اللوحة فيه')
    @app_commands.checks.has_permissions(administrator=True)
    async def ticket_panel(self, interaction: discord.Interaction, روم: discord.TextChannel = None):
        channel = روم or interaction.channel
        config = await self.db.get_ticket_config(interaction.guild.id)

        try:
            departments = json.loads(config['departments'] or '["عام","فني","إداري","شكاوى"]')
        except Exception:
            departments = ['عام', 'فني', 'إداري', 'شكاوى']

        embed = discord.Embed(
            title='🎫 نظام التذاكر',
            description=(
                '**مرحباً بك في نظام الدعم!**\n\n'
                'لفتح تذكرة دعم، اختر القسم المناسب من القائمة أدناه.\n\n'
                '📌 يُرجى توضيح مشكلتك بالتفصيل عند فتح التذكرة.'
            ),
            color=0x5865F2
        )
        embed.set_footer(text='🛡️ OBT System | نظام التذاكر')

        view = TicketView(departments)
        msg = await channel.send(embed=embed, view=view)
        await self.db.update_ticket_config(interaction.guild.id, panel_channel=channel.id,
                                           panel_message_id=msg.id)
        await interaction.response.send_message(
            embed=success_embed('تم إرسال اللوحة', f'تم إرسال لوحة التذاكر في {channel.mention}'),
            ephemeral=True)

    @tickets_group.command(name='إغلاق', description='إغلاق التذكرة الحالية')
    async def slash_close(self, interaction: discord.Interaction):
        await self.close_ticket(interaction)

    @tickets_group.command(name='إحصائيات', description='عرض إحصائيات التذاكر')
    @app_commands.checks.has_permissions(manage_guild=True)
    async def ticket_stats(self, interaction: discord.Interaction):
        config = await self.db.get_ticket_config(interaction.guild.id)
        counter = config['ticket_counter'] if config else 0

        embed = discord.Embed(title='📊 إحصائيات التذاكر', color=0x5865F2, timestamp=datetime.utcnow())
        embed.add_field(name='📋 إجمالي التذاكر', value=str(counter), inline=True)
        embed.set_footer(text='🛡️ OBT System')
        await interaction.response.send_message(embed=embed)

    @tickets_group.command(name='إعداد', description='إعداد نظام التذاكر')
    @app_commands.describe(
        الفئة='فئة الرومات للتذاكر',
        قسم_اللوقات='روم لوقات التذاكر',
        رتبة_الدعم='رتبة فريق الدعم'
    )
    @app_commands.checks.has_permissions(administrator=True)
    async def setup_tickets(self, interaction: discord.Interaction,
                            الفئة: discord.CategoryChannel = None,
                            قسم_اللوقات: discord.TextChannel = None,
                            رتبة_الدعم: discord.Role = None):
        kwargs = {}
        if الفئة:
            kwargs['category_id'] = الفئة.id
        if قسم_اللوقات:
            kwargs['log_channel'] = قسم_اللوقات.id
        if رتبة_الدعم:
            kwargs['support_role'] = رتبة_الدعم.id

        if kwargs:
            await self.db.update_ticket_config(interaction.guild.id, **kwargs)

        embed = success_embed('تم إعداد التذاكر', 'تم تحديث إعدادات نظام التذاكر بنجاح.')
        await interaction.response.send_message(embed=embed)


async def setup(bot):
    await bot.add_cog(Tickets(bot))
