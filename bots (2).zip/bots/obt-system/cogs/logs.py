"""
Logs Cog - نظام اللوقات
"""

import discord
from discord.ext import commands
from datetime import datetime


class Logs(commands.Cog, name='اللوقات'):
    def __init__(self, bot):
        self.bot = bot
        self.db = bot.db

    async def get_log_channel(self, guild_id: int, log_type: str):
        config = await self.db.get_log_config(guild_id)
        if not config:
            return None
        val = config[log_type] if log_type in config.keys() else None
        if not val:
            return None
        guild = self.bot.get_guild(guild_id)
        return guild.get_channel(val) if guild else None

    # ── Message Delete ─────────────────────────────────────────────────────────

    @commands.Cog.listener()
    async def on_message_delete(self, message: discord.Message):
        if not message.guild or message.author.bot:
            return
        channel = await self.get_log_channel(message.guild.id, 'delete_log')
        if not channel:
            return

        embed = discord.Embed(
            title='🗑️ رسالة محذوفة',
            color=0xE74C3C,
            timestamp=datetime.utcnow()
        )
        embed.add_field(name='👤 العضو', value=f'{message.author.mention} (`{message.author.id}`)', inline=True)
        embed.add_field(name='📋 الروم', value=message.channel.mention, inline=True)
        content = message.content or '*[لا يوجد نص]*'
        embed.add_field(name='📝 المحتوى', value=content[:1024], inline=False)
        embed.set_author(name=str(message.author), icon_url=message.author.display_avatar.url)
        embed.set_footer(text='🛡️ OBT System')
        await channel.send(embed=embed)

    # ── Message Edit ───────────────────────────────────────────────────────────

    @commands.Cog.listener()
    async def on_message_edit(self, before: discord.Message, after: discord.Message):
        if not before.guild or before.author.bot or before.content == after.content:
            return
        channel = await self.get_log_channel(before.guild.id, 'edit_log')
        if not channel:
            return

        embed = discord.Embed(
            title='✏️ رسالة معدّلة',
            color=0xF39C12,
            timestamp=datetime.utcnow()
        )
        embed.add_field(name='👤 العضو', value=f'{before.author.mention}', inline=True)
        embed.add_field(name='📋 الروم', value=before.channel.mention, inline=True)
        embed.add_field(name='📝 قبل', value=before.content[:512] or '*فارغ*', inline=False)
        embed.add_field(name='📝 بعد', value=after.content[:512] or '*فارغ*', inline=False)
        embed.add_field(name='🔗 الرابط', value=f'[انتقل للرسالة]({after.jump_url})', inline=True)
        embed.set_author(name=str(before.author), icon_url=before.author.display_avatar.url)
        embed.set_footer(text='🛡️ OBT System')
        await channel.send(embed=embed)

    # ── Channel Create ─────────────────────────────────────────────────────────

    @commands.Cog.listener()
    async def on_guild_channel_create(self, channel: discord.abc.GuildChannel):
        log_ch = await self.get_log_channel(channel.guild.id, 'channel_log')
        if not log_ch:
            return

        embed = discord.Embed(
            title='➕ روم جديد',
            color=0x2ECC71,
            timestamp=datetime.utcnow()
        )
        embed.add_field(name='📋 اسم الروم', value=channel.name, inline=True)
        embed.add_field(name='🔖 النوع', value=str(channel.type).replace('_', ' '), inline=True)
        embed.add_field(name='🆔 المعرف', value=str(channel.id), inline=True)

        # Try to get who created it via audit log
        try:
            async for entry in channel.guild.audit_logs(limit=1, action=discord.AuditLogAction.channel_create):
                embed.add_field(name='👤 المنشئ', value=entry.user.mention, inline=True)
        except Exception:
            pass

        embed.set_footer(text='🛡️ OBT System')
        await log_ch.send(embed=embed)

    # ── Channel Delete ─────────────────────────────────────────────────────────

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel: discord.abc.GuildChannel):
        log_ch = await self.get_log_channel(channel.guild.id, 'channel_log')
        if not log_ch:
            return

        embed = discord.Embed(
            title='➖ روم محذوف',
            color=0xE74C3C,
            timestamp=datetime.utcnow()
        )
        embed.add_field(name='📋 اسم الروم', value=channel.name, inline=True)
        embed.add_field(name='🔖 النوع', value=str(channel.type).replace('_', ' '), inline=True)
        embed.add_field(name='🆔 المعرف', value=str(channel.id), inline=True)

        try:
            async for entry in channel.guild.audit_logs(limit=1, action=discord.AuditLogAction.channel_delete):
                embed.add_field(name='👤 الحاذف', value=entry.user.mention, inline=True)
        except Exception:
            pass

        embed.set_footer(text='🛡️ OBT System')
        await log_ch.send(embed=embed)

    # ── Role Create ────────────────────────────────────────────────────────────

    @commands.Cog.listener()
    async def on_guild_role_create(self, role: discord.Role):
        log_ch = await self.get_log_channel(role.guild.id, 'role_log')
        if not log_ch:
            return

        embed = discord.Embed(
            title='➕ رتبة جديدة',
            color=role.color.value or 0x2ECC71,
            timestamp=datetime.utcnow()
        )
        embed.add_field(name='🎖️ اسم الرتبة', value=role.mention, inline=True)
        embed.add_field(name='🆔 المعرف', value=str(role.id), inline=True)

        try:
            async for entry in role.guild.audit_logs(limit=1, action=discord.AuditLogAction.role_create):
                embed.add_field(name='👤 المنشئ', value=entry.user.mention, inline=True)
        except Exception:
            pass

        embed.set_footer(text='🛡️ OBT System')
        await log_ch.send(embed=embed)

    # ── Role Delete ────────────────────────────────────────────────────────────

    @commands.Cog.listener()
    async def on_guild_role_delete(self, role: discord.Role):
        log_ch = await self.get_log_channel(role.guild.id, 'role_log')
        if not log_ch:
            return

        embed = discord.Embed(
            title='➖ رتبة محذوفة',
            color=0xE74C3C,
            timestamp=datetime.utcnow()
        )
        embed.add_field(name='🎖️ اسم الرتبة', value=role.name, inline=True)
        embed.add_field(name='🆔 المعرف', value=str(role.id), inline=True)

        try:
            async for entry in role.guild.audit_logs(limit=1, action=discord.AuditLogAction.role_delete):
                embed.add_field(name='👤 الحاذف', value=entry.user.mention, inline=True)
        except Exception:
            pass

        embed.set_footer(text='🛡️ OBT System')
        await log_ch.send(embed=embed)

    # ── Member Join ────────────────────────────────────────────────────────────

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        log_ch = await self.get_log_channel(member.guild.id, 'member_log')
        if not log_ch:
            return

        embed = discord.Embed(
            title='📥 عضو جديد',
            color=0x2ECC71,
            timestamp=datetime.utcnow()
        )
        embed.add_field(name='👤 العضو', value=f'{member.mention} (`{member.id}`)', inline=False)
        embed.add_field(name='📅 تاريخ الإنشاء', value=discord.utils.format_dt(member.created_at, 'R'), inline=True)
        embed.add_field(name='👥 إجمالي الأعضاء', value=str(member.guild.member_count), inline=True)
        embed.set_thumbnail(url=member.display_avatar.url)
        embed.set_footer(text='🛡️ OBT System')
        await log_ch.send(embed=embed)

    # ── Member Leave ───────────────────────────────────────────────────────────

    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member):
        log_ch = await self.get_log_channel(member.guild.id, 'member_log')
        if not log_ch:
            return

        roles = [r.mention for r in member.roles if r.name != '@everyone']
        embed = discord.Embed(
            title='📤 عضو غادر',
            color=0xE74C3C,
            timestamp=datetime.utcnow()
        )
        embed.add_field(name='👤 العضو', value=f'**{member}** (`{member.id}`)', inline=False)
        embed.add_field(name='📅 انضم في', value=discord.utils.format_dt(member.joined_at, 'R') if member.joined_at else 'غير معروف', inline=True)
        embed.add_field(name='👥 إجمالي الأعضاء', value=str(member.guild.member_count), inline=True)
        if roles:
            embed.add_field(name='🎖️ الرتب', value=', '.join(roles[:10]), inline=False)
        embed.set_thumbnail(url=member.display_avatar.url)
        embed.set_footer(text='🛡️ OBT System')
        await log_ch.send(embed=embed)

    # ── Member Update (nickname/roles) ─────────────────────────────────────────

    @commands.Cog.listener()
    async def on_member_update(self, before: discord.Member, after: discord.Member):
        if not before.guild:
            return

        # Nickname change
        if before.nick != after.nick:
            log_ch = await self.get_log_channel(before.guild.id, 'name_log')
            if log_ch:
                embed = discord.Embed(title='✏️ تغيير اسم العرض', color=0xF39C12, timestamp=datetime.utcnow())
                embed.add_field(name='👤 العضو', value=after.mention, inline=True)
                embed.add_field(name='📝 قبل', value=before.nick or before.name, inline=True)
                embed.add_field(name='📝 بعد', value=after.nick or after.name, inline=True)
                embed.set_thumbnail(url=after.display_avatar.url)
                embed.set_footer(text='🛡️ OBT System')
                await log_ch.send(embed=embed)

        # Roles change
        added = set(after.roles) - set(before.roles)
        removed = set(before.roles) - set(after.roles)
        if added or removed:
            log_ch = await self.get_log_channel(before.guild.id, 'role_log')
            if log_ch:
                embed = discord.Embed(title='🔄 تغيير رتب العضو', color=0x3498DB, timestamp=datetime.utcnow())
                embed.add_field(name='👤 العضو', value=after.mention, inline=True)
                if added:
                    embed.add_field(name='➕ مضافة', value=', '.join(r.mention for r in added), inline=False)
                if removed:
                    embed.add_field(name='➖ مزالة', value=', '.join(r.mention for r in removed), inline=False)
                embed.set_footer(text='🛡️ OBT System')
                await log_ch.send(embed=embed)

    # ── Ban / Unban ────────────────────────────────────────────────────────────

    @commands.Cog.listener()
    async def on_member_ban(self, guild: discord.Guild, user: discord.User):
        log_ch = await self.get_log_channel(guild.id, 'ban_log')
        if not log_ch:
            return

        embed = discord.Embed(title='🔨 حظر عضو', color=0xFF0000, timestamp=datetime.utcnow())
        embed.add_field(name='👤 العضو', value=f'{user.mention} (`{user.id}`)', inline=True)

        try:
            async for entry in guild.audit_logs(limit=1, action=discord.AuditLogAction.ban):
                if entry.target.id == user.id:
                    embed.add_field(name='🛡️ المشرف', value=entry.user.mention, inline=True)
                    embed.add_field(name='📝 السبب', value=entry.reason or 'لم يُذكر', inline=False)
        except Exception:
            pass

        embed.set_thumbnail(url=user.display_avatar.url)
        embed.set_footer(text='🛡️ OBT System')
        await log_ch.send(embed=embed)

    @commands.Cog.listener()
    async def on_member_unban(self, guild: discord.Guild, user: discord.User):
        log_ch = await self.get_log_channel(guild.id, 'ban_log')
        if not log_ch:
            return

        embed = discord.Embed(title='✅ فك حظر عضو', color=0x2ECC71, timestamp=datetime.utcnow())
        embed.add_field(name='👤 العضو', value=f'{user.mention} (`{user.id}`)', inline=True)
        embed.set_thumbnail(url=user.display_avatar.url)
        embed.set_footer(text='🛡️ OBT System')
        await log_ch.send(embed=embed)


async def setup(bot):
    await bot.add_cog(Logs(bot))
