"""
Points Cog - نظام النقاط
"""

import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime
from utils.embeds import success_embed, error_embed, leaderboard_embed


class Points(commands.Cog, name='النقاط'):
    def __init__(self, bot):
        self.bot = bot
        self.db = bot.db

    POINT_TYPES = {
        'أعضاء': 'member',
        'إدارة': 'admin',
        'كلانات': 'clan',
    }

    # ── /نقاط ─────────────────────────────────────────────────────────────────

    @app_commands.command(name='نقاط', description='عرض نقاط عضو')
    @app_commands.describe(عضو='العضو المراد عرض نقاطه', النوع='نوع النقاط')
    @app_commands.choices(النوع=[
        app_commands.Choice(name='نقاط الأعضاء', value='member'),
        app_commands.Choice(name='نقاط الإدارة', value='admin'),
        app_commands.Choice(name='نقاط الكلانات', value='clan'),
    ])
    async def show_points(self, interaction: discord.Interaction,
                          عضو: discord.Member = None, النوع: str = 'member'):
        target = عضو or interaction.user
        points = await self.db.get_points(interaction.guild.id, target.id, النوع)

        type_names = {'member': 'الأعضاء', 'admin': 'الإدارة', 'clan': 'الكلانات'}
        type_emojis = {'member': '⭐', 'admin': '🛡️', 'clan': '👑'}

        embed = discord.Embed(
            title=f'{type_emojis.get(النوع, "⭐")} نقاط {type_names.get(النوع, النوع)}',
            color=0xF1C40F,
            timestamp=datetime.utcnow()
        )
        embed.set_author(name=target.display_name, icon_url=target.display_avatar.url)
        embed.add_field(name='💰 النقاط', value=f'**{points:,}** نقطة', inline=True)

        # Leaderboard position
        leaderboard = await self.db.get_leaderboard(interaction.guild.id, النوع, 100)
        position = next((i + 1 for i, row in enumerate(leaderboard) if row['user_id'] == target.id), None)
        if position:
            embed.add_field(name='🏆 الترتيب', value=f'**#{position}**', inline=True)

        embed.set_footer(text='🛡️ OBT System')
        await interaction.response.send_message(embed=embed)

    # ── /إضافة_نقاط ───────────────────────────────────────────────────────────

    @app_commands.command(name='إضافة_نقاط', description='إضافة نقاط لعضو')
    @app_commands.describe(عضو='العضو', كمية='كمية النقاط', النوع='نوع النقاط', سبب='السبب')
    @app_commands.choices(النوع=[
        app_commands.Choice(name='نقاط الأعضاء', value='member'),
        app_commands.Choice(name='نقاط الإدارة', value='admin'),
        app_commands.Choice(name='نقاط الكلانات', value='clan'),
    ])
    @app_commands.checks.has_permissions(manage_guild=True)
    async def add_points(self, interaction: discord.Interaction,
                         عضو: discord.Member, كمية: int, النوع: str = 'member', سبب: str = 'لم يُذكر'):
        if كمية <= 0:
            return await interaction.response.send_message(
                embed=error_embed('خطأ', 'يجب أن تكون الكمية أكبر من 0.'), ephemeral=True)

        new_total = await self.db.add_points(interaction.guild.id, عضو.id, كمية, النوع)

        type_names = {'member': 'الأعضاء', 'admin': 'الإدارة', 'clan': 'الكلانات'}
        embed = success_embed(
            'تمت إضافة النقاط',
            f'تمت إضافة **{كمية:,}** نقطة {type_names.get(النوع, "")} لـ {عضو.mention}\n'
            f'**السبب:** {سبب}\n'
            f'**الرصيد الجديد:** {new_total:,} نقطة'
        )
        await interaction.response.send_message(embed=embed)

        # Check rewards
        await self.check_rewards(interaction.guild, عضو, new_total, النوع)

        # DM user
        try:
            dm = discord.Embed(
                title='💰 نقاط مضافة',
                description=f'تمت إضافة **{كمية:,}** نقطة {type_names.get(النوع, "")} في **{interaction.guild.name}**\n'
                           f'**السبب:** {سبب}\n**رصيدك الجديد:** {new_total:,}',
                color=0x2ECC71
            )
            await عضو.send(embed=dm)
        except Exception:
            pass

    # ── /خصم_نقاط ────────────────────────────────────────────────────────────

    @app_commands.command(name='خصم_نقاط', description='خصم نقاط من عضو')
    @app_commands.describe(عضو='العضو', كمية='كمية النقاط', النوع='نوع النقاط', سبب='السبب')
    @app_commands.choices(النوع=[
        app_commands.Choice(name='نقاط الأعضاء', value='member'),
        app_commands.Choice(name='نقاط الإدارة', value='admin'),
        app_commands.Choice(name='نقاط الكلانات', value='clan'),
    ])
    @app_commands.checks.has_permissions(manage_guild=True)
    async def remove_points(self, interaction: discord.Interaction,
                            عضو: discord.Member, كمية: int, النوع: str = 'member', سبب: str = 'لم يُذكر'):
        if كمية <= 0:
            return await interaction.response.send_message(
                embed=error_embed('خطأ', 'يجب أن تكون الكمية أكبر من 0.'), ephemeral=True)

        new_total = await self.db.remove_points(interaction.guild.id, عضو.id, كمية, النوع)
        type_names = {'member': 'الأعضاء', 'admin': 'الإدارة', 'clan': 'الكلانات'}
        embed = success_embed(
            'تم خصم النقاط',
            f'تم خصم **{كمية:,}** نقطة {type_names.get(النوع, "")} من {عضو.mention}\n'
            f'**السبب:** {سبب}\n'
            f'**الرصيد الجديد:** {new_total:,} نقطة'
        )
        await interaction.response.send_message(embed=embed)

    # ── /المتصدرين ────────────────────────────────────────────────────────────

    @app_commands.command(name='المتصدرين', description='عرض لوحة المتصدرين')
    @app_commands.describe(النوع='نوع النقاط')
    @app_commands.choices(النوع=[
        app_commands.Choice(name='نقاط الأعضاء', value='member'),
        app_commands.Choice(name='نقاط الإدارة', value='admin'),
        app_commands.Choice(name='نقاط الكلانات', value='clan'),
    ])
    async def leaderboard(self, interaction: discord.Interaction, النوع: str = 'member'):
        lb = await self.db.get_leaderboard(interaction.guild.id, النوع, 10)
        type_names = {'member': 'الأعضاء', 'admin': 'الإدارة', 'clan': 'الكلانات'}
        title = f'لوحة المتصدرين — نقاط {type_names.get(النوع, النوع)}'

        entries = [(row['user_id'], row['points']) for row in lb]
        embed = leaderboard_embed(title, entries, interaction.guild)
        await interaction.response.send_message(embed=embed)

    # ── /مكافآت ───────────────────────────────────────────────────────────────

    rewards_group = app_commands.Group(name='مكافآت', description='نظام المكافآت التلقائية')

    @rewards_group.command(name='إضافة', description='إضافة مكافأة تلقائية عند الوصول لعدد نقاط')
    @app_commands.describe(نقاط='عدد النقاط المطلوبة', رتبة='الرتبة الممنوحة', النوع='نوع النقاط')
    @app_commands.choices(النوع=[
        app_commands.Choice(name='نقاط الأعضاء', value='member'),
        app_commands.Choice(name='نقاط الإدارة', value='admin'),
        app_commands.Choice(name='نقاط الكلانات', value='clan'),
    ])
    @app_commands.checks.has_permissions(manage_guild=True)
    async def add_reward(self, interaction: discord.Interaction, نقاط: int, رتبة: discord.Role, النوع: str = 'member'):
        await self.db._conn.execute(
            "INSERT INTO point_rewards (guild_id, required_points, reward_role, point_type) VALUES (?, ?, ?, ?)",
            (interaction.guild.id, نقاط, رتبة.id, النوع)
        )
        await self.db._conn.commit()
        embed = success_embed('تمت إضافة المكافأة',
                              f'سيحصل الأعضاء على {رتبة.mention} عند بلوغ **{نقاط:,}** نقطة.')
        await interaction.response.send_message(embed=embed)

    @rewards_group.command(name='عرض', description='عرض المكافآت المتاحة')
    async def show_rewards(self, interaction: discord.Interaction):
        rewards = await self.db.get_point_rewards(interaction.guild.id)
        embed = discord.Embed(title='🎁 المكافآت التلقائية', color=0xF1C40F, timestamp=datetime.utcnow())
        if not rewards:
            embed.description = 'لا توجد مكافآت مضافة.'
        else:
            for r in rewards:
                role = interaction.guild.get_role(r['reward_role'])
                role_mention = role.mention if role else 'رتبة غير موجودة'
                embed.add_field(
                    name=f'💰 {r["required_points"]:,} نقطة',
                    value=f'🎖️ {role_mention} | نوع: {r["point_type"]}',
                    inline=False
                )
        embed.set_footer(text='🛡️ OBT System')
        await interaction.response.send_message(embed=embed)

    async def check_rewards(self, guild: discord.Guild, member: discord.Member,
                            points: int, point_type: str):
        """Check and apply point rewards."""
        rewards = await self.db.get_point_rewards(guild.id, point_type)
        for reward in rewards:
            if points >= reward['required_points']:
                role = guild.get_role(reward['reward_role'])
                if role and role not in member.roles:
                    try:
                        await member.add_roles(role, reason='مكافأة نقاط تلقائية')
                        dm = discord.Embed(
                            title='🎁 مكافأة جديدة!',
                            description=f'حصلت على رتبة **{role.name}** مكافأة على نقاطك في **{guild.name}**!',
                            color=0xF1C40F
                        )
                        await member.send(embed=dm)
                    except Exception:
                        pass


async def setup(bot):
    await bot.add_cog(Points(bot))
