"""
Fun Cog - ألعاب الدردشة والتسلية
Games: fast typing, math, capital cities, would you rather
"""

import discord
from discord import app_commands
from discord.ext import commands
import asyncio
import random
import time
from datetime import datetime
from utils.embeds import success_embed, error_embed


# ── Game Data ──────────────────────────────────────────────────────────────────

TYPING_SENTENCES = [
    'السماء زرقاء والبحر أزرق',
    'الكويت دولة عربية خليجية',
    'البرمجة مهارة المستقبل',
    'العلم نور والجهل ظلام',
    'النجاح ثمرة الصبر والمثابرة',
    'اللغة العربية أجمل اللغات',
    'الوحدة العربية أمل الشعوب',
    'القراءة غذاء العقل',
    'الصدق أساس كل فضيلة',
    'الوقت كالسيف إن لم تقطعه قطعك',
    'discord bot development is fun',
    'python is a great programming language',
    'coding every day improves your skills',
    'practice makes perfect always',
]

MATH_QUESTIONS = [
    (lambda: (a := random.randint(10, 99), b := random.randint(10, 99), f'{a} + {b}', a + b)),
    (lambda: (a := random.randint(20, 99), b := random.randint(10, a), f'{a} - {b}', a - b)),
    (lambda: (a := random.randint(2, 12), b := random.randint(2, 12), f'{a} × {b}', a * b)),
    (lambda: (a := random.randint(1, 10), b := random.randint(2, 10), f'{a*b} ÷ {b}', a)),
]

CAPITALS = [
    ('السعودية', 'الرياض'), ('الكويت', 'الكويت'), ('الإمارات', 'أبوظبي'),
    ('قطر', 'الدوحة'), ('البحرين', 'المنامة'), ('عُمان', 'مسقط'),
    ('العراق', 'بغداد'), ('سوريا', 'دمشق'), ('لبنان', 'بيروت'),
    ('الأردن', 'عمان'), ('مصر', 'القاهرة'), ('ليبيا', 'طرابلس'),
    ('تونس', 'تونس'), ('الجزائر', 'الجزائر'), ('المغرب', 'الرباط'),
    ('السودان', 'الخرطوم'), ('اليمن', 'صنعاء'), ('فلسطين', 'القدس'),
    ('فرنسا', 'باريس'), ('ألمانيا', 'برلين'), ('إيطاليا', 'روما'),
    ('إسبانيا', 'مدريد'), ('المملكة المتحدة', 'لندن'), ('روسيا', 'موسكو'),
    ('اليابان', 'طوكيو'), ('الصين', 'بكين'), ('الهند', 'نيودلهي'),
    ('أمريكا', 'واشنطن'), ('كندا', 'أوتاوا'), ('البرازيل', 'برازيليا'),
    ('أستراليا', 'كانبيرا'), ('تركيا', 'أنقرة'), ('إيران', 'طهران'),
    ('باكستان', 'إسلام آباد'), ('إندونيسيا', 'جاكرتا'),
]

WOULD_YOU_RATHER = [
    ('تملك ذاكرة فوتوغرافية', 'تملك ذكاء خارق'),
    ('تعيش في الماضي', 'تعيش في المستقبل'),
    ('تكون غني لكن وحيد', 'تكون فقير لكن محاط بأصدقاء'),
    ('تتكلم كل اللغات', 'تعزف كل الآلات الموسيقية'),
    ('تطير بدون أجنحة', 'تتنفس تحت الماء'),
    ('لا تأكل الحلو أبداً', 'لا تأكل المالح أبداً'),
    ('تسافر الفضاء', 'تغوص في أعمق المحيطات'),
    ('تكون مشهور لكن فقير', 'تكون غني لكن مجهول'),
    ('تعرف تاريخ وفاتك', 'تعرف تاريخ وفاة الآخرين'),
    ('تعيش 100 سنة بصحة متوسطة', 'تعيش 50 سنة بصحة ممتازة'),
    ('تكون قوي جداً', 'تكون سريع جداً'),
    ('تعلم كل شيء لكن تنسى سريعاً', 'تعلم القليل لكن لا تنساه أبداً'),
    ('تعيش بدون انترنت', 'تعيش بدون مكيف'),
    ('تقضي أسبوعاً في الصحراء', 'تقضي أسبوعاً في القطب الشمالي'),
    ('تملك قدرة قراءة الأفكار', 'تملك قدرة التحكم في الزمن'),
]

# Active game tracking: {channel_id: True}
_active_games: dict = {}


class Fun(commands.Cog, name='الترفيه'):
    def __init__(self, bot):
        self.bot = bot
        self.db = bot.db

    # ── /تحدي_كتابة ───────────────────────────────────────────────────────────

    @app_commands.command(name='تحدي_كتابة', description='تحدي سرعة الكتابة — من يكتب أولاً يفوز!')
    async def typing_race(self, interaction: discord.Interaction):
        if interaction.channel_id in _active_games:
            return await interaction.response.send_message(
                embed=error_embed('خطأ', 'يوجد لعبة نشطة بالفعل في هذا الروم!'), ephemeral=True)

        sentence = random.choice(TYPING_SENTENCES)
        _active_games[interaction.channel_id] = True

        embed = discord.Embed(
            title='⌨️ تحدي الكتابة السريعة!',
            description=f'**اكتب الجملة التالية بسرعة:**\n\n```{sentence}```\n\n⏱️ لديك **30 ثانية**!',
            color=0x3498DB,
            timestamp=datetime.utcnow()
        )
        embed.set_footer(text='🛡️ OBT System | الأول يفوز!')
        await interaction.response.send_message(embed=embed)

        def check(m):
            return (m.channel.id == interaction.channel_id and
                    not m.author.bot and
                    m.content.strip().lower() == sentence.lower())

        start_time = time.time()
        try:
            msg = await self.bot.wait_for('message', check=check, timeout=30.0)
            elapsed = round(time.time() - start_time, 2)
            wpm = round((len(sentence.split()) / elapsed) * 60)

            # Award XP for winning
            config = await self.db.get_xp_config(interaction.guild.id)
            if config and config['enabled']:
                await self.db.add_xp(interaction.guild.id, msg.author.id, 50)

            winner_embed = discord.Embed(
                title='🏆 فوز!',
                description=f'🎉 {msg.author.mention} فاز بتحدي الكتابة!\n'
                            f'⏱️ الوقت: **{elapsed}** ثانية\n'
                            f'📝 السرعة التقريبية: **{wpm}** كلمة/دقيقة\n'
                            f'⭐ حصلت على **50 XP**!',
                color=0x2ECC71,
                timestamp=datetime.utcnow()
            )
            winner_embed.set_thumbnail(url=msg.author.display_avatar.url)
            winner_embed.set_footer(text='🛡️ OBT System')
            await interaction.channel.send(embed=winner_embed)

        except asyncio.TimeoutError:
            timeout_embed = discord.Embed(
                title='⏰ انتهى الوقت!',
                description=f'لم يفز أحد هذه المرة!\nالجملة كانت:\n```{sentence}```',
                color=0xE74C3C
            )
            await interaction.channel.send(embed=timeout_embed)
        finally:
            _active_games.pop(interaction.channel_id, None)

    # ── /مسابقة_رياضيات ───────────────────────────────────────────────────────

    @app_commands.command(name='مسابقة_رياضيات', description='مسابقة رياضيات سريعة — من يجيب أولاً!')
    async def math_quiz(self, interaction: discord.Interaction):
        if interaction.channel_id in _active_games:
            return await interaction.response.send_message(
                embed=error_embed('خطأ', 'يوجد لعبة نشطة بالفعل في هذا الروم!'), ephemeral=True)

        _active_games[interaction.channel_id] = True

        # Generate question
        fn = random.choice(MATH_QUESTIONS)
        result = fn()
        _, _, question, answer = result

        embed = discord.Embed(
            title='🔢 مسابقة الرياضيات!',
            description=f'**ما هو ناتج:**\n\n# {question} = ؟\n\n⏱️ لديك **15 ثانية**!',
            color=0x9B59B6,
            timestamp=datetime.utcnow()
        )
        embed.set_footer(text='🛡️ OBT System | الأول يفوز!')
        await interaction.response.send_message(embed=embed)

        def check(m):
            if m.channel.id != interaction.channel_id or m.author.bot:
                return False
            try:
                return int(m.content.strip()) == answer
            except ValueError:
                return False

        start_time = time.time()
        try:
            msg = await self.bot.wait_for('message', check=check, timeout=15.0)
            elapsed = round(time.time() - start_time, 2)

            # Award XP
            config = await self.db.get_xp_config(interaction.guild.id)
            if config and config['enabled']:
                await self.db.add_xp(interaction.guild.id, msg.author.id, 30)

            win_embed = discord.Embed(
                title='🏆 إجابة صحيحة!',
                description=f'🎉 {msg.author.mention} أجاب صحيحاً!\n'
                            f'**{question} = {answer}**\n'
                            f'⏱️ في **{elapsed}** ثانية!\n'
                            f'⭐ حصلت على **30 XP**!',
                color=0x2ECC71,
                timestamp=datetime.utcnow()
            )
            win_embed.set_thumbnail(url=msg.author.display_avatar.url)
            win_embed.set_footer(text='🛡️ OBT System')
            await interaction.channel.send(embed=win_embed)

        except asyncio.TimeoutError:
            timeout_embed = discord.Embed(
                title='⏰ انتهى الوقت!',
                description=f'لم يجب أحد صحيحاً!\nالجواب: **{answer}**',
                color=0xE74C3C
            )
            await interaction.channel.send(embed=timeout_embed)
        finally:
            _active_games.pop(interaction.channel_id, None)

    # ── /عاصمة ────────────────────────────────────────────────────────────────

    @app_commands.command(name='عاصمة', description='مسابقة عواصم الدول — من يجيب أولاً!')
    async def capital_quiz(self, interaction: discord.Interaction):
        if interaction.channel_id in _active_games:
            return await interaction.response.send_message(
                embed=error_embed('خطأ', 'يوجد لعبة نشطة في هذا الروم!'), ephemeral=True)

        _active_games[interaction.channel_id] = True
        country, capital = random.choice(CAPITALS)
        # Acceptable answers (multiple forms)
        acceptable = {capital.lower(), capital.replace('ة', 'ه').lower()}

        embed = discord.Embed(
            title='🌍 مسابقة عواصم الدول!',
            description=f'ما هي عاصمة **{country}**؟\n\n⏱️ لديك **20 ثانية**!',
            color=0x1ABC9C,
            timestamp=datetime.utcnow()
        )
        embed.set_footer(text='🛡️ OBT System | الأول يفوز!')
        await interaction.response.send_message(embed=embed)

        def check(m):
            return (m.channel.id == interaction.channel_id and
                    not m.author.bot and
                    m.content.strip().lower() in acceptable)

        start_time = time.time()
        try:
            msg = await self.bot.wait_for('message', check=check, timeout=20.0)
            elapsed = round(time.time() - start_time, 2)

            # Award XP
            config = await self.db.get_xp_config(interaction.guild.id)
            if config and config['enabled']:
                await self.db.add_xp(interaction.guild.id, msg.author.id, 25)

            win_embed = discord.Embed(
                title='🏆 إجابة صحيحة!',
                description=f'🎉 {msg.author.mention} أجاب صحيحاً!\n'
                            f'عاصمة **{country}** هي **{capital}**!\n'
                            f'⏱️ في **{elapsed}** ثانية!\n'
                            f'⭐ حصلت على **25 XP**!',
                color=0x2ECC71,
                timestamp=datetime.utcnow()
            )
            win_embed.set_thumbnail(url=msg.author.display_avatar.url)
            win_embed.set_footer(text='🛡️ OBT System')
            await interaction.channel.send(embed=win_embed)

        except asyncio.TimeoutError:
            timeout_embed = discord.Embed(
                title='⏰ انتهى الوقت!',
                description=f'لم يجب أحد صحيحاً!\nعاصمة **{country}** هي **{capital}**',
                color=0xE74C3C
            )
            await interaction.channel.send(embed=timeout_embed)
        finally:
            _active_games.pop(interaction.channel_id, None)

    # ── /لو_خيروك ─────────────────────────────────────────────────────────────

    @app_commands.command(name='لو_خيروك', description='لو خيروك — اختر بين خيارين!')
    async def would_you_rather(self, interaction: discord.Interaction):
        option_a, option_b = random.choice(WOULD_YOU_RATHER)

        embed = discord.Embed(
            title='🤔 لو خيروك',
            color=0xE91E63,
            timestamp=datetime.utcnow()
        )
        embed.add_field(name='🅰️ الخيار الأول', value=option_a, inline=False)
        embed.add_field(name='🅱️ الخيار الثاني', value=option_b, inline=False)
        embed.set_footer(text='🛡️ OBT System | صوّت بـ 🅰️ أو 🅱️')

        await interaction.response.send_message(embed=embed)
        msg = await interaction.original_response()
        await msg.add_reaction('🅰️')
        await msg.add_reaction('🅱️')

    # ── /اقتباس ───────────────────────────────────────────────────────────────

    @app_commands.command(name='اقتباس', description='اقتباس عشوائي ملهم')
    async def quote(self, interaction: discord.Interaction):
        quotes = [
            ('النجاح ليس نهائياً، والفشل ليس قاتلاً، بل الشجاعة للاستمرار هي التي تهم.', 'ونستون تشرشل'),
            ('الفرصة لا تأتي، بل تُصنع.', 'كريس غروسر'),
            ('العقل كالمظلة، لا يعمل إلا إذا فُتح.', 'والت ليبيس'),
            ('إذا أردت أن تعيش حياة سعيدة، اربطها بهدف لا بأشخاص ولا بأشياء.', 'ألبرت أينشتاين'),
            ('أكبر مجد ليس في عدم السقوط بل في الارتفاع في كل مرة نسقط فيها.', 'نيلسون مانديلا'),
            ('لا تقيس نجاحك بما حققته بل بما تغلبت عليه.', 'بوكر تي واشنطن'),
            ('الشخص الذي يتحرك جبلاً يبدأ بحمل الحجارة الصغيرة.', 'مثل صيني'),
            ('إن لم تبنِ حلمك، سيوظفك أحد آخر لبناء حلمه.', 'توني غاسكينز'),
        ]
        text, author = random.choice(quotes)
        embed = discord.Embed(
            description=f'*"{text}"*',
            color=0x3498DB,
            timestamp=datetime.utcnow()
        )
        embed.set_footer(text=f'— {author} | 🛡️ OBT System')
        await interaction.response.send_message(embed=embed)

    # ── /نكتة ─────────────────────────────────────────────────────────────────

    @app_commands.command(name='نكتة', description='نكتة عشوائية')
    async def joke(self, interaction: discord.Interaction):
        jokes = [
            ('ليش المبرمج ما يحب الطبيعة؟', 'لأن فيها الكثير من البيقز (bugs)! 🐛'),
            ('ليش البرمجة مثل الحب؟', 'لأن كلاهما يبدأ بـ "Hello World" ثم تصير المشاكل! 💔'),
            ('كم مرة يحتاج البرمجي ليغير المصباح؟', 'لا شيء، ذلك مشكلة Hardware! 💡'),
            ('ليش المبرمجون يفضلون الظلام؟', 'لأن النور يعمل Bugs! 🌑'),
            ('ما الفرق بين البرمجي والبيتزا؟', 'البيتزا تطعم العيلة! 🍕'),
        ]
        setup, punchline = random.choice(jokes)
        embed = discord.Embed(title='😂 نكتة اليوم', color=0xF39C12, timestamp=datetime.utcnow())
        embed.add_field(name='السؤال', value=setup, inline=False)
        embed.add_field(name='الجواب', value=punchline, inline=False)
        embed.set_footer(text='🛡️ OBT System')
        await interaction.response.send_message(embed=embed)

    # ── Error handling ─────────────────────────────────────────────────────────

    @typing_race.error
    @math_quiz.error
    @capital_quiz.error
    async def game_error(self, interaction: discord.Interaction, error):
        _active_games.pop(interaction.channel_id, None)
        if isinstance(error, app_commands.CommandError):
            try:
                await interaction.response.send_message(
                    embed=error_embed('خطأ', str(error)), ephemeral=True)
            except Exception:
                pass


async def setup(bot):
    await bot.add_cog(Fun(bot))
