"""
Settings Cog - لوحة التحكم والإعدادات
"""

import discord
from discord import app_commands
from discord.ext import commands
import json
from datetime import datetime
from utils.embeds import success_embed, error_embed


class Settings(commands.Cog, name='الإعدادات'):
    def __init__(self, bot):
        self.bot = bot
        self.db = bot.db

    settings_group = app_commands.Group(name='إعدادات', description='لوحة التحكم الكاملة')

    # ── /إعدادات عرض ──────────────────────────────────────────────────────────

    @settings_group.command(name='عرض', description='عرض إعدادات السيرفر الحالية')
    @app_commands.checks.has_permissions(administrator=True)
    async def show_settings(self, interaction: discord.Interaction):
        guild_data = await self.db.get_guild(interaction.guild.id)

        def ch(channel_id):
            if not channel_id:
                return '❌ غير محدد'
            ch = interaction.guild.get_channel(channel_id)
            return ch.mention if ch else '❌ غير موجود'

        def role(role_id):
            if not role_id:
                return '❌ غير محدد'
            r = interaction.guild.get_role(role_id)
            return r.mention if r else '❌ غير موجود'

        embed = discord.Embed(
            title='⚙️ إعدادات السيرفر',
            color=0x5865F2,
            timestamp=datetime.utcnow()
        )
        embed.set_thumbnail(url=interaction.guild.icon.url if interaction.guild.icon else None)

        embed.add_field(name='🔤 البريفكس', value=f'`{guild_data["prefix"]}`', inline=True)
        embed.add_field(name='🌍 اللغة', value=guild_data['language'] or 'ar', inline=True)
        embed.add_field(name='\u200b', value='\u200b', inline=True)

        embed.add_field(name='📋 روم اللوق الرئيسي', value=ch(guild_data['log_channel']), inline=True)
        embed.add_field(name='👋 روم الترحيب', value=ch(guild_data['welcome_channel']), inline=True)
        embed.add_field(name='👋 روم الوداع', value=ch(guild_data['goodbye_channel']), inline=True)

        embed.add_field(name='✅ روم التحقق', value=ch(guild_data['verify_channel']), inline=True)
        embed.add_field(name='✅ رتبة التحقق', value=role(guild_data['verify_role']), inline=True)
        embed.add_field(name='🎖️ الرتبة التلقائية', value=role(guild_data['auto_role']), inline=True)

        embed.add_field(name='👥 عداد الأعضاء', value=ch(guild_data['member_counter_channel']), inline=True)
        embed.add_field(name='🤖 عداد البوتات', value=ch(guild_data['bot_counter_channel']), inline=True)
        embed.add_field(name='🔇 رتبة الكتم', value=role(guild_data['mute_role']), inline=True)

        embed.set_footer(text='🛡️ OBT System')
        await interaction.response.send_message(embed=embed)

    # ── /إعدادات لوق ──────────────────────────────────────────────────────────

    @settings_group.command(name='لوق', description='إعداد قنوات اللوقات')
    @app_commands.describe(
        النوع='نوع اللوق',
        الروم='الروم الذي سيتم إرسال اللوقات إليه'
    )
    @app_commands.choices(النوع=[
        app_commands.Choice(name='لوق الحظر', value='ban_log'),
        app_commands.Choice(name='لوق الطرد', value='kick_log'),
        app_commands.Choice(name='لوق حذف الرسائل', value='delete_log'),
        app_commands.Choice(name='لوق تعديل الرسائل', value='edit_log'),
        app_commands.Choice(name='لوق الرومات', value='channel_log'),
        app_commands.Choice(name='لوق الرتب', value='role_log'),
        app_commands.Choice(name='لوق دخول/خروج الأعضاء', value='member_log'),
        app_commands.Choice(name='لوق تغيير الأسماء', value='name_log'),
        app_commands.Choice(name='لوق الكتم', value='mute_log'),
        app_commands.Choice(name='لوق التذاكر', value='ticket_log'),
        app_commands.Choice(name='لوق الأوامر', value='command_log'),
        app_commands.Choice(name='لوق الدعوات', value='invite_log'),
    ])
    @app_commands.checks.has_permissions(administrator=True)
    async def set_log(self, interaction: discord.Interaction, النوع: str, الروم: discord.TextChannel):
        await self.db.set_log_channel(interaction.guild.id, النوع, الروم.id)

        log_names = {
            'ban_log': 'لوق الحظر', 'kick_log': 'لوق الطرد',
            'delete_log': 'لوق حذف الرسائل', 'edit_log': 'لوق تعديل الرسائل',
            'channel_log': 'لوق الرومات', 'role_log': 'لوق الرتب',
            'member_log': 'لوق دخول/خروج الأعضاء', 'name_log': 'لوق تغيير الأسماء',
            'mute_log': 'لوق الكتم', 'ticket_log': 'لوق التذاكر',
            'command_log': 'لوق الأوامر', 'invite_log': 'لوق الدعوات',
        }
        embed = success_embed(
            f'تم تعيين {log_names.get(النوع, النوع)}',
            f'سيتم إرسال {log_names.get(النوع, النوع)} في {الروم.mention}'
        )
        await interaction.response.send_message(embed=embed)

    # ── /إعدادات بريفكس ───────────────────────────────────────────────────────

    @settings_group.command(name='بريفكس', description='تغيير بريفكس البوت')
    @app_commands.describe(البريفكس='البريفكس الجديد')
    @app_commands.checks.has_permissions(administrator=True)
    async def set_prefix(self, interaction: discord.Interaction, البريفكس: str):
        if len(البريفكس) > 5:
            return await interaction.response.send_message(
                embed=error_embed('خطأ', 'البريفكس يجب أن يكون أقل من 5 أحرف.'), ephemeral=True)
        await self.db.update_guild(interaction.guild.id, prefix=البريفكس)
        embed = success_embed('تم تغيير البريفكس', f'البريفكس الجديد: `{البريفكس}`')
        await interaction.response.send_message(embed=embed)

    # ── /إعدادات عداد_أعضاء ───────────────────────────────────────────────────

    @settings_group.command(name='عداد_أعضاء', description='إعداد عداد الأعضاء والبوتات')
    @app_commands.describe(
        روم_الأعضاء='روم عداد الأعضاء البشريين',
        روم_البوتات='روم عداد البوتات'
    )
    @app_commands.checks.has_permissions(manage_channels=True)
    async def setup_counters(self, interaction: discord.Interaction,
                             روم_الأعضاء: discord.VoiceChannel = None,
                             روم_البوتات: discord.VoiceChannel = None):
        kwargs = {}
        if روم_الأعضاء:
            kwargs['member_counter_channel'] = روم_الأعضاء.id
        if روم_البوتات:
            kwargs['bot_counter_channel'] = روم_البوتات.id

        if kwargs:
            await self.db.update_guild(interaction.guild.id, **kwargs)

        total = interaction.guild.member_count
        bots = sum(1 for m in interaction.guild.members if m.bot)
        humans = total - bots

        if روم_الأعضاء:
            try:
                await روم_الأعضاء.edit(name=f'👥 الأعضاء: {humans}')
            except Exception:
                pass
        if روم_البوتات:
            try:
                await روم_البوتات.edit(name=f'🤖 البوتات: {bots}')
            except Exception:
                pass

        embed = success_embed('تم إعداد العداد', 'تم إعداد عدادات الأعضاء والبوتات.')
        await interaction.response.send_message(embed=embed)

    # ── /إعدادات لوق_رئيسي ────────────────────────────────────────────────────

    @settings_group.command(name='لوق_رئيسي', description='تعيين روم اللوق الرئيسي')
    @app_commands.describe(الروم='الروم الرئيسي للوقات')
    @app_commands.checks.has_permissions(administrator=True)
    async def set_main_log(self, interaction: discord.Interaction, الروم: discord.TextChannel):
        await self.db.update_guild(interaction.guild.id, log_channel=الروم.id)
        embed = success_embed('تم تعيين اللوق الرئيسي', f'اللوق الرئيسي: {الروم.mention}')
        await interaction.response.send_message(embed=embed)

    # ── /إعدادات رتبة_كتم ─────────────────────────────────────────────────────

    @settings_group.command(name='رتبة_كتم', description='تعيين رتبة الكتم')
    @app_commands.describe(رتبة='رتبة الكتم')
    @app_commands.checks.has_permissions(administrator=True)
    async def set_mute_role(self, interaction: discord.Interaction, رتبة: discord.Role):
        await self.db.update_guild(interaction.guild.id, mute_role=رتبة.id)
        embed = success_embed('تم تعيين رتبة الكتم', f'رتبة الكتم: {رتبة.mention}')
        await interaction.response.send_message(embed=embed)

    # ── /إعدادات تصدير ────────────────────────────────────────────────────────

    @settings_group.command(name='تصدير', description='تصدير إعدادات السيرفر (نسخة احتياطية)')
    @app_commands.checks.has_permissions(administrator=True)
    async def export_settings(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)

        guild_data = await self.db.get_guild(interaction.guild.id)
        protection = await self.db.get_protection(interaction.guild.id)
        log_config = await self.db.get_log_config(interaction.guild.id)
        ticket_config = await self.db.get_ticket_config(interaction.guild.id)

        backup = {
            'guild_id': interaction.guild.id,
            'guild_name': interaction.guild.name,
            'exported_at': datetime.utcnow().isoformat(),
            'settings': dict(guild_data) if guild_data else {},
            'protection': dict(protection) if protection else {},
            'logs': dict(log_config) if log_config else {},
            'tickets': dict(ticket_config) if ticket_config else {},
        }

        import io
        json_data = json.dumps(backup, ensure_ascii=False, indent=2)
        file = discord.File(
            fp=io.BytesIO(json_data.encode('utf-8')),
            filename=f'obt_backup_{interaction.guild.id}.json'
        )
        await interaction.followup.send(
            content='📦 نسخة احتياطية من إعدادات السيرفر:',
            file=file,
            ephemeral=True
        )

    # ── /إعدادات استعادة ──────────────────────────────────────────────────────

    @settings_group.command(name='استعادة', description='استعادة إعدادات من نسخة احتياطية')
    @app_commands.checks.has_permissions(administrator=True)
    async def restore_settings(self, interaction: discord.Interaction):
        embed = discord.Embed(
            title='♻️ استعادة الإعدادات',
            description='لاستعادة الإعدادات، استخدم الأمر `/إعدادات تصدير` أولاً للحصول على ملف الإعدادات، ثم تواصل مع المطور.',
            color=0xF39C12
        )
        embed.set_footer(text='🛡️ OBT System')
        await interaction.response.send_message(embed=embed, ephemeral=True)

    # ── /إعدادات معلومات ──────────────────────────────────────────────────────

    @settings_group.command(name='معلومات_البوت', description='معلومات البوت والإحصائيات')
    async def bot_info(self, interaction: discord.Interaction):
        bot = self.bot
        embed = discord.Embed(
            title='🛡️ OBT System',
            description='بوت عربي متكامل لإدارة السيرفرات',
            color=0x5865F2,
            timestamp=datetime.utcnow()
        )
        embed.set_thumbnail(url=bot.user.display_avatar.url)
        embed.add_field(name='🤖 اسم البوت', value=str(bot.user), inline=True)
        embed.add_field(name='🆔 المعرف', value=str(bot.user.id), inline=True)
        embed.add_field(name='🌐 السيرفرات', value=str(len(bot.guilds)), inline=True)
        embed.add_field(name='👥 إجمالي الأعضاء', value=str(sum(g.member_count for g in bot.guilds)), inline=True)
        embed.add_field(name='⏱️ البينق', value=f'{round(bot.latency * 1000)}ms', inline=True)
        embed.add_field(name='🐍 Python', value='3.11', inline=True)
        embed.add_field(name='📚 discord.py', value='2.x', inline=True)

        embed.add_field(name='✨ الأنظمة', value=(
            '🛡️ الإدارة | 📜 اللوقات | 🛡️ الحماية\n'
            '🎫 التذاكر | ⭐ النقاط | 👑 الكلانات\n'
            '🎥 صناع المحتوى | 💬 التفاعل | ⚙️ الإعدادات'
        ), inline=False)

        embed.set_footer(text='🛡️ OBT System | بوت عربي متكامل')
        await interaction.response.send_message(embed=embed)


async def setup(bot):
    await bot.add_cog(Settings(bot))
