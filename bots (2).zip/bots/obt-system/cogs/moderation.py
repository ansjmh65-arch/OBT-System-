"""
Moderation Cog - نظام الإدارة
Permission Tiers:
  - Moderator (moderate_members): mute, unmute, warn, unwarn, clear, slowmode — NO kick/ban
  - Senior Admin (ban_members): ban, unban, kick, lock, unlock
  - Admin (manage_guild): management config commands
  - Server Owner: everything
"""

import discord
from discord import app_commands
from discord.ext import commands
import asyncio
import json
from datetime import datetime, timedelta
from utils.embeds import success_embed, error_embed, mod_embed, warning_embed
from utils.helpers import parse_duration, format_duration, can_moderate


def is_senior_admin():
    """Slash-command check: ban_members OR administrator."""
    async def predicate(interaction: discord.Interaction):
        p = interaction.user.guild_permissions
        if p.administrator or p.ban_members:
            return True
        raise app_commands.MissingPermissions(['ban_members'])
    return app_commands.check(predicate)


def is_moderator():
    """Slash-command check: moderate_members OR ban_members OR administrator."""
    async def predicate(interaction: discord.Interaction):
        p = interaction.user.guild_permissions
        if p.administrator or p.ban_members or p.moderate_members:
            return True
        raise app_commands.MissingPermissions(['moderate_members'])
    return app_commands.check(predicate)


class Moderation(commands.Cog, name='الإدارة'):
    def __init__(self, bot):
        self.bot = bot
        self.db = bot.db

    async def send_log(self, guild: discord.Guild, log_type: str, embed: discord.Embed):
        config = await self.db.get_log_config(guild.id)
        if not config:
            return
        channel_id = config[log_type] if log_type in config.keys() else None
        if channel_id:
            channel = guild.get_channel(channel_id)
            if channel:
                try:
                    await channel.send(embed=embed)
                except Exception:
                    pass

    async def _notify_raid_tracker(self, guild: discord.Guild, member: discord.Member, action: str):
        """Notify anti-raid system of a destructive action."""
        if hasattr(self.bot, 'raid_tracker') and action in ('ban', 'kick'):
            await self.bot.raid_tracker.register_destructive_action(guild, member)

    # ══════════════════════════════════════════════════════════════════════
    # SENIOR ADMIN COMMANDS (ban_members required) — !ban, !unban, !kick
    # ══════════════════════════════════════════════════════════════════════

    # ── /حظر ──────────────────────────────────────────────────────────────────

    @app_commands.command(name='حظر', description='[إدارة عليا] حظر عضو من السيرفر')
    @app_commands.describe(عضو='العضو المراد حظره', سبب='سبب الحظر', حذف_الرسائل='حذف رسائله (0-7 أيام)')
    @is_senior_admin()
    async def ban(self, interaction: discord.Interaction, عضو: discord.Member,
                  سبب: str = 'لم يُذكر', حذف_الرسائل: int = 0):
        can, reason = can_moderate(interaction.user, عضو)
        if not can:
            return await interaction.response.send_message(embed=error_embed('خطأ', reason), ephemeral=True)

        delete_days = max(0, min(7, حذف_الرسائل))
        try:
            try:
                dm_embed = discord.Embed(
                    title='🔨 تم حظرك',
                    description=f'تم حظرك من **{interaction.guild.name}**\n**السبب:** {سبب}',
                    color=0xFF0000
                )
                await عضو.send(embed=dm_embed)
            except Exception:
                pass

            await عضو.ban(reason=f'{interaction.user}: {سبب}', delete_message_days=delete_days)
            await self.db.log_action(interaction.guild.id, interaction.user.id, عضو.id, 'ban', سبب)
            await self._notify_raid_tracker(interaction.guild, interaction.user, 'ban')

            embed = mod_embed('🔨 تم الحظر', عضو, interaction.user, سبب, 0xFF0000)
            await interaction.response.send_message(embed=embed)
            log_embed = mod_embed('🔨 لوق الحظر', عضو, interaction.user, سبب, 0xFF0000,
                                  [('🆔 معرف العضو', str(عضو.id), True)])
            await self.send_log(interaction.guild, 'ban_log', log_embed)
        except discord.Forbidden:
            await interaction.response.send_message(
                embed=error_embed('خطأ', 'البوت لا يملك صلاحية حظر هذا العضو.'), ephemeral=True)

    @commands.command(name='حظر', aliases=['ban'])
    @commands.has_permissions(ban_members=True)
    async def ban_prefix(self, ctx, عضو: discord.Member, *, سبب: str = 'لم يُذكر'):
        """[إدارة عليا] حظر عضو"""
        can, reason = can_moderate(ctx.author, عضو)
        if not can:
            return await ctx.send(embed=error_embed('خطأ', reason))
        try:
            await عضو.ban(reason=f'{ctx.author}: {سبب}')
            await self.db.log_action(ctx.guild.id, ctx.author.id, عضو.id, 'ban', سبب)
            await self._notify_raid_tracker(ctx.guild, ctx.author, 'ban')
            embed = mod_embed('🔨 تم الحظر', عضو, ctx.author, سبب, 0xFF0000)
            await ctx.send(embed=embed)
        except discord.Forbidden:
            await ctx.send(embed=error_embed('خطأ', 'البوت لا يملك صلاحية حظر هذا العضو.'))

    # ── /فك_حظر ───────────────────────────────────────────────────────────────

    @app_commands.command(name='فك_حظر', description='[إدارة عليا] فك حظر عضو')
    @app_commands.describe(معرف_العضو='معرف العضو المحظور', سبب='سبب فك الحظر')
    @is_senior_admin()
    async def unban(self, interaction: discord.Interaction, معرف_العضو: str, سبب: str = 'لم يُذكر'):
        try:
            user_id = int(معرف_العضو)
            user = await self.bot.fetch_user(user_id)
            await interaction.guild.unban(user, reason=f'{interaction.user}: {سبب}')
            embed = success_embed('✅ تم فك الحظر', f'تم فك حظر **{user}**\n**السبب:** {سبب}')
            await interaction.response.send_message(embed=embed)
        except ValueError:
            await interaction.response.send_message(
                embed=error_embed('خطأ', 'معرف العضو غير صحيح.'), ephemeral=True)
        except discord.NotFound:
            await interaction.response.send_message(
                embed=error_embed('خطأ', 'هذا العضو ليس محظوراً.'), ephemeral=True)

    @commands.command(name='فك_حظر', aliases=['unban'])
    @commands.has_permissions(ban_members=True)
    async def unban_prefix(self, ctx, user_id: int, *, سبب: str = 'لم يُذكر'):
        """[إدارة عليا] فك حظر عضو"""
        try:
            user = await self.bot.fetch_user(user_id)
            await ctx.guild.unban(user, reason=f'{ctx.author}: {سبب}')
            await ctx.send(embed=success_embed('✅ تم فك الحظر', f'تم فك حظر **{user}**'))
        except Exception as e:
            await ctx.send(embed=error_embed('خطأ', str(e)))

    # ── /طرد — SENIOR ADMIN ONLY, NOT for moderators ──────────────────────────

    @app_commands.command(name='طرد', description='[إدارة عليا] طرد عضو من السيرفر')
    @app_commands.describe(عضو='العضو المراد طرده', سبب='سبب الطرد')
    @is_senior_admin()
    async def kick(self, interaction: discord.Interaction, عضو: discord.Member, سبب: str = 'لم يُذكر'):
        can, reason = can_moderate(interaction.user, عضو)
        if not can:
            return await interaction.response.send_message(embed=error_embed('خطأ', reason), ephemeral=True)

        try:
            try:
                dm_embed = discord.Embed(
                    title='👢 تم طردك',
                    description=f'تم طردك من **{interaction.guild.name}**\n**السبب:** {سبب}',
                    color=0xFF6600
                )
                await عضو.send(embed=dm_embed)
            except Exception:
                pass

            await عضو.kick(reason=f'{interaction.user}: {سبب}')
            await self.db.log_action(interaction.guild.id, interaction.user.id, عضو.id, 'kick', سبب)
            await self._notify_raid_tracker(interaction.guild, interaction.user, 'kick')

            embed = mod_embed('👢 تم الطرد', عضو, interaction.user, سبب, 0xFF6600)
            await interaction.response.send_message(embed=embed)
            log_embed = mod_embed('👢 لوق الطرد', عضو, interaction.user, سبب, 0xFF6600,
                                  [('🆔 معرف العضو', str(عضو.id), True)])
            await self.send_log(interaction.guild, 'kick_log', log_embed)
        except discord.Forbidden:
            await interaction.response.send_message(
                embed=error_embed('خطأ', 'البوت لا يملك صلاحية طرد هذا العضو.'), ephemeral=True)

    # ── /قفل / /فتح — Senior Admin ────────────────────────────────────────────

    @app_commands.command(name='قفل', description='[إدارة عليا] قفل روم')
    @app_commands.describe(روم='الروم', سبب='سبب القفل')
    @is_senior_admin()
    async def lock(self, interaction: discord.Interaction,
                   روم: discord.TextChannel = None, سبب: str = 'لم يُذكر'):
        channel = روم or interaction.channel
        overwrite = channel.overwrites_for(interaction.guild.default_role)
        overwrite.send_messages = False
        await channel.set_permissions(interaction.guild.default_role, overwrite=overwrite,
                                      reason=f'{interaction.user}: {سبب}')
        embed = success_embed('🔒 تم قفل الروم', f'تم قفل {channel.mention}\n**السبب:** {سبب}')
        await interaction.response.send_message(embed=embed)
        await channel.send(embed=discord.Embed(
            description=f'🔒 تم قفل هذا الروم بواسطة {interaction.user.mention} | **السبب:** {سبب}',
            color=0xFF0000))

    @commands.command(name='قفل', aliases=['lock'])
    @commands.has_permissions(manage_channels=True)
    async def lock_prefix(self, ctx, *, سبب: str = 'لم يُذكر'):
        overwrite = ctx.channel.overwrites_for(ctx.guild.default_role)
        overwrite.send_messages = False
        await ctx.channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)
        await ctx.send(embed=success_embed('🔒 تم قفل الروم',
                                           f'{ctx.channel.mention}\n**السبب:** {سبب}'))

    @app_commands.command(name='فتح', description='[إدارة عليا] فتح روم')
    @app_commands.describe(روم='الروم', سبب='سبب الفتح')
    @is_senior_admin()
    async def unlock(self, interaction: discord.Interaction,
                     روم: discord.TextChannel = None, سبب: str = 'لم يُذكر'):
        channel = روم or interaction.channel
        overwrite = channel.overwrites_for(interaction.guild.default_role)
        overwrite.send_messages = None
        await channel.set_permissions(interaction.guild.default_role, overwrite=overwrite,
                                      reason=f'{interaction.user}: {سبب}')
        embed = success_embed('🔓 تم فتح الروم', f'تم فتح {channel.mention}\n**السبب:** {سبب}')
        await interaction.response.send_message(embed=embed)
        await channel.send(embed=discord.Embed(
            description=f'🔓 تم فتح هذا الروم بواسطة {interaction.user.mention}',
            color=0x2ECC71))

    @commands.command(name='فتح', aliases=['unlock'])
    @commands.has_permissions(manage_channels=True)
    async def unlock_prefix(self, ctx, *, سبب: str = 'لم يُذكر'):
        overwrite = ctx.channel.overwrites_for(ctx.guild.default_role)
        overwrite.send_messages = None
        await ctx.channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)
        await ctx.send(embed=success_embed('🔓 تم فتح الروم', ctx.channel.mention))

    # ══════════════════════════════════════════════════════════════════════
    # MODERATOR COMMANDS (moderate_members) — mute, unmute, warn, clear, slowmode
    # ══════════════════════════════════════════════════════════════════════

    # ── /كتم ──────────────────────────────────────────────────────────────────

    @app_commands.command(name='كتم', description='[مشرف] كتم عضو')
    @app_commands.describe(عضو='العضو', مدة='المدة (10m, 2h, 1d)', سبب='السبب')
    @is_moderator()
    async def mute(self, interaction: discord.Interaction, عضو: discord.Member,
                   مدة: str = '10m', سبب: str = 'لم يُذكر'):
        can, reason = can_moderate(interaction.user, عضو)
        if not can:
            return await interaction.response.send_message(embed=error_embed('خطأ', reason), ephemeral=True)

        seconds = parse_duration(مدة)
        if not seconds:
            return await interaction.response.send_message(
                embed=error_embed('خطأ', 'صيغة المدة غير صحيحة. أمثلة: `10m`, `2h`, `1d`'), ephemeral=True)
        if seconds > 2419200:
            return await interaction.response.send_message(
                embed=error_embed('خطأ', 'الحد الأقصى 28 يوم.'), ephemeral=True)

        try:
            until = discord.utils.utcnow() + timedelta(seconds=seconds)
            await عضو.timeout(until, reason=f'{interaction.user}: {سبب}')
            await self.db.log_action(interaction.guild.id, interaction.user.id, عضو.id, 'mute', سبب)
            formatted = format_duration(seconds)
            embed = mod_embed('🔇 تم الكتم', عضو, interaction.user, سبب, 0xFFA500,
                              [('⏱️ المدة', formatted, True)])
            await interaction.response.send_message(embed=embed)
            log_embed = mod_embed('🔇 لوق الكتم', عضو, interaction.user, سبب, 0xFFA500,
                                  [('⏱️ المدة', formatted, True), ('🆔 معرف', str(عضو.id), True)])
            await self.send_log(interaction.guild, 'mute_log', log_embed)
        except discord.Forbidden:
            await interaction.response.send_message(
                embed=error_embed('خطأ', 'البوت لا يملك صلاحية كتم هذا العضو.'), ephemeral=True)

    @commands.command(name='كتم', aliases=['mute'])
    @commands.has_permissions(moderate_members=True)
    async def mute_prefix(self, ctx, عضو: discord.Member, مدة: str = '10m', *, سبب: str = 'لم يُذكر'):
        """[مشرف] كتم عضو"""
        seconds = parse_duration(مدة)
        if not seconds:
            return await ctx.send(embed=error_embed('خطأ', 'صيغة المدة غير صحيحة.'))
        try:
            until = discord.utils.utcnow() + timedelta(seconds=seconds)
            await عضو.timeout(until, reason=f'{ctx.author}: {سبب}')
            await self.db.log_action(ctx.guild.id, ctx.author.id, عضو.id, 'mute', سبب)
            await ctx.send(embed=mod_embed('🔇 تم الكتم', عضو, ctx.author, سبب, 0xFFA500,
                                           [('⏱️ المدة', format_duration(seconds), True)]))
        except discord.Forbidden:
            await ctx.send(embed=error_embed('خطأ', 'لا أملك صلاحية كتم هذا العضو.'))

    # ── /فك_كتم ───────────────────────────────────────────────────────────────

    @app_commands.command(name='فك_كتم', description='[مشرف] فك كتم عضو')
    @app_commands.describe(عضو='العضو', سبب='السبب')
    @is_moderator()
    async def unmute(self, interaction: discord.Interaction, عضو: discord.Member, سبب: str = 'لم يُذكر'):
        if not عضو.is_timed_out():
            return await interaction.response.send_message(
                embed=error_embed('خطأ', 'هذا العضو غير مكتوم.'), ephemeral=True)
        try:
            await عضو.timeout(None, reason=f'{interaction.user}: {سبب}')
            await self.db.log_action(interaction.guild.id, interaction.user.id, عضو.id, 'unmute', سبب)
            embed = mod_embed('🔊 تم فك الكتم', عضو, interaction.user, سبب, 0x2ECC71)
            await interaction.response.send_message(embed=embed)
            await self.send_log(interaction.guild, 'mute_log', embed)
        except discord.Forbidden:
            await interaction.response.send_message(
                embed=error_embed('خطأ', 'البوت لا يملك الصلاحية.'), ephemeral=True)

    @commands.command(name='فك_كتم', aliases=['unmute'])
    @commands.has_permissions(moderate_members=True)
    async def unmute_prefix(self, ctx, عضو: discord.Member, *, سبب: str = 'لم يُذكر'):
        """[مشرف] فك كتم عضو"""
        if not عضو.is_timed_out():
            return await ctx.send(embed=error_embed('خطأ', 'هذا العضو غير مكتوم.'))
        await عضو.timeout(None, reason=f'{ctx.author}: {سبب}')
        await self.db.log_action(ctx.guild.id, ctx.author.id, عضو.id, 'unmute', سبب)
        await ctx.send(embed=mod_embed('🔊 تم فك الكتم', عضو, ctx.author, سبب, 0x2ECC71))

    # ── /تحذير ────────────────────────────────────────────────────────────────

    @app_commands.command(name='تحذير', description='[مشرف] تحذير عضو')
    @app_commands.describe(عضو='العضو', سبب='السبب')
    @is_moderator()
    async def warn(self, interaction: discord.Interaction, عضو: discord.Member, سبب: str = 'لم يُذكر'):
        can, reason = can_moderate(interaction.user, عضو)
        if not can:
            return await interaction.response.send_message(embed=error_embed('خطأ', reason), ephemeral=True)

        warn_count = await self.db.add_warning(interaction.guild.id, عضو.id, interaction.user.id, سبب)
        await self.db.log_action(interaction.guild.id, interaction.user.id, عضو.id, 'warn', سبب)

        embed = mod_embed('⚠️ تحذير', عضو, interaction.user, سبب, 0xFFA500,
                          [('📊 إجمالي التحذيرات', str(warn_count), True)])
        await interaction.response.send_message(embed=embed)

        protection = await self.db.get_protection(interaction.guild.id)
        warn_limit = protection['warn_limit'] if protection else 3
        if warn_count >= warn_limit:
            action = protection['warn_action'] if protection else 'mute'
            await self._apply_warn_action(interaction.guild, عضو, action, warn_count)

        try:
            dm = discord.Embed(
                title='⚠️ تحذير',
                description=f'تلقيت تحذيراً في **{interaction.guild.name}**\n'
                            f'**السبب:** {سبب}\n**إجمالي التحذيرات:** {warn_count}',
                color=0xFFA500
            )
            await عضو.send(embed=dm)
        except Exception:
            pass

        log_embed = mod_embed('⚠️ لوق التحذير', عضو, interaction.user, سبب, 0xFFA500,
                              [('📊 إجمالي', str(warn_count), True)])
        await self.send_log(interaction.guild, 'command_log', log_embed)

    @commands.command(name='تحذير', aliases=['warn'])
    @commands.has_permissions(moderate_members=True)
    async def warn_prefix(self, ctx, عضو: discord.Member, *, سبب: str = 'لم يُذكر'):
        """[مشرف] تحذير عضو"""
        warn_count = await self.db.add_warning(ctx.guild.id, عضو.id, ctx.author.id, سبب)
        await self.db.log_action(ctx.guild.id, ctx.author.id, عضو.id, 'warn', سبب)
        await ctx.send(embed=mod_embed('⚠️ تحذير', عضو, ctx.author, سبب, 0xFFA500,
                                       [('📊 إجمالي', str(warn_count), True)]))

        protection = await self.db.get_protection(ctx.guild.id)
        warn_limit = protection['warn_limit'] if protection else 3
        if warn_count >= warn_limit:
            action = protection['warn_action'] if protection else 'mute'
            await self._apply_warn_action(ctx.guild, عضو, action, warn_count)

    async def _apply_warn_action(self, guild, member, action, warn_count):
        try:
            if action == 'mute':
                until = discord.utils.utcnow() + timedelta(hours=1)
                await member.timeout(until, reason=f'وصل لحد التحذيرات ({warn_count})')
            elif action == 'kick':
                await member.kick(reason=f'وصل لحد التحذيرات ({warn_count})')
            elif action == 'ban':
                await member.ban(reason=f'وصل لحد التحذيرات ({warn_count})')
        except Exception:
            pass

    # ── /إزالة_تحذير ──────────────────────────────────────────────────────────

    @app_commands.command(name='إزالة_تحذير', description='[مشرف] إزالة تحذير')
    @app_commands.describe(رقم_التحذير='رقم التحذير', عضو='العضو')
    @is_moderator()
    async def remove_warning(self, interaction: discord.Interaction,
                              رقم_التحذير: int, عضو: discord.Member):
        await self.db.remove_warning(رقم_التحذير, interaction.guild.id)
        count = await self.db.get_warning_count(interaction.guild.id, عضو.id)
        embed = success_embed(
            'تم إزالة التحذير',
            f'تمت إزالة التحذير **#{رقم_التحذير}** من {عضو.mention}\n**المتبقي:** {count} تحذير'
        )
        await interaction.response.send_message(embed=embed)

    @commands.command(name='إزالة_تحذير', aliases=['unwarn', 'removewarn'])
    @commands.has_permissions(moderate_members=True)
    async def remove_warning_prefix(self, ctx, رقم_التحذير: int, عضو: discord.Member = None):
        """[مشرف] إزالة تحذير"""
        await self.db.remove_warning(رقم_التحذير, ctx.guild.id)
        await ctx.send(embed=success_embed('تم إزالة التحذير', f'تمت إزالة التحذير **#{رقم_التحذير}**'))

    # ── /التحذيرات ────────────────────────────────────────────────────────────

    @app_commands.command(name='التحذيرات', description='عرض تحذيرات عضو')
    @app_commands.describe(عضو='العضو')
    @is_moderator()
    async def warnings(self, interaction: discord.Interaction, عضو: discord.Member):
        warns = await self.db.get_warnings(interaction.guild.id, عضو.id)
        embed = discord.Embed(
            title=f'⚠️ تحذيرات {عضو.display_name}',
            color=0xFFA500,
            timestamp=datetime.utcnow()
        )
        embed.set_thumbnail(url=عضو.display_avatar.url)
        if not warns:
            embed.description = 'لا توجد تحذيرات.'
        else:
            for warn in warns[:10]:
                mod = interaction.guild.get_member(warn['moderator_id'])
                mod_name = mod.display_name if mod else f"<@{warn['moderator_id']}>"
                embed.add_field(
                    name=f'#{warn["id"]} — {warn["timestamp"][:10]}',
                    value=f'**السبب:** {warn["reason"]}\n**المشرف:** {mod_name}',
                    inline=False
                )
        embed.set_footer(text=f'🛡️ OBT System | إجمالي: {len(warns)} تحذير')
        await interaction.response.send_message(embed=embed)

    # ── /مسح ──────────────────────────────────────────────────────────────────

    @app_commands.command(name='مسح', description='[مشرف] مسح رسائل من الروم')
    @app_commands.describe(عدد='عدد الرسائل (1-100)', عضو='مسح رسائل عضو محدد فقط')
    @is_moderator()
    async def clear(self, interaction: discord.Interaction, عدد: int, عضو: discord.Member = None):
        if عدد < 1 or عدد > 100:
            return await interaction.response.send_message(
                embed=error_embed('خطأ', 'يجب أن يكون العدد بين 1 و 100.'), ephemeral=True)

        await interaction.response.defer(ephemeral=True)

        def check(m):
            return m.author.id == عضو.id if عضو else True

        deleted = await interaction.channel.purge(limit=عدد, check=check)
        embed = success_embed('تم المسح', f'تم مسح **{len(deleted)}** رسالة من {interaction.channel.mention}')
        await interaction.followup.send(embed=embed, ephemeral=True)

        log_embed = discord.Embed(title='🗑️ لوق مسح الرسائل', color=0xFF6600, timestamp=datetime.utcnow())
        log_embed.add_field(name='📋 الروم', value=interaction.channel.mention, inline=True)
        log_embed.add_field(name='📊 العدد', value=str(len(deleted)), inline=True)
        log_embed.add_field(name='🛡️ المشرف', value=interaction.user.mention, inline=True)
        if عضو:
            log_embed.add_field(name='👤 العضو', value=عضو.mention, inline=True)
        log_embed.set_footer(text='🛡️ OBT System')
        await self.send_log(interaction.guild, 'delete_log', log_embed)

    @commands.command(name='مسح', aliases=['clear', 'purge'])
    @commands.has_permissions(manage_messages=True)
    async def clear_prefix(self, ctx, عدد: int = 5):
        """[مشرف] مسح رسائل"""
        if عدد < 1 or عدد > 100:
            return await ctx.send(embed=error_embed('خطأ', 'العدد يجب أن يكون بين 1 و 100.'))
        await ctx.message.delete()
        deleted = await ctx.channel.purge(limit=عدد)
        msg = await ctx.send(embed=success_embed('تم المسح', f'تم مسح **{len(deleted)}** رسالة'))
        await asyncio.sleep(3)
        try:
            await msg.delete()
        except Exception:
            pass

    # ── /إبطاء — MODERATOR ────────────────────────────────────────────────────

    @app_commands.command(name='إبطاء', description='[مشرف] تعيين وضع التباطؤ في الروم')
    @app_commands.describe(ثواني='التأخير بالثواني (0 لإلغاء، حد أقصى 21600)', روم='الروم المستهدف')
    @is_moderator()
    async def slowmode(self, interaction: discord.Interaction,
                       ثواني: int, روم: discord.TextChannel = None):
        channel = روم or interaction.channel
        if not isinstance(channel, discord.TextChannel):
            return await interaction.response.send_message(
                embed=error_embed('خطأ', 'يجب أن يكون الروم قناة نصية.'), ephemeral=True)
        if ثواني < 0 or ثواني > 21600:
            return await interaction.response.send_message(
                embed=error_embed('خطأ', 'التأخير يجب أن يكون بين 0 و 21600 ثانية.'), ephemeral=True)

        await channel.edit(slowmode_delay=ثواني, reason=f'{interaction.user}: إعداد التباطؤ')
        if ثواني == 0:
            msg = f'تم إلغاء وضع التباطؤ في {channel.mention}'
        else:
            msg = f'تم تعيين وضع التباطؤ إلى **{ثواني}** ثانية في {channel.mention}'
        await interaction.response.send_message(embed=success_embed('🐌 وضع التباطؤ', msg))

    @commands.command(name='إبطاء', aliases=['slowmode', 'slow'])
    @commands.has_permissions(manage_channels=True)
    async def slowmode_prefix(self, ctx, ثواني: int = 0):
        """[مشرف] وضع التباطؤ"""
        if ثواني < 0 or ثواني > 21600:
            return await ctx.send(embed=error_embed('خطأ', 'يجب بين 0 و 21600.'))
        await ctx.channel.edit(slowmode_delay=ثواني)
        if ثواني == 0:
            await ctx.send(embed=success_embed('🐌 إلغاء التباطؤ', f'تم إلغاء وضع التباطؤ.'))
        else:
            await ctx.send(embed=success_embed('🐌 وضع التباطؤ', f'تم التعيين إلى **{ثواني}** ثانية'))

    # ── Role management — Admin ────────────────────────────────────────────────

    @app_commands.command(name='إضافة_رتبة', description='[إدارة] إضافة رتبة لعضو')
    @app_commands.describe(عضو='العضو', رتبة='الرتبة')
    @app_commands.checks.has_permissions(manage_roles=True)
    async def add_role(self, interaction: discord.Interaction, عضو: discord.Member, رتبة: discord.Role):
        if رتبة >= interaction.guild.me.top_role:
            return await interaction.response.send_message(
                embed=error_embed('خطأ', 'لا أستطيع إضافة هذه الرتبة (أعلى من رتبتي).'), ephemeral=True)
        if رتبة in عضو.roles:
            return await interaction.response.send_message(
                embed=error_embed('خطأ', 'العضو يملك هذه الرتبة مسبقاً.'), ephemeral=True)
        await عضو.add_roles(رتبة, reason=f'{interaction.user}: إضافة رتبة')
        embed = success_embed('✅ تم إضافة الرتبة', f'تمت إضافة {رتبة.mention} لـ {عضو.mention}')
        await interaction.response.send_message(embed=embed)
        log = discord.Embed(title='➕ إضافة رتبة', color=0x2ECC71, timestamp=datetime.utcnow())
        log.add_field(name='👤 العضو', value=عضو.mention, inline=True)
        log.add_field(name='🎖️ الرتبة', value=رتبة.mention, inline=True)
        log.add_field(name='🛡️ المشرف', value=interaction.user.mention, inline=True)
        log.set_footer(text='🛡️ OBT System')
        await self.send_log(interaction.guild, 'role_log', log)

    @app_commands.command(name='إزالة_رتبة', description='[إدارة] إزالة رتبة من عضو')
    @app_commands.describe(عضو='العضو', رتبة='الرتبة')
    @app_commands.checks.has_permissions(manage_roles=True)
    async def remove_role(self, interaction: discord.Interaction, عضو: discord.Member, رتبة: discord.Role):
        if رتبة not in عضو.roles:
            return await interaction.response.send_message(
                embed=error_embed('خطأ', 'العضو لا يملك هذه الرتبة.'), ephemeral=True)
        await عضو.remove_roles(رتبة, reason=f'{interaction.user}: إزالة رتبة')
        embed = success_embed('✅ تم إزالة الرتبة', f'تمت إزالة {رتبة.mention} من {عضو.mention}')
        await interaction.response.send_message(embed=embed)
        log = discord.Embed(title='➖ إزالة رتبة', color=0xE74C3C, timestamp=datetime.utcnow())
        log.add_field(name='👤 العضو', value=عضو.mention, inline=True)
        log.add_field(name='🎖️ الرتبة', value=رتبة.mention, inline=True)
        log.add_field(name='🛡️ المشرف', value=interaction.user.mention, inline=True)
        log.set_footer(text='🛡️ OBT System')
        await self.send_log(interaction.guild, 'role_log', log)

    # ── /سجل_الإجراءات ────────────────────────────────────────────────────────

    @app_commands.command(name='سجل_الإجراءات', description='عرض سجل إجراءات عضو')
    @app_commands.describe(عضو='العضو')
    @is_moderator()
    async def action_log(self, interaction: discord.Interaction, عضو: discord.Member):
        logs = await self.db.get_action_logs(interaction.guild.id, عضو.id, limit=10)
        embed = discord.Embed(
            title=f'📋 سجل الإجراءات — {عضو.display_name}',
            color=0x5865F2,
            timestamp=datetime.utcnow()
        )
        embed.set_thumbnail(url=عضو.display_avatar.url)
        action_emojis = {'ban': '🔨', 'kick': '👢', 'mute': '🔇', 'unmute': '🔊',
                         'warn': '⚠️', 'unban': '✅', 'anti_raid_lockdown': '🚨'}
        if not logs:
            embed.description = 'لا توجد إجراءات مسجلة.'
        else:
            for log in logs:
                emoji = action_emojis.get(log['action'], '📋')
                mod = interaction.guild.get_member(log['moderator_id'])
                mod_name = mod.display_name if mod else f"<@{log['moderator_id']}>"
                embed.add_field(
                    name=f'{emoji} {log["action"]} — {log["timestamp"][:10]}',
                    value=f'**السبب:** {log["reason"]}\n**المشرف:** {mod_name}',
                    inline=False
                )
        embed.set_footer(text='🛡️ OBT System')
        await interaction.response.send_message(embed=embed)

    # ── Error handlers ─────────────────────────────────────────────────────────

    @ban.error
    @kick.error
    @unban.error
    @lock.error
    @unlock.error
    @mute.error
    @unmute.error
    @warn.error
    @clear.error
    @slowmode.error
    @add_role.error
    @remove_role.error
    @action_log.error
    async def mod_error(self, interaction: discord.Interaction, error):
        if isinstance(error, app_commands.MissingPermissions):
            await interaction.response.send_message(
                embed=error_embed('❌ خطأ في الصلاحيات', 'ليس لديك صلاحية استخدام هذا الأمر.'),
                ephemeral=True)
        elif isinstance(error, app_commands.BotMissingPermissions):
            await interaction.response.send_message(
                embed=error_embed('❌ خطأ', 'البوت يفتقر للصلاحيات اللازمة.'),
                ephemeral=True)

    @ban_prefix.error
    @lock_prefix.error
    @unlock_prefix.error
    async def prefix_mod_error(self, ctx, error):
        if isinstance(error, commands.MissingPermissions):
            await ctx.send(embed=error_embed('❌ خطأ في الصلاحيات', 'ليس لديك صلاحية هذا الأمر.'))


async def setup(bot):
    await bot.add_cog(Moderation(bot))
